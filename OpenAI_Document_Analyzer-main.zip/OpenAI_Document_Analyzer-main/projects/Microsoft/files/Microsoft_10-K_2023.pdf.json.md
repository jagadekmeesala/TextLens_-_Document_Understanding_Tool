## FORM 10-K

:selected:

X ANNUAL REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934 For the Fiscal Year Ended June 30, 2023

UNITED STATES SECURITIES AND EXCHANGE COMMISSION Washington, D.C. 20549

OR

to :unselected: TRANSITION REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934 For the Transition Period From

Commission File Number 001-37845

## MICROSOFT CORPORATION

WASHINGTON

(STATE OF INCORPORATION)

ONE MICROSOFT WAY, REDMOND, WASHINGTON 98052-6399

(425) 882-8080 www.microsoft.com/investor

91-1144442

(I.R.S. ID)

Securities registered pursuant to Section 12(b) of the Act:



|Title of each class|Trading Symbol|Name of exchange on which registered|
|---|---|---|
|Common stock, $0.00000625 par value per share|MSFT|NASDAQ|
|3.125% Notes due 2028|MSFT|NASDAQ|
|2.625% Notes due 2033|MSFT|NASDAQ|


Securities registered pursuant to Section 12(g) of the Act:

None

Indicate by check mark if the registrant is a well-known seasoned issuer, as defined in Rule 405 of the Securities Act. Yes :selected:

:unselected: No

Indicate by check mark if the registrant is not required to file reports pursuant to Section 13 or Section 15(d) of the Act. Yes

:unselected:

:selected: No

Indicate by check mark whether the registrant (1) has filed all reports required to be filed by Section 13 or 15(d) of the Securities Exchange Act of 1934 during the preceding 12 months (or for such shorter period that the registrant was required to file such reports), and (2) has been subject to such filing requirements for the past 90 days. Yes x Indicate by check mark whether the registrant has submitted electronically every Interactive Data File required to be submitted pursuant to Rule 405 of Regulation S-T (§232.405 of this chapter) during the preceding 12 months (or for such shorter period that the registrant was required to submit such files). Yes :selected: No :unselected: :selected: No

:unselected: Indicate by check mark whether the registrant is a large accelerated filer, an accelerated filer, a non-accelerated filer, a smaller reporting company, or an emerging growth company. See the definitions of "large accelerated filer," "accelerated filer," "smaller reporting company," and "emerging growth company" in Rule 12b-2 of the Exchange Act.

:unselected: Accelerated Filer

Non-accelerated Filer :unselected: Large Accelerated Filer X :selected:

:unselected: Smaller Reporting Company

:unselected: Emerging Growth Company

If an emerging growth company, indicate by check mark if the registrant has elected not to use the extended transition period for complying with any new or revised financial accounting standards provided pursuant to Section 13(a) of the Exchange Act. :unselected:

Indicate by check mark whether the registrant has filed a report on and attestation to its management's assessment of the effectiveness of its internal control over financial reporting under Section 404(b) of the Sarbanes-Oxley Act (15 U.S.C. 7262(b)) by the registered public accounting firm that prepared or issued its audit report. :selected: If securities are registered pursuant to Section 12(b) of the Act, indicate by check mark whether the financial statements of the registrant included in the filing reflect the correction of an error to previously issued financial statements. :unselected:

Indicate by check mark whether any of those error corrections are restatements that required a recovery analysis of incentive-based compensation received by any of the registrant's executive officers during the relevant recovery period pursuant to §240.10D-1(b). :unselected:

Indicate by check mark whether the registrant is a shell company (as defined in Rule 12b-2 of the Act). Yes

:unselected:

:selected: No

As of December 31, 2022, the aggregate market value of the registrant's common stock held by non-affiliates of the registrant was $1.8 trillion based on the closing sale price as reported on the NASDAQ National Market System. As of July 24, 2023, there were 7,429,763,722 shares of common stock outstanding.

DOCUMENTS INCORPORATED BY REFERENCE

Portions of the definitive Proxy Statement to be delivered to shareholders in connection with the Annual Meeting of Shareholders to be held on December 7, 2023 are incorporated by reference into Part III.

MICROSOFT CORPORATION FORM 10-K For the Fiscal Year Ended June 30, 2023 INDEX



||||Page|
|---|---|---|---|
|PART I||||
||Item 1.|Business|4|
|||Information about our Executive Officers|20|
||Item 1A.|Risk Factors|23|
||Item 1B.|Unresolved Staff Comments|37|
||Item 2.|Properties|37|
||Item 3.|Legal Proceedings|37|
||Item 4.|Mine Safety Disclosures|37|
|PART II||||
||Item 5.|Market for Registrant's Common Equity, Related Stockholder Matters, and Issuer Purchases of Equity Securities|38|
||Item 6.|[Reserved]|39|
||Item 7.|Management's Discussion and Analysis of Financial Condition and Results of Operations|40|
||Item 7A.|Quantitative and Qualitative Disclosures about Market Risk|57|
||Item 8.|Financial Statements and Supplementary Data|58|
||Item 9.|Changes in and Disagreements with Accountants on Accounting and Financial Disclosure|99|
||Item 9A.|Controls and Procedures|99|
|||Report of Management on Internal Control over Financial Reporting|99|
|||Report of Independent Registered Public Accounting Firm|100|
||Item 9B.|Other Information|101|
||Item 9C.|Disclosure Regarding Foreign Jurisdictions that Prevent Inspections|101|
|PART III||||
||Item 10.|Directors, Executive Officers, and Corporate Governance|101|
||Item 11.|Executive Compensation|101|
||Item 12.|Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters|101|
||Item 13.|Certain Relationships and Related Transactions, and Director Independence|101|
||Item 14.|Principal Accountant Fees and Services|101|
|PART IV||||
||Item 15.|Exhibit and Financial Statement Schedules|102|
||Item 16.|Form 10-K Summary|108|
|||Signatures|109|


2

PART I Item 1

Note About Forward-Looking Statements

This report includes estimates, projections, statements relating to our business plans, objectives, and expected operating results that are "forward-looking statements" within the meaning of the Private Securities Litigation Reform Act of 1995, Section 27A of the Securities Act of 1933, and Section 21E of the Securities Exchange Act of 1934. Forward-looking statements may appear throughout this report, including the following sections: "Business" (Part I, Item 1 of this Form 10-K), "Risk Factors" (Part I, Item 1A of this Form 10-K), and "Management's Discussion and Analysis of Financial Condition and Results of Operations" (Part II, Item 7 of this Form 10-K). These forward-looking statements generally are identified by the words "believe," "project," "expect," "anticipate," "estimate," "intend," "strategy," "future," "opportunity," "plan," "may," "should," "will," "would," "will be," "will continue," "will likely result," and similar expressions. Forward-looking statements are based on current expectations and assumptions that are subject to risks and uncertainties that may cause actual results to differ materially. We describe risks and uncertainties that could cause actual results and events to differ materially in "Risk Factors," "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Quantitative and Qualitative Disclosures about Market Risk" (Part II, Item 7A of this Form 10-K). Readers are cautioned not to place undue reliance on forward-looking statements, which speak only as of the date they are made. We undertake no obligation to update or revise publicly any forward-looking statements, whether because of new information, future events, or otherwise.

3

PART I Item 1

PART I

ITEM 1. BUSINESS

GENERAL

## Embracing Our Future

Microsoft is a technology company whose mission is to empower every person and every organization on the planet to achieve more. We strive to create local opportunity, growth, and impact in every country around the world. We are creating the platforms and tools, powered by artificial intelligence ("Al"), that deliver better, faster, and more effective solutions to support small and large business competitiveness, improve educational and health outcomes, grow public-sector efficiency, and empower human ingenuity. From infrastructure and data, to business applications and collaboration, we provide unique, differentiated value to customers.

In a world of increasing economic complexity, Al has the power to revolutionize many types of work. Microsoft is now innovating and expanding our portfolio with Al capabilities to help people and organizations overcome today's challenges and emerge stronger. Customers are looking to unlock value from their digital spend and innovate for this next generation of Al, while simplifying security and management. Those leveraging the Microsoft Cloud are best positioned to take advantage of technological advancements and drive innovation. Our investment in Al spans the entire company, from Microsoft Teams and Outlook, to Bing and Xbox, and we are infusing generative Al capability into our consumer and commercial offerings to deliver copilot capability for all services across the Microsoft Cloud.

We're committed to making the promise of Al real - and doing it responsibly. Our work is guided by a core set of principles: fairness, reliability and safety, privacy and security, inclusiveness, transparency, and accountability.

## What We Offer

Founded in 1975, we develop and support software, services, devices, and solutions that deliver new value for customers and help people and businesses realize their full potential.

We offer an array of services, including cloud-based solutions that provide customers with software, services, platforms, and content, and we provide solution support and consulting services. We also deliver relevant online advertising to a global audience.

Our products include operating systems, cross-device productivity and collaboration applications, server applications, business solution applications, desktop and server management tools, software development tools, and video games. We also design and sell devices, including PCs, tablets, gaming and entertainment consoles, other intelligent devices, and related accessories.

## The Ambitions That Drive Us

To achieve our vision, our research and development efforts focus on three interconnected ambitions:

·Reinvent productivity and business processes. ·Build the intelligent cloud and intelligent edge platform.

·Create more personal computing.

## Reinvent Productivity and Business Processes

At Microsoft, we provide technology and resources to help our customers create a secure, productive work environment. Our family of products plays a key role in the ways the world works, learns, and connects.

4

PART I Item 1

Our growth depends on securely delivering continuous innovation and advancing our leading productivity and collaboration tools and services, including Office 365, Dynamics 365, and Linkedln. Microsoft 365 brings together Office 365, Windows, and Enterprise Mobility + Security to help organizations empower their employees with Al-backed tools that unlock creativity, increase collaboration, and fuel innovation, all the while enabling compliance coverage and data protection. Microsoft Teams is a comprehensive platform for work, with meetings, calls, chat, collaboration, and business process automation. Microsoft Viva is an employee experience platform that brings together communications, knowledge, learning, resources, and insights. Microsoft 365 Copilot combines next-generation Al with business data in the Microsoft Graph and Microsoft 365 applications.

Together with the Microsoft Cloud, Dynamics 365, Microsoft Teams, and our Al offerings bring a new era of collaborative applications that optimize business functions, processes, and applications to better serve customers and employees while creating more business value. Microsoft Power Platform is helping domain experts drive productivity gains with low-code/no-code tools, robotic process automation, virtual agents, and business intelligence. In a dynamic labor market, LinkedIn is helping professionals use the platform to connect, learn, grow, and get hired.

## Build the Intelligent Cloud and Intelligent Edge Platform

As digital transformation and adoption of Al accelerates and revolutionizes more business workstreams, organizations in every sector across the globe can address challenges that will have a fundamental impact on their success. For enterprises, digital technology empowers employees, optimizes operations, engages customers, and in some cases, changes the very core of products and services. We continue to invest in high performance and sustainable computing to meet the growing demand for fast access to Microsoft services provided by our network of cloud computing infrastructure and datacenters.

Our cloud business benefits from three economies of scale: datacenters that deploy computational resources at significantly lower cost per unit than smaller ones; datacenters that coordinate and aggregate diverse customer, geographic, and application demand patterns, improving the utilization of computing, storage, and network resources; and multi-tenancy locations that lower application maintenance labor costs.

The Microsoft Cloud provides the best integration across the technology stack while offering openness, improving time to value, reducing costs, and increasing agility. Being a global-scale cloud, Azure uniquely offers hybrid consistency, developer productivity, Al capabilities, and trusted security and compliance. We see more emerging use cases and needs for compute and security at the edge and are accelerating our innovation across the spectrum of intelligent edge devices, from Internet of Things ("loT") sensors to gateway devices and edge hardware to build, manage, and secure edge workloads.

Our Al platform, Azure Al, is helping organizations transform, bringing intelligence and insights to the hands of their employees and customers to solve their most pressing challenges. Organizations large and small are deploying Azure Al solutions to achieve more at scale, more easily, with the proper enterprise-level and responsible Al protections.

We have a long-term partnership with OpenAI, a leading Al research and deployment company. We deploy OpenAl's models across our consumer and enterprise products. As OpenAl's exclusive cloud provider, Azure powers all of OpenAl's workloads. We have also increased our investments in the development and deployment of specialized supercomputing systems to accelerate OpenAl's research.

Our hybrid infrastructure offers integrated, end-to-end security, compliance, identity, and management capabilities to support the real-world needs and evolving regulatory requirements of commercial customers and enterprises. Our industry clouds bring together capabilities across the entire Microsoft Cloud, along with industry-specific customizations. Azure Arc simplifies governance and management by delivering a consistent multi-cloud and on- premises management platform.

Nuance, a leader in conversational Al and ambient intelligence across industries including healthcare, financial services, retail, and telecommunications, joined Microsoft in 2022. Microsoft and Nuance enable organizations to accelerate their business goals with security-focused, cloud-based solutions infused with Al.

We are accelerating our development of mixed reality solutions with new Azure services and devices. Microsoft Mesh enables organizations to create custom, immersive experiences for the workplace to help bring remote and hybrid workers and teams together.

5

PART ! Item 1

The ability to convert data into Al drives our competitive advantage. The Microsoft Intelligent Data Platform is a leading cloud data platform that fully integrates databases, analytics, and governance. The platform empowers organizations to invest more time creating value rather than integrating and managing their data. Microsoft Fabric is an end-to-end, unified analytics platform that brings together all the data and analytics tools that organizations need.

GitHub Copilot is at the forefront of Al-powered software development, giving developers a new tool to write code easier and faster so they can focus on more creative problem-solving. From GitHub to Visual Studio, we provide a developer tool chain for everyone, no matter the technical experience, across all platforms, whether Azure, Windows, or any other cloud or client platform.

Windows also plays a critical role in fueling our cloud business with Windows 365, a desktop operating system that's also a cloud service. From another internet-connected device, including Android or macOS devices, users can run Windows 365, just like a virtual machine.

Additionally, we are extending our infrastructure beyond the planet, bringing cloud computing to space. Azure Orbital is a fully managed ground station as a service for fast downlinking of data.

## Create More Personal Computing

We strive to make computing more personal, enabling users to interact with technology in more intuitive, engaging, and dynamic ways.

Windows 11 offers innovations focused on enhancing productivity, including Windows Copilot with centralized Al assistance and Dev Home to help developers become more productive. Windows 11 security and privacy features include operating system security, application security, and user and identity security.

Through our Search, News, Mapping, and Browser services, Microsoft delivers unique trust, privacy, and safety features. In February 2023, we launched an all new, Al-powered Microsoft Edge browser and Bing search engine with Bing Chat to deliver better search, more complete answers, and the ability to generate content. Microsoft Edge is our fast and secure browser that helps protect users' data. Quick access to Al-powered tools, apps, and more within Microsoft Edge's sidebar enhance browsing capabilities.

We are committed to designing and marketing first-party devices to help drive innovation, create new device categories, and stimulate demand in the Windows ecosystem. The Surface family includes Surface Pro, Surface Laptop, and other Surface products.

Microsoft continues to invest in gaming content, community, and cloud services. We have broadened our approach to how we think about gaming end-to- end, from the way games are created and distributed to how they are played, including subscription services like Xbox Game Pass and new devices from third-party manufacturers so players can engage across PC, console, and mobile. In January 2022, we announced plans to acquire Activision Blizzard, Inc., a leader in game development and an interactive entertainment content publisher.

## Our Future Opportunity

We are focused on helping customers use the breadth and depth of the Microsoft Cloud to get the most value out of their digital spend while leading the new Al wave across our solution areas. We continue to develop complete, intelligent solutions for our customers that empower people to be productive and collaborate, while safeguarding businesses and simplifying IT management. Our goal is to lead the industry in several distinct areas of technology over the long term, which we expect will translate to sustained growth. We are investing significant resources in:

· Transforming the workplace to deliver new modern, modular business applications, drive deeper insights, and improve how people communicate, collaborate, learn, work, and interact with one another.

·Building and running cloud-based services in ways that utilize ubiquitous computing to unleash new experiences and opportunities for businesses and individuals.

·Applying Al and ambient intelligence to drive insights, revolutionize many types of work, and provide substantive productivity gains using natural methods of communication.

6

PART I Item 1

· Tackling security from all angles with our integrated, end-to-end solutions spanning security, compliance, identity, and management, across all clouds and platforms.

·Inventing new gaming experiences that bring people together around their shared love for games on any devices and pushing the boundaries of innovation with console and PC gaming.

.Using Windows to fuel our cloud business, grow our share of the PC market, and drive increased engagement with our services like Microsoft 365 Consumer, Microsoft Teams, Microsoft Edge, Bing, Xbox Game Pass, and more.

Our future growth depends on our ability to transcend current product category definitions, business models, and sales motions.

## Commitment to Sustainability

Microsoft's approach to addressing climate change starts with the sustainability of our own business. In 2020, we committed to being a carbon negative, water positive, and zero waste company by 2030.

In May 2023, we released our Environmental Sustainability Report which looked back at our progress during fiscal year 2022. We continued to make progress on our goals, with our overall emissions declining by 0.5 percent. While our Scope 1 and Scope 2 emissions continued to decline, Scope 3 emissions increased by 0.5 percent. Scope 3 represented 96 percent of our total emissions, resulting primarily from the operations of our suppliers and the use of our products across our customers.

A few examples of our continued progress include:

·Signed new power purchase agreements, bringing our total portfolio of carbon-free energy to over 13.5 gigawatts.

·Contracted for water replenishment projects that are estimated to provide more than 15.6 million cubic meters in volumetric water benefit over the lifetime of these projects.

·Diverted 12,159 metric tons of solid waste from landfills and incinerators across our direct operational footprint.

.Protected 12,270 acres of land in Belize - more than the 11,206 acres of land that we use around the world.

Microsoft has a role to play in developing and advancing new climate solutions, but we recognize that no solution can be offered by any single company, organization, or government. Our approach helps to support the sustainability needs of our customers and the global community. Our Microsoft Cloud for Sustainability, an environmental sustainability management platform that includes Microsoft Sustainability Manager, enables organizations to record, report, and reduce their Scope 1, 2, and 3 emissions. These digital tools can interoperate with business systems and unify data intelligence for organizations.

## Addressing Racial Injustice and Inequity

We are committed to addressing racial injustice and inequity in the United States for Black and African American communities and helping improve lived experiences at Microsoft, in employees' communities, and beyond. Our Racial Equity Initiative focuses on three multi-year pillars, each containing actions and progress we expect to make or exceed by 2025.

·Strengthening our communities: using data, technology, and partnerships to help improve the lives of Black and African American people in the United States, including our employees and their communities.

·Engaging our ecosystem: using our balance sheet and relationships with suppliers and partners to foster societal change and create new opportunities.

·Increasing representation and strengthening inclusion: building on our momentum by adding a $150 million investment to strengthen inclusion and double the number of Black, African American, Hispanic, and Latinx leaders in the United States by 2025.

7

PARTI Item 1

In fiscal year 2023, we collaborated with partners and worked within neighborhoods and communities to launch and scale a number of projects and programs, including:

·Working with 103 unique organizations in 165 cities and counties on our Justice Reform Initiative to empower communities and advance racial equity and fairness in the justice system.

·Increasing access to affordable broadband, devices, and digital literacy training across 14 geographies, including 11 cities and three states in the Black Rural south.

·Growing our Nonprofit Tech Acceleration for Black and African American Communities program, which uses data, technology, and partnerships to help more than 2,000 local organizations to modernize and streamline operations.

·Expanding our Technology Education and Learning Support ("TEALS") program to reach nearly 400 high schools in 21 communities to increase computer science opportunities for Black and African American students.

We exceeded our 2020 goal to double the percentage of our transaction volumes with Black- and African American-owned financial institutions by 2023. We are also increasing investment activity with Black- and African American-owned asset managers, which now represent 45 percent of our external manager group, enabling increased funds into local communities. We also met our goal of creating a $100 million program focused on mission-driven banks. We enriched our supplier pipeline, achieving our goal to spend $500 million with double the number of Black- and African American-owned suppliers. We also increased the number of identified partners in the Black Partner Growth Initiative by more than 250 percent, surpassing our initial goal.

We have made meaningful progress on representation and inclusion at Microsoft. As of June 2023, we are 93 percent of the way to our 2025 commitment to double the number of Black and African American people managers in the U.S. (below director level), and 107 percent of the way for Black and African American directors (people managers and individual contributors). We are 28 percent of the way for Hispanic and Latinx people managers (below director level) and 74 percent of the way for Hispanic and Latinx directors.

## Investing in Digital Skills

After helping over 80 million jobseekers around the world access digital skilling resources, we introduced a new Skills for Jobs initiative to support a more skills-based labor market, with greater flexibility and accessible learning paths to develop the right skills needed for the most in-demand jobs. Our Skills for Jobs initiative brings together learning resources, certification opportunities, and job-seeker tools from LinkedIn, GitHub, and Microsoft Learn, and is built on data insights drawn from LinkedIn's Economic Graph.

We also launched a national campaign to help skill and recruit 250,000 people into the cybersecurity workforce by 2025, representing half of the country's workforce shortage. To that end, we are making curriculum available free of charge to all of the nation's higher education institutions, providing training for new and existing faculty, and providing scholarships and supplemental resources to 25,000 students. We have expanded the cyber skills initiative to 27 additional countries that show elevated cyberthreat risks coupled with significant gaps in their cybersecurity workforces, partnering with nonprofits and other educational institutions to train the next generation of cybersecurity workers.

Generative Al is creating unparalleled opportunities to empower workers globally, but only if everyone has the skills to use it. To address this, in June 2023 we launched a new Al Skills Initiative to help everyone learn how to harness the power of Al. This includes a new LinkedIn learning pathway offering new coursework on learning the foundations of generative Al. We also launched a new global grant challenge to uncover new ways of training workers on generative Al and are providing greater access to digital learning events and resources for everyone to improve their Al fluency.

## Overview

Microsoft aims to recruit, develop, and retain world-changing talent from a diversity of backgrounds. To foster their and our success, we seek to create an environment where people can thrive and do their best work. We strive to maximize the potential of our human capital resources by creating a respectful, rewarding, and inclusive work environment that enables our global employees to create products and services that further our mission.

8

PART I Item 1

As of June 30, 2023, we employed approximately 221,000 people on a full-time basis, 120,000 in the U.S. and 101,000 internationally. Of the total employed people, 89,000 were in operations, including manufacturing, distribution, product support, and consulting services; 72,000 were in product research and development; 45,000 were in sales and marketing; and 15,000 were in general and administration. Certain employees are subject to collective bargaining agreements.

## Our Culture

Microsoft's culture is grounded in growth mindset. This means everyone is on a continuous journey to learn and grow, operating as one company instead of multiple siloed businesses.

Our employee listening systems enable us to gather feedback directly from our workforce to inform our programs and employee needs globally. Employees participate in our Employee Signals surveys, which cover a variety of topics such as thriving, inclusion, team culture, wellbeing, and learning and development. We also collect Daily Signals employee survey responses, giving us real-time insights into ways we can support our employees. In addition to Employee Signals and Daily Signals surveys, we gain insights through onboarding, exit surveys, internal Viva Engage channels, employee Q&A sessions, and our internal AskHR Service support.

Diversity and inclusion are core to our business model, and we hold ourselves accountable for driving global systemic change in our workforce and creating an inclusive work environment. We support multiple highly active Employee Resource Groups for women, families, racial and ethnic minorities, military, people with disabilities, and employees who identify as LGBTQIA+, where employees can go for support, networking, and community-building. As described in our 2022 Proxy Statement, annual performance and compensation reviews of our senior leadership team include an evaluation of their contributions to employee culture and diversity. To ensure accountability over time, we publicly disclose our progress on a multitude of workforce metrics including:

·Detailed breakdowns of gender, racial, and ethnic minority representation in our employee population, with data by job types, levels, and segments of our business. ·Our EEO-1 report (equal employment opportunity).

· Disability representation.

·Pay equity (see details below).

## Total Rewards and Pay Equity

We develop dynamic, sustainable, market-driven, and strategic programs with the goal of providing a highly differentiated portfolio to attract, reward, and retain top talent and enable our employees to thrive. These programs reinforce our culture and values such as collaboration and growth mindset. Managers evaluate and recommend rewards based on, for example, how well we leverage the work of others and contribute to the success of our colleagues. We monitor pay equity and career progress across multiple dimensions. Our total compensation opportunity is highly differentiated and is market competitive.

In order to manage our costs in a dynamic, competitive environment, in fiscal year 2023 we announced that base salaries of salaried employees would remain at fiscal year 2022 levels. Pay increases continue to be available for rewards-eligible hourly and equivalent employees. We will continue our practice of investing in stock for all rewards-eligible employees, salaried and hourly, and investing in bonuses for all eligible employees.

9

PART I Item 1

Since 2016, we have reported on pay equity as part of our annual Diversity and Inclusion report. In 2022, we reported that all racial and ethnic minority employees in the U.S. combined earn $1.008 for every $1.000 earned by their white counterparts, that women in the U.S. earn $1.007 for every $1.000 earned by their counterparts who are men, and that women outside the U.S. earn $1.002 for every $1.000 earned by their counterparts outside the U.S. who are men. In this year's report, we again expanded our pay equity data beyond the U.S. to report on 61 additional countries (up from 12 last year), representing 99.8% of our global Microsoft workforce.

In addition, we began reporting on unadjusted median pay in our annual report, comparing total pay amounts for all employees regardless of factors such as job title, level, or tenure. For employees who are eligible for rewards, the analysis showed that total pay for women is 89.6% of total pay for men in the U.S. and 86.2% outside of the U.S., and total pay for racial and ethnic minorities in the U.S. is 89.9% of total pay for white employees. As we continue to increase representation for women and racial and ethnic minorities at more senior levels, and continue to ensure pay equity for all, the gap between the medians will reduce.

Our intended result is a global performance and development approach that fosters our culture, and competitive compensation that ensures equitable pay by role while supporting pay for performance.

## Wellbeing and Hybrid Work

Microsoft is committed to supporting our employees' wellbeing while they are at work and in their personal lives. We have invested significantly in wellbeing, and offer a differentiated benefits package which includes many physical, emotional, and financial wellness programs including counseling through the Microsoft CARES Employee Assistance Program, mental wellbeing support, flexible fitness benefits, disability accommodations, savings and investment tools, adoption assistance, and back-up care for children and elders. Finally, our Occupational Health and Safety program helps ensure employees can stay safe while they are working.

We introduced Hybrid Workplace Flexibility Guidance to better support leaders, managers, and employees in hybrid work scenarios. Our ongoing survey data shows that 93% of employees value the flexibility related to work location, work site, and work hours, and 78% are satisfied with the quality of connection with co-workers. There is no one-size-fits-all approach to flexible work at Microsoft. As a company, we will continue to leverage data and research to inform decision making, balancing the needs of business, team, and individual.

## Learning and Development

We offer a range of learning opportunities, including personalized opportunities on our internal and external learning portals, in-classroom learning, required learning on compliance and company culture, on-the-job advancement opportunities, and manager coaching. We also provide customized manager learning, new employee orientation, and tools for operating in a flexible hybrid work environment.

All Microsoft employees globally access our single Viva Learning tool for both required and personal choice learning. This includes courses focused on our core principles and compliance matters, such as Business Conduct, Privacy, Security Foundations, and Harassment Prevention. We also deliver skills training for employees based on their profession and role discipline.

We have over 27,000 people managers, all of whom must complete between 20-33 hours of compulsory training on leadership and management and are assigned additional targeted training on an ongoing basis related to people management, compliance, and culture.

10

PART I Item 1

## OPERATING SEGMENTS

We operate our business and report our financial performance using three segments: Productivity and Business Processes, Intelligent Cloud, and More Personal Computing. Our segments provide management with a comprehensive financial view of our key businesses. The segments enable the alignment of strategies and objectives across the development, sales, marketing, and services organizations, and they provide a framework for timely and rational allocation of resources within businesses.

Additional information on our operating segments and geographic and product information is contained in Note 19 - Segment Information and Geographic Data of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K).

Our reportable segments are described below.

## Productivity and Business Processes

Our Productivity and Business Processes segment consists of products and services in our portfolio of productivity, communication, and information services, spanning a variety of devices and platforms. This segment primarily comprises:

·Office Commercial (Office 365 subscriptions, the Office 365 portion of Microsoft 365 Commercial subscriptions, and Office licensed on- premises), comprising Office, Exchange, SharePoint, Microsoft Teams, Office 365 Security and Compliance, Microsoft Viva, and Microsoft 365 Copilot.

·Office Consumer, including Microsoft 365 Consumer subscriptions, Office licensed on-premises, and other Office services.

·LinkedIn, including Talent Solutions, Marketing Solutions, Premium Subscriptions, and Sales Solutions.

·Dynamics business solutions, including Dynamics 365, comprising a set of intelligent, cloud-based applications across ERP, CRM (including Customer Insights), Power Apps, and Power Automate; and on-premises ERP and CRM applications.

## Office Commercial

Office Commercial is designed to increase personal, team, and organizational productivity through a range of products and services. Growth depends on our ability to reach new users in new markets such as frontline workers, small and medium businesses, and growth markets, as well as add value to our core product and service offerings to span productivity categories such as communication, collaboration, analytics, security, and compliance. Office Commercial revenue is mainly affected by a combination of continued installed base growth and average revenue per user expansion, as well as the continued shift from Office licensed on-premises to Office 365.

## Office Consumer

Office Consumer is designed to increase personal productivity and creativity through a range of products and services. Growth depends on our ability to reach new users, add value to our core product set, and continue to expand our product and service offerings into new markets. Office Consumer revenue is mainly affected by the percentage of customers that buy Office with their new devices and the continued shift from Office licensed on- premises to Microsoft 365 Consumer subscriptions. Office Consumer Services revenue is mainly affected by the demand for communication and storage through Skype, Outlook.com, and OneDrive, which is largely driven by subscriptions, advertising, and the sale of minutes.

11

PART I Item 1

## LinkedIn

LinkedIn connects the world's professionals to make them more productive and successful and transforms the way companies hire, market, sell, and learn. Our vision is to create economic opportunity for every member of the global workforce through the ongoing development of the world's first Economic Graph, a digital representation of the global economy. In addition to LinkedIn's free services, Linkedln offers monetized solutions: Talent Solutions, Marketing Solutions, Premium Subscriptions, and Sales Solutions. Talent Solutions provide insights for workforce planning and tools to hire, nurture, and develop talent. Talent Solutions also includes Learning Solutions, which help businesses close critical skills gaps in times where companies are having to do more with existing talent. Marketing Solutions help companies reach, engage, and convert their audiences at scale. Premium Subscriptions enable professionals to manage their professional identity, grow their network, find jobs, and connect with talent through additional services like premium search. Sales Solutions help companies strengthen customer relationships, empower teams with digital selling tools, and acquire new opportunities. LinkedIn has over 950 million members and has offices around the globe. Growth will depend on our ability to increase the number of LinkedIn members and our ability to continue offering services that provide value for our members and increase their engagement. LinkedIn revenue is mainly affected by demand from enterprises and professional organizations for subscriptions to Talent Solutions, Sales Solutions, and Premium Subscriptions offerings, as well as member engagement and the quality of the sponsored content delivered to those members to drive Marketing Solutions.

## Dynamics

Dynamics provides cloud-based and on-premises business solutions for financial management, enterprise resource planning ("ERP"), customer relationship management ("CRM"), supply chain management, and other application development platforms for small and medium businesses, large organizations, and divisions of global enterprises. Dynamics revenue is driven by the number of users licensed and applications consumed, expansion of average revenue per user, and the continued shift to Dynamics 365, a unified set of cloud-based intelligent business applications, including Power Apps and Power Automate.

## Competition

Competitors to Office include software and global application vendors, such as Apple, Cisco Systems, Meta, Google, Okta, Proofpoint, Slack, Symantec, Zoom, and numerous web-based and mobile application competitors as well as local application developers. Apple distributes versions of its pre-installed application software, such as email and calendar products, through its PCs, tablets, and phones. Cisco Systems is using its position in enterprise communications equipment to grow its unified communications business. Meta offers communication tools to enable productivity and engagement within organizations. Google provides a hosted messaging and productivity suite. Slack provides teamwork and collaboration software. Zoom offers videoconferencing and cloud phone solutions. Okta, Proofpoint, and Symantec provide security solutions across email security, information protection, identity, and governance. Web-based offerings competing with individual applications have also positioned themselves as alternatives to our products and services. We compete by providing powerful, flexible, secure, integrated industry-specific, and easy-to-use productivity and collaboration tools and services that create comprehensive solutions and work well with technologies our customers already have both on-premises or in the cloud.

LinkedIn faces competition from online professional networks, recruiting companies, talent management companies, and larger companies that are focusing on talent management and human resource services; job boards; traditional recruiting firms; and companies that provide learning and development products and services. Marketing Solutions competes with online and offline outlets that generate revenue from advertisers and marketers, and Sales Solutions competes with online and offline outlets for companies with lead generation and customer intelligence and insights.

Dynamics competes with cloud-based and on-premises business solution providers such as Oracle, Salesforce, and SAP.

12

PART I Item 1

## Intelligent Cloud

Our Intelligent Cloud segment consists of our public, private, and hybrid server products and cloud services that can power modern business and developers. This segment primarily comprises:

·Server products and cloud services, including Azure and other cloud services; SQL Server, Windows Server, Visual Studio, System Center, and related Client Access Licenses ("CALs"); and Nuance and GitHub.

·Enterprise Services, including Enterprise Support Services, Industry Solutions (formerly Microsoft Consulting Services), and Nuance professional services.

## Server Products and Cloud Services

Azure is a comprehensive set of cloud services that offer developers, IT professionals, and enterprises freedom to build, deploy, and manage applications on any platform or device. Customers can use Azure through our global network of datacenters for computing, networking, storage, mobile and web application services, Al, loT, cognitive services, and machine learning. Azure enables customers to devote more resources to development and use of applications that benefit their organizations, rather than managing on-premises hardware and software. Azure revenue is mainly affected by infrastructure-as-a-service and platform-as-a-service consumption-based services, and per user-based services such as Enterprise Mobility + Security.

Azure Al offerings provide a competitive advantage as companies seek ways to optimize and scale their business with machine learning. Azure's purpose-built, Al-optimized infrastructure allows advanced models, including GPT-4 services designed for developers and data scientists, to do more with less. Customers can integrate large language models and develop the next generation of Al apps and services.

Our server products are designed to make IT professionals, developers, and their systems more productive and efficient. Server software is integrated server infrastructure and middleware designed to support software applications built on the Windows Server operating system. This includes the server platform, database, business intelligence, storage, management and operations, virtualization, service-oriented architecture platform, security, and identity software. We also license standalone and software development lifecycle tools for software architects, developers, testers, and project managers. Server products revenue is mainly affected by purchases through volume licensing programs, licenses sold to original equipment manufacturers ("OEM"), and retail packaged products. CALs provide access rights to certain server products, including SQL Server and Windows Server, and revenue is reported along with the associated server product.

Nuance and GitHub include both cloud and on-premises offerings. Nuance provides healthcare and enterprise Al solutions. GitHub provides a collaboration platform and code hosting service for developers.

## Enterprise Services

Enterprise Services, including Enterprise Support Services, Industry Solutions, and Nuance Professional Services, assist customers in developing, deploying, and managing Microsoft server solutions, Microsoft desktop solutions, and Nuance conversational Al and ambient intelligent solutions, along with providing training and certification to developers and IT professionals on various Microsoft products.

## Competition

Azure faces diverse competition from companies such as Amazon, Google, IBM, Oracle, VMware, and open source offerings. Azure's competitive advantage includes enabling a hybrid cloud, allowing deployment of existing datacenters with our public cloud into a single, cohesive infrastructure, and the ability to run at a scale that meets the needs of businesses of all sizes and complexities. Our Al offerings compete with Al products from hyperscalers such as Amazon Bedrock, Amazon CodeWhisperer, and Google Al, as well as products from other emerging competitors, many of which are also current or potential partners, including Meta's LLaMA2 and other open source solutions. Our Enterprise Mobility + Security offerings also compete with products from a range of competitors including identity vendors, security solution vendors, and numerous other security point solution vendors. We believe our cloud's global scale, coupled with our broad portfolio of identity and security solutions, allows us to effectively solve complex cybersecurity challenges for our customers and differentiates us from the competition.

13

PART I Item 1

Our server products face competition from a wide variety of server operating systems and applications offered by companies with a range of market approaches. Vertically integrated computer manufacturers such as Hewlett-Packard, IBM, and Oracle offer their own versions of the Unix operating system preinstalled on server hardware. Nearly all computer manufacturers offer server hardware for the Linux operating system, and many contribute to Linux operating system development. The competitive position of Linux has also benefited from the large number of compatible applications now produced by many commercial and non-commercial software developers. A number of companies, such as Red Hat, supply versions of Linux.

We compete to provide enterprise-wide computing solutions and point solutions with numerous commercial software vendors that offer solutions and middleware technology platforms, software applications for connectivity (both Internet and intranet), security, hosting, database, and e-business servers. IBM and Oracle lead a group of companies focused on the Java Platform Enterprise Edition that competes with our enterprise-wide computing solutions. Commercial competitors for our server applications for PC-based distributed client-server environments include CA Technologies, IBM, and Oracle. Our web application platform software competes with open source software such as Apache, Linux, MySQL, and PHP. In middleware, we compete against Java vendors.

Our database, business intelligence, and data warehousing solutions offerings compete with products from IBM, Oracle, SAP, Snowflake, and other companies. Our system management solutions compete with server management and server virtualization platform providers, such as BMC, CA Technologies, Hewlett-Packard, IBM, and VMware. Our products for software developers compete against offerings from Adobe, IBM, Oracle, and other companies, and also against open source projects, including Eclipse (sponsored by CA Technologies, IBM, Oracle, and SAP), PHP, and Ruby on Rails.

We believe our server products provide customers with advantages in performance, total costs of ownership, and productivity by delivering superior applications, development tools, compatibility with a broad base of hardware and software applications, security, and manageability.

Our Enterprise Services business competes with a wide range of companies that provide strategy and business planning, application development, and infrastructure services, including multinational consulting firms and small niche businesses focused on specific technologies.

## More Personal Computing

Our More Personal Computing segment consists of products and services that put customers at the center of the experience with our technology. This segment primarily comprises:

·Windows, including Windows OEM licensing ("Windows OEM") and other non-volume licensing of the Windows operating system; Windows Commercial, comprising volume licensing of the Windows operating system, Windows cloud services, and other Windows commercial offerings; patent licensing; and Windows loT.

·Devices, including Surface, HoloLens, and PC accessories.

.Gaming, including Xbox hardware and Xbox content and services, comprising first- and third-party content (including games and in-game content), Xbox Game Pass and other subscriptions, Xbox Cloud Gaming, advertising, third-party disc royalties, and other cloud services. .Search and news advertising, comprising Bing (including Bing Chat), Microsoft News, Microsoft Edge, and third-party affiliates.

## Windows

The Windows operating system is designed to deliver a more personal computing experience for users by enabling consistency of experience, applications, and information across their devices. Windows OEM revenue is impacted significantly by the number of Windows operating system licenses purchased by OEMs, which they pre-install on the devices they sell. In addition to computing device market volume, Windows OEM revenue is impacted by:

·The mix of computing devices based on form factor and screen size.

·Differences in device market demand between developed markets and growth markets.

·Attachment of Windows to devices shipped.

14

PART I Item 1

## ·Customer mix between consumer, small and medium businesses, and large enterprises.

·Changes in inventory levels in the OEM channel. ·Pricing changes and promotions, pricing variation that occurs when the mix of devices manufactured shifts from local and regional system builders to large multinational OEMs, and different pricing of Windows versions licensed. ·Constraints in the supply chain of device components. ·Piracy.

Windows Commercial revenue, which includes volume licensing of the Windows operating system and Windows cloud services such as Microsoft Defender for Endpoint, is affected mainly by the demand from commercial customers for volume licensing and Software Assurance ("SA"), as well as advanced security offerings. Windows Commercial revenue often reflects the number of information workers in a licensed enterprise and is relatively independent of the number of PCs sold in a given year.

Patent licensing includes our programs to license patents we own for use across a broad array of technology areas, including mobile devices and cloud offerings.

Windows loT extends the power of Windows and the cloud to intelligent systems by delivering specialized operating systems, tools, and services for use in embedded devices.

## Devices

We design and sell devices, including Surface, HoloLens, and PC accessories. Our devices are designed to enable people and organizations to connect to the people and content that matter most using Windows and integrated Microsoft products and services. Surface is designed to help organizations, students, and consumers be more productive. Growth in Devices is dependent on total PC shipments, the ability to attract new customers, our product roadmap, and expanding into new categories.

## Gaming

Our gaming platform is designed to provide a variety of entertainment through a unique combination of content, community, and cloud services. Our exclusive game content is created through Xbox Game Studios, a collection of first-party studios creating iconic and differentiated gaming experiences. We continue to invest in new gaming studios and content to expand our intellectual property roadmap and leverage new content creators. These unique gaming experiences are the cornerstone of Xbox Game Pass, a subscription service and gaming community with access to a curated library of over 400 first- and third-party console and PC titles.

The gamer remains at the heart of the Xbox ecosystem. We are identifying new opportunities to attract gamers across a variety of different end points through our first- and third-party content and business diversification across subscriptions, ads, and digital stores. We've seen new devices from third- party manufacturers along with key PC and mobile end points that help us empower gamers to play in a way that is most convenient to them. We are focused on growing the platform and expanding to new ecosystems to engage as many gamers as possible.

Xbox enables people to connect and share online gaming experiences that are accessible on Xbox consoles, Windows-enabled devices, and other devices. Xbox is designed to benefit users by providing access to a network of certified applications and services and to benefit our developer and partner ecosystems by providing access to a large customer base. Xbox revenue is mainly affected by subscriptions and sales of first- and third-party content, as well as advertising. Growth of our Gaming business is determined by the overall active user base through Xbox enabled content, availability of games, providing exclusive game content that gamers seek, the computational power and reliability of the devices used to access our content and services, and the ability to create new experiences through first-party content creators.

15

PART I Item 1

## Search and News Advertising

Our Search and news advertising business is designed to deliver relevant search, native, and display advertising to a global audience. Our Microsoft Edge browser and Bing Chat capabilities are key tools to enable user acquisition and engagement, while our technology platform enables accelerated delivery of digital advertising solutions. In addition to first-party tools, we have several partnerships with companies, such as Yahoo, through which we provide and monetize search offerings. Growth depends on our ability to attract new users, understand intent, and match intent with relevant content on advertising offerings.

## Competition

Windows faces competition from various software products and from alternative platforms and devices, mainly from Apple and Google. We believe Windows competes effectively by giving customers choice, value, flexibility, security, an easy-to-use interface, and compatibility with a broad range of hardware and software applications, including those that enable productivity.

Devices face competition from various computer, tablet, and hardware manufacturers who offer a unique combination of high-quality industrial design and innovative technologies across various price points. These manufacturers, many of which are also current or potential partners and customers, include Apple and our Windows OEMs.

Xbox and our cloud gaming services face competition from various online gaming ecosystems and game streaming services, including those operated by Amazon, Apple, Meta, and Tencent. We also compete with other providers of entertainment services such as video streaming platforms. Our gaming platform competes with console platforms from Nintendo and Sony, both of which have a large, established base of customers. We believe our gaming platform is effectively positioned against, and uniquely differentiated from, competitive products and services based on significant innovation in hardware architecture, user interface, developer tools, online gaming and entertainment services, and continued strong exclusive content from our own first-party game franchises as well as other digital content offerings.

Our Search and news advertising business competes with Google and a wide array of websites, social platforms like Meta, and portals that provide content and online offerings to end users.

## OPERATIONS

We have regional operations service centers that support our operations, including customer contract and order processing, billing, credit and collections, information processing, and vendor management and logistics. The center in Ireland supports the African, Asia-Pacific, European, and Middle East regions; and the centers in Arlington, Virginia, Atlanta, Georgia, Charlotte, North Carolina, Fargo, North Dakota, Fort Lauderdale, Florida, Redmond, Washington, Reno, Nevada, and Puerto Rico support the American regions.

In addition to our operations centers, we also operate datacenters throughout each of these regions. We continue to identify and evaluate opportunities to expand our datacenter locations and increase our server capacity to meet the evolving needs of our customers, particularly given the growing demand for Al services. Our datacenters depend on the availability of permitted and buildable land, predictable energy, networking supplies, and servers, including graphics processing units ("GPUs") and other components.

Our devices are primarily manufactured by third-party contract manufacturers. For the majority of our products, we have the ability to use other manufacturers if a current vendor becomes unavailable or unable to meet our requirements. However, some of our products contain certain components for which there are very few qualified suppliers. Extended disruptions at these suppliers could impact our ability to manufacture devices on time to meet consumer demand.

16

PART I Item 1

RESEARCH AND DEVELOPMENT

## We develop most of our products and services internally through the following engineering groups.

·Cloud and Al - focuses on making IT professionals, developers, partners, independent software vendors, and their systems more productive and efficient through development of Azure Al platform and cloud infrastructure, server, database, CRM, ERP, software development tools and services (including GitHub), Al cognitive services, and other business process applications and services for enterprises.

· Strategic Missions and Technologies - focuses on incubating technical products and support solutions with transformative potential for the future of cloud computing and continued company growth across quantum computing, Azure Space & Missions Engineering, telecommunications, and Microsoft Federal Sales and Delivery.

· Experiences and Devices - focuses on delivering high value end-user experiences across our products, services, and devices, including Microsoft 365, Windows, Microsoft Teams, Search (including Microsoft Edge and Bing Chat) and other advertising-based services, and the Surface line of devices.

·Microsoft Security - focuses on delivering a comprehensive portfolio of services that protect our customers' digital infrastructure through cloud platform and application security, data protection and governance, identity and network access, and device management.

· Technology and Research - focuses on fundamental research, product and business incubations, and forward-looking Al innovations that span infrastructure, services, and applications.

·LinkedIn - focuses on our services that transform the way professionals grow their network and find jobs and the way businesses hire, market, sell, and learn.

· Gaming - focuses on developing hardware, content, and services across a large range of platforms to help grow our user base through game experiences and social interaction.

Internal development allows us to maintain competitive advantages that come from product differentiation and closer technical control over our products and services. It also gives us the freedom to decide which modifications and enhancements are most important and when they should be implemented. We strive to obtain information as early as possible about changing usage patterns and hardware advances that may affect software and hardware design. Before releasing new software platforms, and as we make significant modifications to existing platforms, we provide application vendors with a range of resources and guidelines for development, training, and testing. Generally, we also create product documentation internally.

We protect our intellectual property investments in a variety of ways. We work actively in the U.S. and internationally to ensure the enforcement of copyright, trademark, trade secret, and other protections that apply to our software and hardware products, services, business plans, and branding. We are a leader among technology companies in pursuing patents and currently have a portfolio of over 70,000 U.S. and international patents issued and over 19,000 pending worldwide. While we employ much of our internally-developed intellectual property in our products and services, we also engage in outbound licensing of specific patented technologies that are incorporated into licensees' products. From time to time, we enter into broader cross-license agreements with other technology companies covering entire groups of patents. We may also purchase or license technology that we incorporate into our products and services. At times, we make select intellectual property broadly available at no or low cost to achieve a strategic objective, such as promoting industry standards, advancing interoperability, supporting societal and/or environmental efforts, or attracting and enabling our external development community. Our increasing engagement with open source software will also cause us to license our intellectual property rights broadly in certain situations.

While it may be necessary in the future to seek or renew licenses relating to various aspects of our products and services, we believe, based upon past experience and industry practice, such licenses generally can be obtained on commercially reasonable terms. We believe our continuing research and product development are not materially dependent on any single license or other agreement with a third party relating to the development of our products.

17

PART I Item 1

## Investing in the Future

Our success is based on our ability to create new and compelling products, services, and experiences for our users, to initiate and embrace disruptive technology trends, to enter new geographic and product markets, and to drive broad adoption of our products and services. We invest in a range of emerging technology trends and breakthroughs that we believe offer significant opportunities to deliver value to our customers and growth for the company. Based on our assessment of key technology trends, we maintain our long-term commitment to research and development across a wide spectrum of technologies, tools, and platforms spanning digital work and life experiences, cloud computing, Al, devices, and operating systems.

While our main product research and development facilities are located in Redmond, Washington, we also operate research and development facilities in other parts of the U.S. and around the world. This global approach helps us remain competitive in local markets and enables us to continue to attract top talent from across the world.

We plan to continue to make significant investments in a broad range of product research and development activities, and as appropriate we will coordinate our research and development across operating segments and leverage the results across the company.

In addition to our main research and development operations, we also operate Microsoft Research. Microsoft Research is one of the world's largest corporate research organizations, often working in close collaboration with top universities around the world, and is focused on advancing the state-of- the-art in computer science and a broad range of other disciplines. Our investment in fundamental research provides us a unique perspective on future trends and contributes to our innovation.

## DISTRIBUTION, SALES, AND MARKETING

We market and distribute our products and services through the following channels: OEMs, direct, and distributors and resellers. Our sales organization performs a variety of functions, including working directly with commercial enterprises and public-sector organizations worldwide to identify and meet their technology and digital transformation requirements; managing OEM relationships; and supporting system integrators, independent software vendors, and other partners who engage directly with our customers to perform sales, consulting, and fulfillment functions for our products and services.

## OEMs

We distribute our products and services through OEMs that pre-install our software on new devices and servers they sell. The largest component of the OEM business is the Windows operating system pre-installed on devices. OEMs also sell devices pre-installed with other Microsoft products and services, including applications such as Office and the capability to subscribe to Office 365.

There are two broad categories of OEMs. The largest category of OEMs are direct OEMs as our relationship with them is managed through a direct agreement between Microsoft and the OEM. We have distribution agreements covering one or more of our products with virtually all the multinational OEMs, including Dell, Hewlett-Packard, Lenovo, and with many regional and local OEMs. The second broad category of OEMs are system builders consisting of lower-volume PC manufacturers, which source Microsoft software for pre-installation and local redistribution primarily through the Microsoft distributor channel rather than through a direct agreement or relationship with Microsoft.

## Direct

Many organizations that license our products and services transact directly with us through Enterprise Agreements and Enterprise Services contracts, with sales support from system integrators, independent software vendors, web agencies, and partners that advise organizations on licensing our products and services ("Enterprise Agreement Software Advisors" or "ESA"). Microsoft offers direct sales programs targeted to reach small, medium, and corporate customers, in addition to those offered through the reseller channel. A large network of partner advisors support many of these sales.

We also sell commercial and consumer products and services directly to customers, such as cloud services, search, and gaming, through our digital marketplaces and online stores. Additionally, our Microsoft Experience Centers are designed to facilitate deeper engagement with our partners and customers across industries.

18

PART I Item 1

## Distributors and Resellers

Organizations also license our products and services indirectly, primarily through licensing solution partners ("LSP"), distributors, value-added resellers ("VAR"), and retailers. Although each type of reselling partner may reach organizations of all sizes, LSPs are primarily engaged with large organizations, distributors resell primarily to VARs, and VARs typically reach small and medium organizations. ESAs are also typically authorized as LSPs and operate as resellers for our other volume licensing programs. Microsoft Cloud Solution Provider is our main partner program for reselling cloud services.

We distribute our retail packaged products primarily through independent non-exclusive distributors, authorized replicators, resellers, and retail outlets. Individual consumers obtain these products primarily through retail outlets. We distribute our devices through third-party retailers. We have a network of field sales representatives and field support personnel that solicit orders from distributors and resellers and provide product training and sales support.

Our Dynamics business solutions are also licensed to enterprises through a global network of channel partners providing vertical solutions and specialized services.

## LICENSING OPTIONS

We offer options for organizations that want to purchase our cloud services, on-premises software, and SA. We license software to organizations under volume licensing agreements to allow the customer to acquire multiple licenses of products and services instead of having to acquire separate licenses through retail channels. We use different programs designed to provide flexibility for organizations of various sizes. While these programs may differ in various parts of the world, generally they include those discussed below.

SA conveys rights to new software and upgrades for perpetual licenses released over the contract period. It also provides support, tools, training, and other licensing benefits to help customers deploy and use software efficiently. SA is included with certain volume licensing agreements and is an optional purchase with others.

## Enterprise Agreement

Enterprise Agreements offer large organizations a manageable volume licensing program that gives them the flexibility to buy cloud services and software licenses under one agreement. Enterprise Agreements are designed for medium or large organizations that want to license cloud services and on-premises software organization-wide over a three-year period. Organizations can elect to purchase perpetual licenses or subscribe to licenses. SA is included.

## Microsoft Customer Agreement

A Microsoft Customer Agreement is a simplified purchase agreement presented, accepted, and stored through a digital experience. A Microsoft Customer Agreement is a non-expiring agreement that is designed to support all customers over time, whether purchasing through a partner or directly from Microsoft.

## Microsoft Online Subscription Agreement

A Microsoft Online Subscription Agreement is designed for small and medium organizations that want to subscribe to, activate, provision, and maintain cloud services seamlessly and directly via the web. The agreement allows customers to acquire monthly or annual subscriptions for cloud-based services.

## Microsoft Products and Services Agreement

Microsoft Products and Services Agreements are designed for medium and large organizations that want to license cloud services and on-premises software as needed, with no organization-wide commitment, under a single, non-expiring agreement. Organizations purchase perpetual licenses or subscribe to licenses. SA is optional for customers that purchase perpetual licenses.

19

PART I Item 1

## Open Value

Open Value agreements are a simple, cost-effective way to acquire the latest Microsoft technology. These agreements are designed for small and medium organizations that want to license cloud services and on-premises software over a three-year period. Under Open Value agreements, organizations can elect to purchase perpetual licenses or subscribe to licenses and SA is included.

## Select Plus

A Select Plus agreement is designed for government and academic organizations to acquire on-premises licenses at any affiliate or department level, while realizing advantages as one organization. Organizations purchase perpetual licenses and SA is optional.

## Partner Programs

The Microsoft Cloud Solution Provider Program offers customers an easy way to license the cloud services they need in combination with the value- added services offered by their systems integrator, managed services provider, or cloud reseller partner. Partners in this program can easily package their own products and services to directly provision, manage, and support their customer subscriptions.

The Microsoft Services Provider License Agreement allows hosting service providers and independent software vendors who want to license eligible Microsoft software products to provide software services and hosted applications to their end customers. Partners license software over a three-year period and are billed monthly based on consumption.

The Independent Software Vendor Royalty Program enables partners to integrate Microsoft products into other applications and then license the unified business solution to their end users.

## CUSTOMERS

Our customers include individual consumers, small and medium organizations, large global enterprises, public-sector institutions, Internet service providers, application developers, and OEMs. Our practice is to ship our products promptly upon receipt of purchase orders from customers; consequently, backlog is not significant.

## INFORMATION ABOUT OUR EXECUTIVE OFFICERS

Our executive officers as of July 27, 2023 were as follows:



|Name|Age|Position with the Company|
|---|---|---|
|Satya Nadella|55|Chairman and Chief Executive Officer|
|Judson B. Althoff|50|Executive Vice President and Chief Commercial Officer|
|Christopher C. Capossela|53|Executive Vice President and Chief Marketing Officer|
|Kathleen T. Hogan|57|Executive Vice President and Chief Human Resources Officer|
|Amy E. Hood|51|Executive Vice President and Chief Financial Officer|
|Bradford L. Smith|64|Vice Chair and President|
|Christopher D. Young|51|Executive Vice President, Business Development, Strategy, and Ventures|


Mr. Nadella was appointed Chairman of the Board in June 2021 and Chief Executive Officer in February 2014. He served as Executive Vice President, Cloud and Enterprise from July 2013 until that time. From 2011 to 2013, Mr. Nadella served as President, Server and Tools. From 2009 to 2011, he was Senior Vice President, Online Services Division. From 2008 to 2009, he was Senior Vice President, Search, Portal, and Advertising. Since joining Microsoft in 1992, Mr. Nadella's roles also included Vice President of the Business Division. Mr. Nadella also serves on the Board of Directors of Starbucks Corporation.

Mr. Althoff was appointed Executive Vice President and Chief Commercial Officer in July 2021. He served as Executive Vice President, Worldwide Commercial Business from July 2017 until that time. Prior to that, Mr. Althoff served as the President of Microsoft North America. Mr. Althoff joined Microsoft in March 2013 as President of Microsoft North America.

20

PART I Item 1

Mr. Capossela was appointed Executive Vice President, Marketing and Consumer Business, and Chief Marketing Officer in July 2016. He had served as Executive Vice President, Chief Marketing Officer since March 2014.Since joining Microsoft in 1991, Mr. Capossela has held a variety of marketing leadership roles in the Consumer Channels Group, and in the Microsoft Office Division where he was responsible for marketing productivity solutions including Microsoft Office, Office 365, SharePoint, Exchange, Skype for Business, Project, and Visio.

Ms. Hogan was appointed Executive Vice President, Human Resources in November 2014. Prior to that Ms. Hogan was Corporate Vice President of Microsoft Services. She also served as Corporate Vice President of Customer Service and Support. Ms. Hogan joined Microsoft in 2003. Ms. Hogan also serves on the Board of Directors of Alaska Air Group, Inc.

Ms. Hood was appointed Executive Vice President and Chief Financial Officer in July 2013, subsequent to her appointment as Chief Financial Officer in May 2013. From 2010 to 2013, Ms. Hood was Chief Financial Officer of the Microsoft Business Division. Since joining Microsoft in 2002, Ms. Hood has also held finance-related positions in the Server and Tools Business and the corporate finance organization. Ms. Hood also serves on the Board of Directors of 3M Corporation.

Mr. Smith was appointed Vice Chair and President in September 2021. Prior to that, he served as President and Chief Legal Officer since September 2015. He served as Executive Vice President, General Counsel, and Secretary from 2011 to 2015, and served as Senior Vice President, General Counsel, and Secretary from 2001 to 2011. Mr. Smith was also named Chief Compliance Officer in 2002. Since joining Microsoft in 1993, he was Deputy General Counsel for Worldwide Sales and previously was responsible for managing the European Law and Corporate Affairs Group, based in Paris. Mr. Smith also serves on the Board of Directors of Netflix, Inc.

Mr. Young has served as Executive Vice President, Business Development, Strategy, and Ventures since joining Microsoft in November 2020. Prior to Microsoft, he served as the Chief Executive Officer of McAfee, LLC from 2017 to 2020, and served as a Senior Vice President and General Manager of Intel Security Group from 2014 until 2017, when he led the initiative to spin out McAfee into a standalone company. Mr. Young also serves on the Board of Directors of American Express Company.

21

PART I Item 1

AVAILABLE INFORMATION

Our Internet address is www.microsoft.com. At our Investor Relations website, www.microsoft.com/investor, we make available free of charge a variety of information for investors. Our goal is to maintain the Investor Relations website as a portal through which investors can easily find or navigate to pertinent information about us, including:

·Our annual report on Form 10-K, quarterly reports on Form 10-Q, current reports on Form 8-K, and any amendments to those reports, as soon as reasonably practicable after we electronically file that material with or furnish it to the Securities and Exchange Commission ("SEC") at www.sec.gov.

·Information on our business strategies, financial results, and metrics for investors.

·Announcements of investor conferences, speeches, and events at which our executives talk about our product, service, and competitive strategies. Archives of these events are also available.

·Press releases on quarterly earnings, product and service announcements, legal developments, and international news.

·Corporate governance information including our articles of incorporation, bylaws, governance guidelines, committee charters, codes of conduct and ethics, global corporate social responsibility initiatives, and other governance-related policies.

·Other news and announcements that we may post from time to time that investors might find useful or interesting.

·Opportunities to sign up for email alerts to have information pushed in real time.

We publish a variety of reports and resources related to our Corporate Social Responsibility programs and progress on our Reports Hub website, www.microsoft.com/corporate-responsibility/reports-hub, including reports on sustainability, responsible sourcing, accessibility, digital trust, and public policy engagement.

The information found on these websites is not part of, or incorporated by reference into, this or any other report we file with, or furnish to, the SEC. In addition to these channels, we use social media to communicate to the public. It is possible that the information we post on social media could be deemed to be material to investors. We encourage investors, the media, and others interested in Microsoft to review the information we post on the social media channels listed on our Investor Relations website.

22

PART I Item 1A

ITEM 1A. RISK FACTORS

Our operations and financial results are subject to various risks and uncertainties, including those described below, that could adversely affect our business, financial condition, results of operations, cash flows, and the trading price of our common stock.

## STRATEGIC AND COMPETITIVE RISKS

We face intense competition across all markets for our products and services, which may lead to lower revenue or operating margins.

## Competition in the technology sector

Our competitors range in size from diversified global companies with significant research and development resources to small, specialized firms whose narrower product lines may let them be more effective in deploying technical, marketing, and financial resources. Barriers to entry in many of our businesses are low and many of the areas in which we compete evolve rapidly with changing and disruptive technologies, shifting user needs, and frequent introductions of new products and services. Our ability to remain competitive depends on our success in making innovative products, devices, and services that appeal to businesses and consumers.

## Competition among platform-based ecosystems

An important element of our business model has been to create platform-based ecosystems on which many participants can build diverse solutions. A well-established ecosystem creates beneficial network effects among users, application developers, and the platform provider that can accelerate growth. Establishing significant scale in the marketplace is necessary to achieve and maintain attractive margins. We face significant competition from firms that provide competing platforms.

·A competing vertically-integrated model, in which a single firm controls the software and hardware elements of a product and related services, has succeeded with some consumer products such as personal computers, tablets, phones, gaming consoles, wearables, and other endpoint devices. Competitors pursuing this model also earn revenue from services integrated with the hardware and software platform, including applications and content sold through their integrated marketplaces. They may also be able to claim security and performance benefits from their vertically integrated offer. We also offer some vertically-integrated hardware and software products and services. To the extent we shift a portion of our business to a vertically integrated model we increase our cost of revenue and reduce our operating margins.

·We derive substantial revenue from licenses of Windows operating systems on PCs. We face significant competition from competing platforms developed for new devices and form factors such as smartphones and tablet computers. These devices compete on multiple bases including price and the perceived utility of the device and its platform. Users are increasingly turning to these devices to perform functions that in the past were performed by personal computers. Even if many users view these devices as complementary to a personal computer, the prevalence of these devices may make it more difficult to attract application developers to our PC operating system platforms. Competing with operating systems licensed at low or no cost may decrease our PC operating system margins. Popular products or services offered on competing platforms could increase their competitive strength. In addition, some of our devices compete with products made by our original equipment manufacturer ("OEM") partners, which may affect their commitment to our platform.

·Competing platforms have content and application marketplaces with scale and significant installed bases. The variety and utility of content and applications available on a platform are important to device purchasing decisions. Users may incur costs to move data and buy new content and applications when switching platforms. To compete, we must successfully enlist developers to write applications for our platform and ensure that these applications have high quality, security, customer appeal, and value. Efforts to compete with competitors' content and application marketplaces may increase our cost of revenue and lower our operating margins. Competitors' rules governing their content and applications marketplaces may restrict our ability to distribute products and services through them in accordance with our technical and business model objectives.

23

PART I Item 1A

## Business model competition

Companies compete with us based on a growing variety of business models.

·Even as we transition more of our business to infrastructure-, platform-, and software-as-a-service business model, the license-based proprietary software model generates a substantial portion of our software revenue. We bear the costs of converting original ideas into software products through investments in research and development, offsetting these costs with the revenue received from licensing our products. Many of our competitors also develop and sell software to businesses and consumers under this model.

·We are investing in artificial intelligence ("Al") across the entire company and infusing generative Al capabilities into our consumer and commercial offerings. We expect Al technology and services to be a highly competitive and rapidly evolving market. We will bear significant development and operational costs to build and support the Al capabilities, products, and services necessary to meet the needs of our customers. To compete effectively we must also be responsive to technological change, potential regulatory developments, and public scrutiny.

·Other competitors develop and offer free applications, online services, and content, and make money by selling third-party advertising. Advertising revenue funds development of products and services these competitors provide to users at no or little cost, competing directly with our revenue-generating products.

·Some companies compete with us by modifying and then distributing open source software at little or no cost to end users, using open source Al models, and earning revenue on advertising or integrated products and services. These firms do not bear the full costs of research and development for the open source products. Some open source products mimic the features and functionality of our products.

The competitive pressures described above may cause decreased sales volumes, price reductions, and/or increased operating costs, such as for research and development, marketing, and sales incentives. This may lead to lower revenue, gross margins, and operating income.

Our increasing focus on cloud-based services presents execution and competitive risks. A growing part of our business involves cloud-based services available across the spectrum of computing devices. Our strategic vision is to compete and grow by building best-in-class platforms and productivity services that utilize ubiquitous computing and ambient intelligence to drive insights and productivity gains. At the same time, our competitors are rapidly developing and deploying cloud-based services for consumers and business customers. Pricing and delivery models are evolving. Devices and form factors influence how users access services in the cloud and sometimes the user's choice of which cloud-based services to use. Certain industries and customers have specific requirements for cloud services and may present enhanced risks. We are devoting significant resources to develop and deploy our cloud-based strategies. The Windows ecosystem must continue to evolve with this changing environment. We embrace cultural and organizational changes to drive accountability and eliminate obstacles to innovation. Our intelligent cloud and intelligent edge offerings are connected to the growth of the Internet of Things ("loT"), a network of distributed and interconnected devices employing sensors, data, and computing capabilities, including Al. Our success in driving ubiquitous computing and ambient intelligence will depend on the level of adoption of our offerings such as Azure, Azure Al, and Azure loT Edge. We may not establish market share sufficient to achieve scale necessary to meet our business objectives.

Besides software development costs, we are incurring costs to build and maintain infrastructure to support cloud computing services. These costs will reduce the operating margins we have previously achieved. Whether we succeed in cloud-based services depends on our execution in several areas, including:

.Continuing to bring to market compelling cloud-based experiences that generate increasing traffic and market share.

·Maintaining the utility, compatibility, and performance of our cloud-based services on the growing array of computing devices, including PCs, smartphones, tablets, gaming consoles, and other devices, as well as sensors and other loT endpoints.

.Continuing to enhance the attractiveness of our cloud platforms to third-party developers.

·Ensuring our cloud-based services meet the reliability expectations of our customers and maintain the security of their data as well as help them meet their own compliance needs.

·Making our suite of cloud-based services platform-agnostic, available on a wide range of devices and ecosystems, including those of our competitors.

24

PART I Item 1A

It is uncertain whether our strategies will attract the users or generate the revenue required to succeed. If we are not effective in executing organizational and technical changes to increase efficiency and accelerate innovation, or if we fail to generate sufficient usage of our new products and services, we may not grow revenue in line with the infrastructure and development investments described above. This may negatively impact gross margins and operating income.

Some users may engage in fraudulent or abusive activities through our cloud-based services. These include unauthorized use of accounts through stolen credentials, use of stolen credit cards or other payment vehicles, failure to pay for services accessed, or other activities that violate our terms of service such as cryptocurrency mining or launching cyberattacks. If our efforts to detect such violations or our actions to control these types of fraud and abuse are not effective, we may experience adverse impacts to our revenue or incur reputational damage.

## RISKS RELATING TO THE EVOLUTION OF OUR BUSINESS

We make significant investments in products and services that may not achieve expected returns. We will continue to make significant investments in research, development, and marketing for existing products, services, and technologies, including the Windows operating system, Microsoft 365, Bing, SQL Server, Windows Server, Azure, Office 365, Xbox, LinkedIn, and other products and services. In addition, we are focused on developing new Al platform services and incorporating Al into existing products and services. We also invest in the development and acquisition of a variety of hardware for productivity, communication, and entertainment, including PCs, tablets, gaming devices, and HoloLens. Investments in new technology are speculative. Commercial success depends on many factors, including innovativeness, developer support, and effective distribution and marketing. If customers do not perceive our latest offerings as providing significant new functionality or other value, they may reduce their purchases of new software and hardware products or upgrades, unfavorably affecting revenue. We may not achieve significant revenue from new product, service, and distribution channel investments for several years, if at all. New products and services may not be profitable, and even if they are profitable, operating margins for some new products and businesses will not be as high as the margins we have experienced historically. We may not get engagement in certain features, like Microsoft Edge, Bing, and Bing Chat, that drive post-sale monetization opportunities. Our data handling practices across our products and services will continue to be under scrutiny. Perceptions of mismanagement, driven by regulatory activity or negative public reaction to our practices or product experiences, could negatively impact product and feature adoption, product design, and product quality.

Developing new technologies is complex. It can require long development and testing periods. Significant delays in new releases or significant problems in creating new products or services could adversely affect our revenue.

Acquisitions, joint ventures, and strategic alliances may have an adverse effect on our business. We expect to continue making acquisitions and entering into joint ventures and strategic alliances as part of our long-term business strategy. For example, in March 2021 we completed our acquisition of ZeniMax Media Inc. for $8.1 billion, and in March 2022 we completed our acquisition of Nuance Communications, Inc. for $18.8 billion. In January 2022 we announced a definitive agreement to acquire Activision Blizzard, Inc. for $68.7 billion. In January 2023 we announced the third phase of our OpenAl strategic partnership. Acquisitions and other transactions and arrangements involve significant challenges and risks, including that they do not advance our business strategy, that we get an unsatisfactory return on our investment, that they raise new compliance-related obligations and challenges, that we have difficulty integrating and retaining new employees, business systems, and technology, that they distract management from our other businesses, or that announced transactions may not be completed. If an arrangement fails to adequately anticipate changing circumstances and interests of a party, it may result in early termination or renegotiation of the arrangement. The success of these transactions and arrangements will depend in part on our ability to leverage them to enhance our existing products and services or develop compelling new ones, as well as acquired companies' ability to meet our policies and processes in areas such as data governance, privacy, and cybersecurity. It may take longer than expected to realize the full benefits from these transactions and arrangements such as increased revenue or enhanced efficiencies, or the benefits may ultimately be smaller than we expected. These events could adversely affect our consolidated financial statements.

25

PART I Item 1A

If our goodwill or amortizable intangible assets become impaired, we may be required to record a significant charge to earnings. We acquire other companies and intangible assets and may not realize all the economic benefit from those acquisitions, which could cause an impairment of goodwill or intangibles. We review our amortizable intangible assets for impairment when events or changes in circumstances indicate the carrying value may not be recoverable. We test goodwill for impairment at least annually. Factors that may be a change in circumstances, indicating that the carrying value of our goodwill or amortizable intangible assets may not be recoverable, include a decline in our stock price and market capitalization, reduced future cash flow estimates, and slower growth rates in industry segments in which we participate. We have in the past recorded, and may in the future be required to record, a significant charge in our consolidated financial statements during the period in which any impairment of our goodwill or amortizable intangible assets is determined, negatively affecting our results of operations.

## CYBERSECURITY, DATA PRIVACY, AND PLATFORM ABUSE RISKS

Cyberattacks and security vulnerabilities could lead to reduced revenue, increased costs, liability claims, or harm to our reputation or competitive position.

## Security of our information technology

Threats to IT security can take a variety of forms. Individual and groups of hackers and sophisticated organizations, including state-sponsored organizations or nation-states, continuously undertake attacks that pose threats to our customers and our IT. These actors may use a wide variety of methods, which may include developing and deploying malicious software or exploiting vulnerabilities or intentionally designed processes in hardware, software, or other infrastructure in order to attack our products and services or gain access to our networks and datacenters, using social engineering techniques to induce our employees, users, partners, or customers to disclose passwords or other sensitive information or take other actions to gain access to our data or our users' or customers' data, or acting in a coordinated manner to launch distributed denial of service or other coordinated attacks. Nation-state and state-sponsored actors can deploy significant resources to plan and carry out attacks. Nation-state attacks against us, our customers, or our partners may intensify during periods of intense diplomatic or armed conflict, such as the ongoing conflict in Ukraine. Inadequate account security or organizational security practices may also result in unauthorized access to confidential data. For example, system administrators may fail to timely remove employee account access when no longer appropriate. Employees or third parties may intentionally compromise our or our users' security or systems or reveal confidential information. Malicious actors may employ the IT supply chain to introduce malware through software updates or compromised supplier accounts or hardware.

Cyberthreats are constantly evolving and becoming increasingly sophisticated and complex, increasing the difficulty of detecting and successfully defending against them. We may have no current capability to detect certain vulnerabilities or new attack methods, which may allow them to persist in the environment over long periods of time. Cyberthreats can have cascading impacts that unfold with increasing speed across our internal networks and systems and those of our partners and customers. Breaches of our facilities, network, or data security could disrupt the security of our systems and business applications, impair our ability to provide services to our customers and protect the privacy of their data, result in product development delays, compromise confidential or technical business information harming our reputation or competitive position, result in theft or misuse of our intellectual property or other assets, subject us to ransomware attacks, require us to allocate more resources to improve technologies or remediate the impacts of attacks, or otherwise adversely affect our business. We are also subject to supply chain cyberattacks where malware can be introduced to a software provider's customers, including us, through software updates.

In addition, our internal IT environment continues to evolve. Often, we are early adopters of new devices and technologies. We embrace new ways of sharing data and communicating internally and with partners and customers using methods such as social networking and other consumer-oriented technologies. Increasing use of generative Al models in our internal systems may create new attack methods for adversaries. Our business policies and internal security controls may not keep pace with these changes as new threats emerge, or emerging cybersecurity regulations in jurisdictions worldwide.

26

PART I Item 1A

## Security of our products, services, devices, and customers' data

The security of our products and services is important in our customers' decisions to purchase or use our products or services across cloud and on- premises environments. Security threats are a significant challenge to companies like us whose business is providing technology products and services to others. Threats to our own IT infrastructure can also affect our customers. Customers using our cloud-based services rely on the security of our infrastructure, including hardware and other elements provided by third parties, to ensure the reliability of our services and the protection of their data. Adversaries tend to focus their efforts on the most popular operating systems, programs, and services, including many of ours, and we expect that to continue. In addition, adversaries can attack our customers' on-premises or cloud environments, sometimes exploiting previously unknown ("zero day") vulnerabilities, such as occurred in early calendar year 2021 with several of our Exchange Server on-premises products. Vulnerabilities in these or any product can persist even after we have issued security patches if customers have not installed the most recent updates, or if the attackers exploited the vulnerabilities before patching to install additional malware to further compromise customers' systems. Adversaries will continue to attack customers using our cloud services as customers embrace digital transformation. Adversaries that acquire user account information can use that information to compromise our users' accounts, including where accounts share the same attributes such as passwords. Inadequate account security practices may also result in unauthorized access, and user activity may result in ransomware or other malicious software impacting a customer's use of our products or services. We are increasingly incorporating open source software into our products. There may be vulnerabilities in open source software that may make our products susceptible to cyberattacks. Additionally, we are actively adding new generative Al features to our services. Because generative Al is a new field, understanding of security risks and protection methods continues to develop; features that rely on generative Al may be susceptible to unanticipated security threats from sophisticated adversaries.

Our customers operate complex IT systems with third-party hardware and software from multiple vendors that may include systems acquired over many years. They expect our products and services to support all these systems and products, including those that no longer incorporate the strongest current security advances or standards. As a result, we may not be able to discontinue support in our services for a product, service, standard, or feature solely because a more secure alternative is available. Failure to utilize the most current security advances and standards can increase our customers' vulnerability to attack. Further, customers of widely varied size and technical sophistication use our technology, and consequently may still have limited capabilities and resources to help them adopt and implement state of the art cybersecurity practices and technologies. In addition, we must account for this wide variation of technical sophistication when defining default settings for our products and services, including security default settings, as these settings may limit or otherwise impact other aspects of IT operations and some customers may have limited capability to review and reset these defaults.

Cyberattacks may adversely impact our customers even if our production services are not directly compromised. We are committed to notifying our customers whose systems have been impacted as we become aware and have actionable information for customers to help protect themselves. We are also committed to providing guidance and support on detection, tracking, and remediation. We may not be able to detect the existence or extent of these attacks for all of our customers or have information on how to detect or track an attack, especially where an attack involves on-premises software such as Exchange Server where we may have no or limited visibility into our customers' computing environments.

## Development and deployment of defensive measures

To defend against security threats to our internal IT systems, our cloud-based services, and our customers' systems, we must continuously engineer more secure products and services, enhance security, threat detection, and reliability features, improve the deployment of software updates to address security vulnerabilities in our own products as well as those provided by others, develop mitigation technologies that help to secure customers from attacks even when software updates are not deployed, maintain the digital security infrastructure that protects the integrity of our network, products, and services, and provide security tools such as firewalls, anti-virus software, and advanced security and information about the need to deploy security measures and the impact of doing so. Customers in certain industries such as financial services, health care, and government may have enhanced or specialized requirements to which we must engineer our products and services.

27

PART I Item 1A

The cost of measures to protect products and customer-facing services could reduce our operating margins. If we fail to do these things well, actual or perceived security vulnerabilities in our products and services, data corruption issues, or reduced performance could harm our reputation and lead customers to reduce or delay future purchases of products or subscriptions to services, or to use competing products or services. Customers may also spend more on protecting their existing computer systems from attack, which could delay adoption of additional products or services. Customers, and third parties granted access to their systems, may fail to update their systems, continue to run software or operating systems we no longer support, or may fail timely to install or enable security patches, or may otherwise fail to adopt adequate security practices. Any of these could adversely affect our reputation and revenue. Actual or perceived vulnerabilities may lead to claims against us. Our license agreements typically contain provisions that eliminate or limit our exposure to liability, but there is no assurance these provisions will withstand legal challenges. At times, to achieve commercial objectives, we may enter into agreements with larger liability exposure to customers.

Our products operate in conjunction with and are dependent on products and components across a broad ecosystem of third parties. If there is a security vulnerability in one of these components, and if there is a security exploit targeting it, we could face increased costs, liability claims, reduced revenue, or harm to our reputation or competitive position.

Disclosure and misuse of personal data could result in liability and harm our reputation. As we continue to grow the number, breadth, and scale of our cloud-based offerings, we store and process increasingly large amounts of personal data of our customers and users. The continued occurrence of high-profile data breaches provides evidence of an external environment increasingly hostile to information security. Despite our efforts to improve the security controls across our business groups and geographies, it is possible our security controls over personal data, our training of employees and third parties on data security, and other practices we follow may not prevent the improper disclosure or misuse of customer or user data we or our vendors store and manage. In addition, third parties who have limited access to our customer or user data may use this data in unauthorized ways. Improper disclosure or misuse could harm our reputation, lead to legal exposure to customers or users, or subject us to liability under laws that protect personal data, resulting in increased costs or loss of revenue. Our software products and services also enable our customers and users to store and process personal data on-premises or, increasingly, in a cloud-based environment we host. Government authorities can sometimes require us to produce customer or user data in response to valid legal orders. In the U.S. and elsewhere, we advocate for transparency concerning these requests and appropriate limitations on government authority to compel disclosure. Despite our efforts to protect customer and user data, perceptions that the collection, use, and retention of personal information is not satisfactorily protected could inhibit sales of our products or services and could limit adoption of our cloud-based solutions by consumers, businesses, and government entities. Additional security measures we may take to address customer or user concerns, or constraints on our flexibility to determine where and how to operate datacenters in response to customer or user expectations or governmental rules or actions, may cause higher operating expenses or hinder growth of our products and services.

We may not be able to protect information in our products and services from use by others. Linkedln and other Microsoft products and services contain valuable information and content protected by contractual restrictions or technical measures. In certain cases, we have made commitments to our members and users to limit access to or use of this information. Changes in the law or interpretations of the law may weaken our ability to prevent third parties from scraping or gathering information or content through use of bots or other measures and using it for their own benefit, thus diminishing the value of our products and services.

## Advertising, professional, marketplace, and gaming platform abuses

For platform products and services that provide content or host ads that come from or can be influenced by third parties, including GitHub, Linkedln, Microsoft Advertising, Microsoft News, Microsoft Store, Bing, and Xbox, our reputation or user engagement may be negatively affected by activity that is hostile or inappropriate. This activity may come from users impersonating other people or organizations including through the use of Al technologies, dissemination of information that may be viewed as misleading or intended to manipulate the opinions of our users, or the use of our products or services that violates our terms of service or otherwise for objectionable or illegal ends. Preventing or responding to these actions may require us to make substantial investments in people and technology and these investments may not be successful, adversely affecting our business and consolidated financial statements.

28

PART I Item 1A

## Other digital safety abuses

Our hosted consumer services as well as our enterprise services may be used to generate or disseminate harmful or illegal content in violation of our terms or applicable law. We may not proactively discover such content due to scale, the limitations of existing technologies, and conflicting legal frameworks. When discovered by users and others, such content may negatively affect our reputation, our brands, and user engagement. Regulations and other initiatives to make platforms responsible for preventing or eliminating harmful content online have been enacted, and we expect this to continue. We may be subject to enhanced regulatory oversight, civil or criminal liability, or reputational damage if we fail to comply with content moderation regulations, adversely affecting our business and consolidated financial statements.

The development of the loT presents security, privacy, and execution risks. To support the growth of the intelligent cloud and the intelligent edge, we are developing products, services, and technologies to power the loT. The loT's great potential also carries substantial risks. IoT products and services may contain defects in design, manufacture, or operation that make them insecure or ineffective for their intended purposes. An loT solution has multiple layers of hardware, sensors, processors, software, and firmware, several of which we may not develop or control. Each layer, including the weakest layer, can impact the security of the whole system. Many loT devices have limited interfaces and ability to be updated or patched. loT solutions may collect large amounts of data, and our handling of loT data may not satisfy customers or regulatory requirements. loT scenarios may increasingly affect personal health and safety. If loT solutions that include our technologies do not work as intended, violate the law, or harm individuals or businesses, we may be subject to legal claims or enforcement actions. These risks, if realized, may increase our costs, damage our reputation or brands, or negatively impact our revenues or margins.

Issues in the development and use of Al may result in reputational or competitive harm or liability. We are building Al into many of our offerings, including our productivity services, and we are also making Al available for our customers to use in solutions that they build. This Al may be developed by Microsoft or others, including our strategic partner, OpenAl. We expect these elements of our business to grow. We envision a future in which Al operating in our devices, applications, and the cloud helps our customers be more productive in their work and personal lives. As with many innovations, Al presents risks and challenges that could affect its adoption, and therefore our business. Al algorithms or training methodologies may be flawed. Datasets may be overbroad, insufficient, or contain biased information. Content generated by Al systems may be offensive, illegal, or otherwise harmful. Ineffective or inadequate Al development or deployment practices by Microsoft or others could result in incidents that impair the acceptance of Al solutions or cause harm to individuals, customers, or society, or result in our products and services not working as intended. Human review of certain outputs may be required. As a result of these and other challenges associated with innovative technologies, our implementation of Al systems could subject us to competitive harm, regulatory action, legal liability, including under new proposed legislation regulating Al in jurisdictions such as the European Union ("EU"), new applications of existing data protection, privacy, intellectual property, and other laws, and brand or reputational harm. Some Al scenarios present ethical issues or may have broad impacts on society. If we enable or offer Al solutions that have unintended consequences, unintended usage or customization by our customers and partners, or are controversial because of their impact on human rights, privacy, employment, or other social, economic, or political issues, we may experience brand or reputational harm, adversely affecting our business and consolidated financial statements.

29

PART I Item 1A

## OPERATIONAL RISKS

We may have excessive outages, data losses, and disruptions of our online services if we fail to maintain an adequate operations infrastructure. Our increasing user traffic, growth in services, and the complexity of our products and services demand more computing power. We spend substantial amounts to build, purchase, or lease datacenters and equipment and to upgrade our technology and network infrastructure to handle more traffic on our websites and in our datacenters. Our datacenters depend on the availability of permitted and buildable land, predictable energy, networking supplies, and servers, including graphics processing units ("GPUs") and other components. The cost or availability of these dependencies could be adversely affected by a variety of factors, including the transition to a clean energy economy, local and regional environmental regulations, and geopolitical disruptions. These demands continue to increase as we introduce new products and services and support the growth and the augmentation of existing services such as Bing, Azure, Microsoft Account services, Microsoft 365, Microsoft Teams, Dynamics 365, OneDrive, SharePoint Online, Skype, Xbox, and Outlook.com through the incorporation of Al features and/or functionality. We are rapidly growing our business of providing a platform and back-end hosting for services provided by third parties to their end users. Maintaining, securing, and expanding this infrastructure is expensive and complex, and requires development of principles for datacenter builds in geographies with higher safety and reliability risks. It requires that we maintain an Internet connectivity infrastructure and storage and compute capacity that is robust and reliable within competitive and regulatory constraints that continue to evolve. Inefficiencies or operational failures, including temporary or permanent loss of customer data, insufficient Internet connectivity, insufficient or unavailable power supply, or inadequate storage and compute capacity, could diminish the quality of our products, services, and user experience resulting in contractual liability, claims by customers and other third parties, regulatory actions, damage to our reputation, and loss of current and potential users, subscribers, and advertisers, each of which may adversely impact our consolidated financial statements.

We may experience quality or supply problems. Our hardware products such as Xbox consoles, Surface devices, and other devices we design and market are highly complex and can have defects in design, manufacture, or associated software. We could incur significant expenses, lost revenue, and reputational harm as a result of recalls, safety alerts, or product liability claims if we fail to prevent, detect, or address such issues through design, testing, or warranty repairs.

Our software products and services also may experience quality or reliability problems. The highly sophisticated software we develop may contain bugs and other defects that interfere with their intended operation. Our customers increasingly rely on us for critical business functions and multiple workloads. Many of our products and services are interdependent with one another. Each of these circumstances potentially magnifies the impact of quality or reliability issues. Any defects we do not detect and fix in pre-release testing could cause reduced sales and revenue, damage to our reputation, repair or remediation costs, delays in the release of new products or versions, or legal liability. Although our license agreements typically contain provisions that eliminate or limit our exposure to liability, there is no assurance these provisions will withstand legal challenge.

There are limited suppliers for certain device and datacenter components. Our competitors use some of the same suppliers and their demand for hardware components can affect the capacity available to us. If components are delayed or become unavailable, whether because of supplier capacity constraint, industry shortages, legal or regulatory changes that restrict supply sources, or other reasons, we may not obtain timely replacement supplies, resulting in reduced sales or inadequate datacenter capacity to support the delivery and continued development of our products and services. Component shortages, excess or obsolete inventory, or price reductions resulting in inventory adjustments may increase our cost of revenue. Xbox consoles, Surface devices, datacenter servers, and other hardware are assembled in Asia and other geographies that may be subject to disruptions in the supply chain, resulting in shortages that would affect our revenue and operating margins.

## LEGAL, REGULATORY, AND LITIGATION RISKS

Government litigation and regulatory activity relating to competition rules may limit how we design and market our products. Government agencies closely scrutinize us under U.S. and foreign competition laws. Governments are actively enforcing competition laws and regulations, and this includes scrutiny in potentially large markets such as the EU, the U.S., and China. Some jurisdictions also allow competitors or consumers to assert claims of anti-competitive conduct. U.S. federal and state antitrust authorities have previously brought enforcement actions and continue to scrutinize our business.

30

PART I Item 1A

For example, the European Commission ("the Commission") closely scrutinizes the design of high-volume Microsoft products and the terms on which we make certain technologies used in these products, such as file formats, programming interfaces, and protocols, available to other companies. Flagship product releases such as Windows can receive significant scrutiny under EU or other competition laws.

Our portfolio of first-party devices continues to grow; at the same time our OEM partners offer a large variety of devices for our platforms. As a result, increasingly we both cooperate and compete with our OEM partners, creating a risk that we fail to do so in compliance with competition rules. Regulatory scrutiny in this area may increase. Certain foreign governments, particularly in China and other countries in Asia, have advanced arguments under their competition laws that exert downward pressure on royalties for our intellectual property.

Competition law regulatory actions and court decisions may result in fines or hinder our ability to provide the benefits of our software to consumers and businesses, reducing the attractiveness of our products and the revenue that comes from them. New competition law actions could be initiated, potentially using previous actions as precedent. The outcome of such actions, or steps taken to avoid them, could adversely affect us in a variety of ways, including causing us to withdraw products from or modify products for certain markets, decreasing the value of our assets, adversely affecting our ability to monetize our products, or inhibiting our ability to consummate acquisition or impose conditions on acquisitions that may reduce their value.

Laws and regulations relating to anti-corruption and trade could result in increased costs, fines, criminal penalties, or reputational damage. The Foreign Corrupt Practices Act ("FCPA") and other anti-corruption laws and regulations ("Anti-Corruption Laws") prohibit corrupt payments by our employees, vendors, or agents, and the accounting provisions of the FCPA require us to maintain accurate books and records and adequate internal controls. From time to time, we receive inquiries from authorities in the U.S. and elsewhere which may be based on reports from employees and others about our business activities outside the U.S. and our compliance with Anti-Corruption Laws. Periodically, we receive such reports directly and investigate them, and also cooperate with investigations by U.S. and foreign law enforcement authorities. An example of increasing international regulatory complexity is the EU Whistleblower Directive, initiated in 2021, which may present compliance challenges to the extent it is implemented in different forms by EU member states. Most countries in which we operate also have competition laws that prohibit competitors from colluding or otherwise attempting to reduce competition between themselves. While we devote substantial resources to our U.S. and international compliance programs and have implemented policies, training, and internal controls designed to reduce the risk of corrupt payments and collusive activity, our employees, vendors, or agents may violate our policies. Our failure to comply with Anti-Corruption Laws or competition laws could result in significant fines and penalties, criminal sanctions against us, our officers, or our employees, prohibitions on the conduct of our business, and damage to our reputation.

Increasing trade laws, policies, sanctions, and other regulatory requirements also affect our operations in and outside the U.S. relating to trade and investment. Economic sanctions in the U.S., the EU, and other countries prohibit most business with restricted entities or countries. U.S. export controls restrict Microsoft from offering many of its products and services to, or making investments in, certain entities in specified countries. U.S. import controls restrict us from integrating certain information and communication technologies into our supply chain and allow for government review of transactions involving information and communications technology from countries determined to be foreign adversaries. Supply chain regulations may impact the availability of goods or result in additional regulatory scrutiny. Periods of intense diplomatic or armed conflict, such as the ongoing conflict in Ukraine, may result in (1) new and rapidly evolving sanctions and trade restrictions, which may impair trade with sanctioned individuals and countries, and (2) negative impacts to regional trade ecosystems among our customers, partners, and us. Non-compliance with sanctions as well as general ecosystem disruptions could result in reputational harm, operational delays, monetary fines, loss of revenues, increased costs, loss of export privileges, or criminal sanctions.

31

PART I Item 1A

Laws and regulations relating to the handling of personal data may impede the adoption of our services or result in increased costs, legal claims, fines against us, or reputational damage. The growth of our Internet- and cloud-based services internationally relies increasingly on the movement of data across national boundaries. Legal requirements relating to the collection, storage, handling, and transfer of personal data continue to evolve. For example, while the EU-U.S. Data Privacy Framework ("DPF") has been recognized as adequate under EU law to allow transfers of personal data from the EU to certified companies in the U.S., the DPF is subject to further legal challenge which could cause the legal requirements for data transfers from the EU to be uncertain. EU data protection authorities have and may again block the use of certain U.S .- based services that involve the transfer of data to the U.S. In the EU and other markets, potential new rules and restrictions on the flow of data across borders could increase the cost and complexity of delivering our products and services.

In addition, the EU General Data Protection Regulation ("GDPR"), which applies to all of our activities conducted from an establishment in the EU or related to products and services offered in the EU, imposes a range of compliance obligations regarding the handling of personal data. More recently, the EU has been developing new requirements related to the use of data, including in the Digital Markets Act, the Digital Services Act, and the Data Act, that add additional rules and restriction on the use of data in our products and services. Engineering efforts to build and maintain capabilities to facilitate compliance with these laws involve substantial expense and the diversion of engineering resources from other projects. We might experience reduced demand for our offerings if we are unable to engineer products that meet our legal duties or help our customers meet their obligations under these and other data regulations, or if our implementation to comply makes our offerings less attractive. Compliance with these obligations depends in part on how particular regulators interpret and apply them. If we fail to comply, or if regulators assert we have failed to comply (including in response to complaints made by customers), it may lead to regulatory enforcement actions, which can result in significant monetary penalties, private lawsuits, reputational damage, blockage of international data transfers, and loss of customers. The highest fines assessed under GDPR have recently been increasing, especially against large technology companies. Jurisdictions around the world, such as China, India, and states in the U.S. have adopted, or are considering adopting or expanding, laws and regulations imposing obligations regarding the collection, handling, and transfer of personal data.

Our investment in gaining insights from data is becoming central to the value of the services, including Al services, we deliver to customers, to operational efficiency and key opportunities in monetization, and to customer perceptions of quality. Our ability to use data in this way may be constrained by regulatory developments that impede realizing the expected return from this investment. Ongoing legal analyses, reviews, and inquiries by regulators of Microsoft practices, or relevant practices of other organizations, may result in burdensome or inconsistent requirements, including data sovereignty and localization requirements, affecting the location, movement, collection, and use of our customer and internal employee data as well as the management of that data. Compliance with applicable laws and regulations regarding personal data may require changes in services, business practices, or internal systems that result in increased costs, lower revenue, reduced efficiency, or greater difficulty in competing with foreign-based firms. Compliance with data regulations might limit our ability to innovate or offer certain features and functionality in some jurisdictions where we operate. Failure to comply with existing or new rules may result in significant penalties or orders to stop the alleged noncompliant activity, as well as negative publicity and diversion of management time and effort.

Existing and increasing legal and regulatory requirements could adversely affect our results of operations. We are subject to a wide range of laws, regulations, and legal requirements in the U.S. and globally, including those that may apply to our products and online services offerings, and those that impose requirements related to user privacy, telecommunications, data storage and protection, advertising, and online content. Laws in several jurisdictions, including EU Member State laws under the European Electronic Communications Code, increasingly define certain of our services as regulated telecommunications services. This trend may continue and will result in these offerings being subjected to additional data protection, security, law enforcement surveillance, and other obligations. Regulators and private litigants may assert that our collection, use, and management of customer data and other information is inconsistent with their laws and regulations, including laws that apply to the tracking of users via technology such as cookies. New environmental, social, and governance laws and regulations are expanding mandatory disclosure, reporting, and diligence requirements. Legislative or regulatory action relating to cybersecurity requirements may increase the costs to develop, implement, or secure our products and services. Compliance with evolving digital accessibility laws and standards will require engineering and is important to our efforts to empower all people and organizations to achieve more. Legislative and regulatory action is emerging in the areas of Al and content moderation, which could increase costs or restrict opportunity. For example, in the EU, an Al Act is being considered, and may entail increased costs or decreased opportunities for the operation of our Al services in the European market.

32

PART I Item 1A

How these laws and regulations apply to our business is often unclear, subject to change over time, and sometimes may be inconsistent from jurisdiction to jurisdiction. In addition, governments' approach to enforcement, and our products and services, are continuing to evolve. Compliance with existing, expanding, or new laws and regulations may involve significant costs or require changes in products or business practices that could adversely affect our results of operations. Noncompliance could result in the imposition of penalties or orders we cease the alleged noncompliant activity. In addition, there is increasing pressure from advocacy groups, regulators, competitors, customers, and other stakeholders across many of these areas. If our products do not meet customer expectations or legal requirements, we could lose sales opportunities or face regulatory or legal actions.

We have claims and lawsuits against us that may result in adverse outcomes. We are subject to a variety of claims and lawsuits. These claims may arise from a wide variety of business practices and initiatives, including major new product releases such as Windows, Al services, significant business transactions, warranty or product claims, employment practices, and regulation. Adverse outcomes in some or all of these claims may result in significant monetary damages or injunctive relief that could adversely affect our ability to conduct our business. The litigation and other claims are subject to inherent uncertainties and management's view of these matters may change in the future. A material adverse impact in our consolidated financial statements could occur for the period in which the effect of an unfavorable outcome becomes probable and reasonably estimable.

Our business with government customers may present additional uncertainties. We derive substantial revenue from government contracts. Government contracts generally can present risks and challenges not present in private commercial agreements. For instance, we may be subject to government audits and investigations relating to these contracts, we could be suspended or debarred as a governmental contractor, we could incur civil and criminal fines and penalties, and under certain circumstances contracts may be rescinded. Some agreements may allow a government to terminate without cause and provide for higher liability limits for certain losses. Some contracts may be subject to periodic funding approval, reductions, cancellations, or delays which could adversely impact public-sector demand for our products and services. These events could negatively impact our results of operations, financial condition, and reputation.

We may have additional tax liabilities. We are subject to income taxes in the U.S. and many foreign jurisdictions. Significant judgment is required in determining our worldwide provision for income taxes. In the course of our business, there are many transactions and calculations where the ultimate tax determination is uncertain. For example, compliance with the 2017 United States Tax Cuts and Jobs Act ("TCJA") and possible future legislative changes may require the collection of information not regularly produced within the company, the use of estimates in our consolidated financial statements, and the exercise of significant judgment in accounting for its provisions. As regulations and guidance evolve with respect to the TCJA or possible future legislative changes, and as we gather more information and perform more analysis, our results may differ from previous estimates and may materially affect our consolidated financial statements.

We are regularly under audit by tax authorities in different jurisdictions. Although we believe that our provision for income taxes and our tax estimates are reasonable, tax authorities may disagree with certain positions we have taken. In addition, economic and political pressures to increase tax revenue in various jurisdictions may make resolving tax disputes favorably more difficult. We are currently under Internal Revenue Service audit for prior tax years, with the primary unresolved issues relating to transfer pricing. The final resolution of those audits, and other audits or litigation, may differ from the amounts recorded in our consolidated financial statements and may materially affect our consolidated financial statements in the period or periods in which that determination is made.

We earn a significant amount of our operating income outside the U.S. A change in the mix of earnings and losses in countries with differing statutory tax rates, changes in our business or structure, or the expiration of or disputes about certain tax agreements in a particular country may result in higher effective tax rates for the company. In addition, changes in U.S. federal and state or international tax laws applicable to corporate multinationals, other fundamental law changes currently being considered by many countries, including in the U.S., and changes in taxing jurisdictions' administrative interpretations, decisions, policies, and positions may materially adversely impact our consolidated financial statements.

33

PART I Item 1A

INTELLECTUAL PROPERTY RISKS

We face risks related to the protection and utilization of our intellectual property that may result in our business and operating results may be harmed. Protecting our intellectual property rights and combating unlicensed copying and use of our software and other intellectual property on a global basis is difficult. Similarly, the absence of harmonized patent laws makes it more difficult to ensure consistent respect for patent rights.

Changes in the law may continue to weaken our ability to prevent the use of patented technology or collect revenue for licensing our patents. Additionally, licensees of our patents may fail to satisfy their obligations to pay us royalties or may contest the scope and extent of their obligations. Finally, our increasing engagement with open source software will also cause us to license our intellectual property rights broadly in certain situations. If we are unable to protect our intellectual property, our revenue may be adversely affected.

Source code, the detailed program commands for our operating systems and other software programs, is critical to our business. If our source code leaks, we might lose future trade secret protection for that code. It may then become easier for third parties to compete with our products by copying functionality, which could adversely affect our revenue and operating results. Unauthorized disclosure of source code also could increase the security risks described elsewhere in these risk factors.

Third parties may claim that we infringe their intellectual property. From time to time, others claim we infringe their intellectual property rights. To resolve these claims, we may enter into royalty and licensing agreements on terms that are less favorable than currently available, stop selling or redesign affected products or services, or pay damages to satisfy indemnification commitments with our customers. Adverse outcomes could also include monetary damages or injunctive relief that may limit or prevent importing, marketing, and selling our products or services that have infringing technologies. We have paid significant amounts to settle claims related to the use of technology and intellectual property rights and to procure intellectual property rights as part of our strategy to manage this risk, and may continue to do so.

## GENERAL RISKS

If our reputation or our brands are damaged, our business and operating results may be harmed. Our reputation and brands are globally recognized and are important to our business. Our reputation and brands affect our ability to attract and retain consumer, business, and public-sector customers. There are numerous ways our reputation or brands could be damaged. These include product safety or quality issues, our environmental impact and sustainability, supply chain practices, or human rights record. We may experience backlash from customers, government entities, advocacy groups, employees, and other stakeholders that disagree with our product offering decisions or public policy positions. Damage to our reputation or our brands may occur from, among other things:

· The introduction of new features, products, services, or terms of service that customers, users, or partners do not like.

·Public scrutiny of our decisions regarding user privacy, data practices, or content.

·Data security breaches, compliance failures, or actions of partners or individual employees.

The proliferation of social media may increase the likelihood, speed, and magnitude of negative brand events. If our brands or reputation are damaged, it could negatively impact our revenues or margins, or ability to attract the most highly qualified employees.

Adverse economic or market conditions may harm our business. Worsening economic conditions, including inflation, recession, pandemic, or other changes in economic conditions, may cause lower IT spending and adversely affect our revenue. If demand for PCs, servers, and other computing devices declines, or consumer or business spending for those products declines, our revenue will be adversely affected.

Our product distribution system relies on an extensive partner and retail network. OEMs building devices that run our software have also been a significant means of distribution. The impact of economic conditions on our partners, such as the bankruptcy of a major distributor, OEM, or retailer, could cause sales channel disruption.

Challenging economic conditions also may impair the ability of our customers to pay for products and services they have purchased. As a result, allowances for doubtful accounts and write-offs of accounts receivable may increase.

34

PART I Item 1A

We maintain an investment portfolio of various holdings, types, and maturities. These investments are subject to general credit, liquidity, market, and interest rate risks, which may be exacerbated by market downturns or events that affect global financial markets. A significant part of our investment portfolio comprises U.S. government securities. If global financial markets decline for long periods, or if there is a downgrade of the U.S. government credit rating due to an actual or threatened default on government debt, our investment portfolio may be adversely affected and we could determine that more of our investments have experienced a decline in fair value, requiring impairment charges that could adversely affect our consolidated financial statements.

Catastrophic events or geopolitical conditions may disrupt our business. A disruption or failure of our systems or operations because of a major earthquake, weather event, cyberattack, terrorist attack, pandemic, or other catastrophic event could cause delays in completing sales, providing services, or performing other critical functions. Our corporate headquarters, a significant portion of our research and development activities, and certain other essential business operations are in the Seattle, Washington area, and we have other business operations in the Silicon Valley area of California, both of which are seismically active regions. A catastrophic event that results in the destruction or disruption of any of our critical business or IT systems, or the infrastructure or systems they rely on, such as power grids, could harm our ability to conduct normal business operations. Providing our customers with more services and solutions in the cloud puts a premium on the resilience of our systems and strength of our business continuity management plans and magnifies the potential impact of prolonged service outages in our consolidated financial statements.

Abrupt political change, terrorist activity, and armed conflict, such as the ongoing conflict in Ukraine, pose a risk of general economic disruption in affected countries, which may increase our operating costs and negatively impact our ability to sell to and collect from customers in affected markets. These conditions also may add uncertainty to the timing and budget for technology investment decisions by our customers and may cause supply chain disruptions for hardware manufacturers. Geopolitical change may result in changing regulatory systems and requirements and market interventions that could impact our operating strategies, access to national, regional, and global markets, hiring, and profitability. Geopolitical instability may lead to sanctions and impact our ability to do business in some markets or with some public-sector customers. Any of these changes may negatively impact our revenues.

The occurrence of regional epidemics or a global pandemic, such as COVID-19, may adversely affect our operations, financial condition, and results of operations. The extent to which global pandemics impact our business going forward will depend on factors such as the duration and scope of the pandemic; governmental, business, and individuals' actions in response to the pandemic; and the impact on economic activity, including the possibility of recession or financial market instability. Measures to contain a global pandemic may intensify other risks described in these Risk Factors.

We may incur increased costs to effectively manage these aspects of our business. If we are unsuccessful, it may adversely impact our revenues, cash flows, market share growth, and reputation.

The long-term effects of climate change on the global economy and the IT industry in particular are unclear. Environmental regulations or changes in the supply, demand, or available sources of energy or other resources may affect the availability or cost of goods and services, including natural resources, necessary to run our business. Changes in climate where we operate may increase the costs of powering and cooling computer hardware we use to develop software and provide cloud-based services.

35

PART I Item 1A

Our global business exposes us to operational and economic risks. Our customers are located throughout the world and a significant part of our revenue comes from international sales. The global nature of our business creates operational, economic, and geopolitical risks. Our results of operations may be affected by global, regional, and local economic developments, monetary policy, inflation, and recession, as well as political and military disputes. In addition, our international growth strategy includes certain markets, the developing nature of which presents several risks, including deterioration of social, political, labor, or economic conditions in a country or region, and difficulties in staffing and managing foreign operations. Emerging nationalist and protectionist trends and concerns about human rights, the environment, and political expression in specific countries may significantly alter the trade and commercial environments. Changes to trade policy or agreements as a result of populism, protectionism, or economic nationalism may result in higher tariffs, local sourcing initiatives, and non-local sourcing restrictions, export controls, investment restrictions, or other developments that make it more difficult to sell our products in foreign countries. Disruptions of these kinds in developed or emerging markets could negatively impact demand for our products and services, impair our ability to operate in certain regions, or increase operating costs. Although we hedge a portion of our international currency exposure, significant fluctuations in foreign exchange rates between the U.S. dollar and foreign currencies may adversely affect our results of operations.

Our business depends on our ability to attract and retain talented employees. Our business is based on successfully attracting and retaining talented employees representing diverse backgrounds, experiences, and skill sets. The market for highly skilled workers and leaders in our industry is extremely competitive. Maintaining our brand and reputation, as well as a diverse and inclusive work environment that enables all our employees to thrive, are important to our ability to recruit and retain employees. We are also limited in our ability to recruit internationally by restrictive domestic immigration laws. Changes to U.S. immigration policies that restrain the flow of technical and professional talent may inhibit our ability to adequately staff our research and development efforts. If we are less successful in our recruiting efforts, or if we cannot retain highly skilled workers and key leaders, our ability to develop and deliver successful products and services may be adversely affected. Effective succession planning is also important to our long-term success. Failure to ensure effective transfer of knowledge and smooth transitions involving key employees could hinder our strategic planning and execution. How employment-related laws are interpreted and applied to our workforce practices may result in increased operating costs and less flexibility in how we meet our workforce needs. Our global workforce is predominantly non-unionized, although we do have some employees in the U.S. and internationally who are represented by unions or works councils. In the U.S., there has been a general increase in workers exercising their right to form or join a union. The unionization of significant employee populations could result in higher costs and other operational changes necessary to respond to changing conditions and to establish new relationships with worker representatives.

36

PART I Item 1B, 2, 3, 4

ITEM 1B. UNRESOLVED STAFF COMMENTS

We have received no written comments regarding our periodic or current reports from the staff of the Securities and Exchange Commission that were issued 180 days or more preceding the end of our fiscal year 2023 that remain unresolved.

## ITEM 2. PROPERTIES

Our corporate headquarters are located in Redmond, Washington. We have approximately 16 million square feet of space located in King County, Washington that is used for engineering, sales, marketing, and operations, among other general and administrative purposes. These facilities include approximately 11 million square feet of owned space situated on approximately 530 acres of land we own at our corporate headquarters, and approximately 5 million square feet of space we lease.

We own and lease other facilities domestically and internationally, primarily for offices, datacenters, and research and development. The largest owned international properties include space in the following locations: China, India, Ireland, and the Netherlands. The largest leased international properties include space in the following locations: Australia, Canada, China, France, Germany, India, Ireland, Israel, Japan, the Netherlands, and the United Kingdom. Refer to Research and Development (Part I, Item 1 of this Form 10-K) for further discussion of our research and development facilities.

In fiscal year 2023, we made decisions to consolidate our office leases to create higher density across our workspaces, and we may make similar decisions in future periods as we continue to evaluate our real estate needs.

The table below shows a summary of the square footage of our properties owned and leased domestically and internationally as of June 30, 2023:

## (Square feet in millions)



|Location|Owned|Leased|Total|
|---|---|---|---|
|U.S.|27|20|47|
|International|9|22|31|
|Total|36|42|78|


## ITEM 3. LEGAL PROCEEDINGS

Refer to Note 15 - Contingencies of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K) for information regarding legal proceedings in which we are involved.

## ITEM 4. MINE SAFETY DISCLOSURES

Not applicable.

37

PART II Item 5

PART II

ITEM 5. MARKET FOR REGISTRANT'S COMMON EQUITY, RELATED STOCKHOLDER MATTERS, AND ISSUER PURCHASES OF EQUITY SECURITIES

MARKET AND STOCKHOLDERS

Our common stock is traded on the NASDAQ Stock Market under the symbol MSFT. On July 24, 2023, there were 83,883 registered holders of record of our common stock.

SHARE REPURCHASES AND DIVIDENDS

Following are our monthly share repurchases for the fourth quarter of fiscal year 2023:



|Period|Total Number of Shares Purchased|Average Price Paid Per Share|Total Number of Shares Purchased as Part of Publicly Announced Plans or Programs|Approximate Dollar Value of Shares That May Yet Be Purchased Under the Plans or Programs (In millions)|
|---|---|---|---|---|
|April 1, 2023 - April 30, 2023|5,007,656|$ 287.97|5,007,656|$ 25,467|
|May 1, 2023 - May 31, 2023|5,355,638|314.26|5,355,638|23,784|
|June 1, 2023 - June 30, 2023|4,413,960|334.15|4,413,960|22,309|
||14,777,254||14,777,254||


All share repurchases were made using cash resources. Our share repurchases may occur through open market purchases or pursuant to a Rule 10b5-1 trading plan. The above table excludes shares repurchased to settle employee tax withholding related to the vesting of stock awards.

Our Board of Directors declared the following dividends during the fourth quarter of fiscal year 2023:



|Declaration Date|Record Date|Payment Date|Dividend Per Share|Amount|
|---|---|---|---|---|
|||||(In millions)|
|June 13, 2023|August 17, 2023|September 14, 2023|$ 0.68|$ 5,054|


We returned $9.7 billion to shareholders in the form of share repurchases and dividends in the fourth quarter of fiscal year 2023. Refer to Note 16 - Stockholders' Equity of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K) for further discussion regarding share repurchases and dividends.

38

PART II Item 6

ITEM 6. [RESERVED]

39

PART II Item 7

ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

The following Management's Discussion and Analysis of Financial Condition and Results of Operations ("MD&A") is intended to help the reader understand the results of operations and financial condition of Microsoft Corporation. MD&A is provided as a supplement to, and should be read in conjunction with, our consolidated financial statements and the accompanying Notes to Financial Statements (Part II, Item 8 of this Form 10-K). This section generally discusses the results of our operations for the year ended June 30, 2023 compared to the year ended June 30, 2022. For a discussion of the year ended June 30, 2022 compared to the year ended June 30, 2021, please refer to Part II, Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K for the year ended June 30, 2022.

## OVERVIEW

Microsoft is a technology company whose mission is to empower every person and every organization on the planet to achieve more. We strive to create local opportunity, growth, and impact in every country around the world. We are creating the platforms and tools, powered by artificial intelligence ("Al"), that deliver better, faster, and more effective solutions to support small and large business competitiveness, improve educational and health outcomes, grow public-sector efficiency, and empower human ingenuity.

We generate revenue by offering a wide range of cloud-based solutions, content, and other services to people and businesses; licensing and supporting an array of software products; delivering relevant online advertising to a global audience; and designing and selling devices. Our most significant expenses are related to compensating employees; supporting and investing in our cloud-based services, including datacenter operations; designing, manufacturing, marketing, and selling our other products and services; and income taxes.

Highlights from fiscal year 2023 compared with fiscal year 2022 included:

·Microsoft Cloud revenue increased 22% to $111.6 billion.

·Office Commercial products and cloud services revenue increased 10% driven by Office 365 Commercial growth of 13%.

·Office Consumer products and cloud services revenue increased 2% and Microsoft 365 Consumer subscribers increased to 67.0 million. ·LinkedIn revenue increased 10%.

·Dynamics products and cloud services revenue increased 16% driven by Dynamics 365 growth of 24%.

·Server products and cloud services revenue increased 19% driven by Azure and other cloud services growth of 29%.

·Windows original equipment manufacturer licensing ("Windows OEM") revenue decreased 25%.

·Devices revenue decreased 24%.

·Windows Commercial products and cloud services revenue increased 5%.

·Xbox content and services revenue decreased 3%.

·Search and news advertising revenue excluding traffic acquisition costs increased 11%.

## Industry Trends

Our industry is dynamic and highly competitive, with frequent changes in both technologies and business models. Each industry shift is an opportunity to conceive new products, new technologies, or new ideas that can further transform the industry and our business. At Microsoft, we push the boundaries of what is possible through a broad range of research and development activities that seek to identify and address the changing demands of customers and users, industry trends, and competitive forces.

40

PART II Item 7

## Economic Conditions, Challenges, and Risks

The markets for software, devices, and cloud-based services are dynamic and highly competitive. Our competitors are developing new software and devices, while also deploying competing cloud-based services for consumers and businesses. The devices and form factors customers prefer evolve rapidly, influencing how users access services in the cloud and, in some cases, the user's choice of which suite of cloud-based services to use. Aggregate demand for our software, services, and devices is also correlated to global macroeconomic and geopolitical factors, which remain dynamic. We must continue to evolve and adapt over an extended time in pace with this changing environment.

The investments we are making in cloud and Al infrastructure and devices will continue to increase our operating costs and may decrease our operating margins. We continue to identify and evaluate opportunities to expand our datacenter locations and increase our server capacity to meet the evolving needs of our customers, particularly given the growing demand for Al services. Our datacenters depend on the availability of permitted and buildable land, predictable energy, networking supplies, and servers, including graphics processing units ("GPUs") and other components. Our devices are primarily manufactured by third-party contract manufacturers. For the majority of our products, we have the ability to use other manufacturers if a current vendor becomes unavailable or unable to meet our requirements. However, some of our products contain certain components for which there are very few qualified suppliers. Extended disruptions at these suppliers could impact our ability to manufacture devices on time to meet consumer demand.

Our success is highly dependent on our ability to attract and retain qualified employees. We hire a mix of university and industry talent worldwide. We compete for talented individuals globally by offering an exceptional working environment, broad customer reach, scale in resources, the ability to grow one's career across many different products and businesses, and competitive compensation and benefits.

Our international operations provide a significant portion of our total revenue and expenses. Many of these revenue and expenses are denominated in currencies other than the U.S. dollar. As a result, changes in foreign exchange rates may significantly affect revenue and expenses. Fluctuations in the U.S. dollar relative to certain foreign currencies reduced reported revenue and expenses from our international operations in fiscal year 2023.

On January 18, 2023, we announced decisions we made to align our cost structure with our revenue and customer demand, prioritize our investments in strategic areas, and consolidate office space. As a result, we recorded a $1.2 billion charge in the second quarter of fiscal year 2023 ("Q2 charge"), which included employee severance expenses of $800 million, impairment charges resulting from changes to our hardware portfolio, and costs related to lease consolidation activities. First, we reduced our overall workforce by approximately 10,000 jobs through the third quarter of fiscal year 2023 related to the Q2 charge, which represents less than 5% of our total employee base. While we eliminated roles in some areas, we will continue to hire in key strategic areas. Second, we are allocating both our capital and talent to areas of secular growth and long-term competitiveness, while divesting in other areas. Third, we are consolidating our leases to create higher density across our workspaces, which impacted our financial results through the remainder of fiscal year 2023, and we may make similar decisions in future periods as we continue to evaluate our real estate needs.

Refer to Risk Factors (Part I, Item 1A of this Form 10-K) for a discussion of these factors and other risks.

## Seasonality

Our revenue fluctuates quarterly and is generally higher in the second and fourth quarters of our fiscal year. Second quarter revenue is driven by corporate year-end spending trends in our major markets and holiday season spending by consumers, and fourth quarter revenue is driven by the volume of multi-year on-premises contracts executed during the period.

## Change in Accounting Estimate

In July 2022, we completed an assessment of the useful lives of our server and network equipment. Due to investments in software that increased efficiencies in how we operate our server and network equipment, as well as advances in technology, we determined we should increase the estimated useful lives of both server and network equipment from four years to six years. This change in accounting estimate was effective beginning fiscal year 2023. Based on the carrying amount of server and network equipment included in property and equipment, net as of June 30, 2022, the effect of this change in estimate for fiscal year 2023 was an increase in operating income of $3.7 billion and net income of $3.0 billion, or $0.40 per both basic and diluted share.

41

PART II Item 7

## Reportable Segments

We report our financial performance based on the following segments: Productivity and Business Processes, Intelligent Cloud, and More Personal Computing. The segment amounts included in MD&A are presented on a basis consistent with our internal management reporting. We have recast certain prior period amounts to conform to the way we internally manage and monitor our business.

Additional information on our reportable segments is contained in Note 19 - Segment Information and Geographic Data of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K).

## Metrics

We use metrics in assessing the performance of our business and to make informed decisions regarding the allocation of resources. We disclose metrics to enable investors to evaluate progress against our ambitions, provide transparency into performance trends, and reflect the continued evolution of our products and services. Our commercial and other business metrics are fundamentally connected based on how customers use our products and services. The metrics are disclosed in the MD&A or the Notes to Financial Statements (Part II, Item 8 of this Form 10-K). Financial metrics are calculated based on financial results prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP"), and growth comparisons relate to the corresponding period of last fiscal year.

In the first quarter of fiscal year 2023, we made updates to the presentation and method of calculation for certain metrics, most notably expanding our Surface metric into a broader Devices metric to incorporate additional revenue streams, along with other minor changes to align with how we manage our businesses.

## Commercial

Our commercial business primarily consists of Server products and cloud services, Office Commercial, Windows Commercial, the commercial portion of LinkedIn, Enterprise Services, and Dynamics. Our commercial metrics allow management and investors to assess the overall health of our commercial business and include leading indicators of future performance.



|Commercial remaining performance obligation|Commercial portion of revenue allocated to remaining performance obligations, which includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods|
|---|---|
|Microsoft Cloud revenue|Revenue from Azure and other cloud services, Office 365 Commercial, the commercial portion of Linkedln, Dynamics 365, and other commercial cloud properties|
|Microsoft Cloud gross margin percentage|Gross margin percentage for our Microsoft Cloud business|


42

PART II Item 7

## Productivity and Business Processes and Intelligent Cloud

Metrics related to our Productivity and Business Processes and Intelligent Cloud segments assess the health of our core businesses within these segments. The metrics reflect our cloud and on-premises product strategies and trends.

Office Commercial products and cloud services revenue growth

Office Consumer products and cloud services revenue growth

Office 365 Commercial seat growth

Microsoft 365 Consumer subscribers

Dynamics products and cloud services revenue growth

LinkedIn revenue growth

Server products and cloud services revenue growth

Revenue from Office Commercial products and cloud services (Office 365 subscriptions, the Office 365 portion of Microsoft 365 Commercial subscriptions, and Office licensed on- premises), comprising Office, Exchange, SharePoint, Microsoft Teams, Office 365 Security and Compliance, Microsoft Viva, and Microsoft 365 Copilot

Revenue from Office Consumer products and cloud services, including Microsoft 365 Consumer subscriptions, Office licensed on-premises, and other Office services

The number of Office 365 Commercial seats at end of period where seats are paid users covered by an Office 365 Commercial subscription

The number of Microsoft 365 Consumer subscribers at end of period

Revenue from Dynamics products and cloud services, including Dynamics 365, comprising a set of intelligent, cloud-based applications across ERP, CRM (including Customer Insights), Power Apps, and Power Automate; and on-premises ERP and CRM applications

Revenue from LinkedIn, including Talent Solutions, Marketing Solutions, Premium Subscriptions, and Sales Solutions

Revenue from Server products and cloud services, including Azure and other cloud services; SQL Server, Windows Server, Visual Studio, System Center, and related Client Access Licenses ("CALs"); and Nuance and GitHub

## More Personal Computing

Metrics related to our More Personal Computing segment assess the performance of key lines of business within this segment. These metrics provide strategic product insights which allow us to assess the performance across our commercial and consumer businesses. As we have diversity of target audiences and sales motions within the Windows business, we monitor metrics that are reflective of those varying motions.

Windows OEM revenue growth

Windows Commercial products and cloud services revenue growth

Devices revenue growth Xbox content and services revenue growth

Search and news advertising revenue (ex TAC) growth

Revenue from sales of Windows Pro and non-Pro licenses sold through the OEM channel

Revenue from Windows Commercial products and cloud services, comprising volume licensing of the Windows operating system, Windows cloud services, and other Windows commercial offerings

Revenue from Devices, including Surface, HoloLens, and PC accessories

Revenue from Xbox content and services, comprising first- and third-party content (including games and in-game content), Xbox Game Pass and other subscriptions, Xbox Cloud Gaming, advertising, third-party disc royalties, and other cloud services

Revenue from search and news advertising excluding traffic acquisition costs ("TAC") paid to Bing Ads network publishers and news partners

43

PART II Item 7

SUMMARY RESULTS OF OPERATIONS



|(In millions, except percentages and per share amounts)|2023|2022|Percentage Change|
|---|---|---|---|
|Revenue|$ 211,915|$ 198,270|7%|
|Gross margin|146,052|135,620|8%|
|Operating income|88,523|83,383|6%|
|Net income|72,361|72,738|(1)%|
|Diluted earnings per share|9.68|9.65|0%|
|Adjusted gross margin (non-GAAP)|146,204|135,620|8%|
|Adjusted operating income (non-GAAP)|89,694|83,383|8%|
|Adjusted net income (non-GAAP)|73,307|69,447|6%|
|Adjusted diluted earnings per share (non-GAAP)|9.81|9.21|7%|


Adjusted gross margin, operating income, net income, and diluted earnings per share ("EPS") are non-GAAP financial measures. Current year non- GAAP financial measures exclude the impact of the Q2 charge, which includes employee severance expenses, impairment charges resulting from changes to our hardware portfolio, and costs related to lease consolidation activities. Prior year non-GAAP financial measures exclude the net income tax benefit related to transfer of intangible properties in the first quarter of fiscal year 2022. Refer to Note 12 - Income Taxes of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K) for further discussion. Refer to the Non-GAAP Financial Measures section below for a reconciliation of our financial results reported in accordance with GAAP to non-GAAP financial results.

## Fiscal Year 2023 Compared with Fiscal Year 2022

Revenue increased $13.6 billion or 7% driven by growth in Intelligent Cloud and Productivity and Business Processes, offset in part by a decline in More Personal Computing. Intelligent Cloud revenue increased driven by Azure and other cloud services. Productivity and Business Processes revenue increased driven by Office 365 Commercial and LinkedIn. More Personal Computing revenue decreased driven by Windows and Devices.

Cost of revenue increased $3.2 billion or 5% driven by growth in Microsoft Cloud, offset in part by the change in accounting estimate.

Gross margin increased $10.4 billion or 8% driven by growth in Intelligent Cloud and Productivity and Business Processes and the change in accounting estimate, offset in part by a decline in More Personal Computing.

·Gross margin percentage increased slightly. Excluding the impact of the change in accounting estimate, gross margin percentage decreased 1 point driven by declines in Intelligent Cloud and More Personal Computing, offset in part by sales mix shift between our segments.

·Microsoft Cloud gross margin percentage increased 2 points to 72%. Excluding the impact of the change in accounting estimate, Microsoft Cloud gross margin percentage decreased slightly driven by a decline in Azure and other cloud services and sales mix shift to Azure and other cloud services, offset in part by improvement in Office 365 Commercial.

Operating expenses increased $5.3 billion or 10% driven by employee severance expenses, 2 points of growth from the Nuance and Xandr acquisitions, investments in cloud engineering, and LinkedIn.

Operating income increased $5.1 billion or 6% driven by growth in Productivity and Business Processes and Intelligent Cloud and the change in accounting estimate, offset in part by a decline in More Personal Computing.

Revenue, gross margin, and operating income included an unfavorable foreign currency impact of 4%, 4%, and 6%, respectively. Cost of revenue and operating expenses both included a favorable foreign currency impact of 2%.

Current year gross margin, operating income, net income, and diluted EPS were negatively impacted by the Q2 charge, which resulted in decreases of $152 million, $1.2 billion, $946 million, and $0.13, respectively. Prior year net income and diluted EPS were positively impacted by the net tax benefit related to the transfer of intangible properties, which resulted in an increase to net income and diluted EPS of $3.3 billion and $0.44, respectively.

44

PART II Item 7

SEGMENT RESULTS OF OPERATIONS



|(In millions, except percentages)|2023|2022|Percentage Change|
|---|---|---|---|
|Revenue||||
|Productivity and Business Processes|$ 69,274|$ 63,364|9%|
|Intelligent Cloud|87,907|74,965|17%|
|More Personal Computing|54,734|59,941|(9)%|
|Total|$ 211,915|$ 198,270|7%|
|Operating Income||||
|Productivity and Business Processes|$ 34,189|$ 29,690|15%|
|Intelligent Cloud|37,884|33,203|14%|
|More Personal Computing|16,450|20,490|(20)%|
|Total|$ 88,523|$ 83,383|6%|


## Fiscal Year 2023 Compared with Fiscal Year 2022

Productivity and Business Processes

Revenue increased $5.9 billion or 9%.

·Office Commercial products and cloud services revenue increased $3.7 billion or 10%. Office 365 Commercial revenue grew 13% with seat growth of 11%, driven by small and medium business and frontline worker offerings, as well as growth in revenue per user. Office Commercial products revenue declined 21% driven by continued customer shift to cloud offerings.

·Office Consumer products and cloud services revenue increased $140 million or 2%. Microsoft 365 Consumer subscribers grew 12% to 67.0 million.

·LinkedIn revenue increased $1.3 billion or 10% driven by Talent Solutions.

·Dynamics products and cloud services revenue increased $750 million or 16% driven by Dynamics 365 growth of 24%.

Operating income increased $4.5 billion or 15%.

.Gross margin increased $5.8 billion or 12% driven by growth in Office 365 Commercial and Linkedln, as well as the change in accounting estimate. Gross margin percentage increased. Excluding the impact of the change in accounting estimate, gross margin percentage increased slightly driven by improvement in Office 365 Commercial, offset in part by sales mix shift to cloud offerings.

·Operating expenses increased $1.3 billion or 7% driven by investment in LinkedIn and employee severance expenses.

Revenue, gross margin, and operating income included an unfavorable foreign currency impact of 5%, 5%, and 8%, respectively.

## Revenue increased $12.9 billion or 17%.

.Server products and cloud services revenue increased $12.6 billion or 19% driven by Azure and other cloud services. Azure and other cloud services revenue grew 29% driven by growth in our consumption-based services. Server products revenue decreased 1%.

·Enterprise Services revenue increased $315 million or 4% driven by growth in Enterprise Support Services, offset in part by a decline in Industry Solutions (formerly Microsoft Consulting Services).

45

PART II Item 7

## Operating income increased $4.7 billion or 14%.

·Gross margin increased $8.9 billion or 17% driven by growth in Azure and other cloud services and the change in accounting estimate. Gross margin percentage decreased slightly. Excluding the impact of the change in accounting estimate, gross margin percentage decreased 3 points driven by sales mix shift to Azure and other cloud services and a decline in Azure and other cloud services.

·Operating expenses increased $4.2 billion or 21% driven by investments in Azure, 4 points of growth from the Nuance acquisition, and employee severance expenses.

Revenue, gross margin, and operating income included an unfavorable foreign currency impact of 4%, 4%, and 6%, respectively. Operating expenses included a favorable foreign currency impact of 2%.

## More Personal Computing

Revenue decreased $5.2 billion or 9%.

·Windows revenue decreased $3.2 billion or 13% driven by a decrease in Windows OEM. Windows OEM revenue decreased 25% as elevated channel inventory levels continued to drive additional weakness beyond declining PC demand. Windows Commercial products and cloud services revenue increased 5% driven by demand for Microsoft 365.

·Devices revenue decreased $1.8 billion or 24% as elevated channel inventory levels continued to drive additional weakness beyond declining PC demand.

·Gaming revenue decreased $764 million or 5% driven by declines in Xbox hardware and Xbox content and services. Xbox hardware revenue decreased 11% driven by lower volume and price of consoles sold. Xbox content and services revenue decreased 3% driven by a decline in first-party content, offset in part by growth in Xbox Game Pass.

.Search and news advertising revenue increased $617 million or 5%. Search and news advertising revenue excluding traffic acquisition costs increased 11% driven by higher search volume and the Xandr acquisition.

Operating income decreased $4.0 billion or 20%.

·Gross margin decreased $4.2 billion or 13% driven by declines in Windows and Devices. Gross margin percentage decreased driven by a decline in Devices.

·Operating expenses decreased $195 million or 2% driven by a decline in Devices, offset in part by investments in Search and news advertising, including 2 points of growth from the Xandr acquisition.

Revenue, gross margin, and operating income included an unfavorable foreign currency impact of 3%, 4%, and 6%, respectively. Operating expenses included a favorable foreign currency impact of 2%.

46

PART II Item 7

OPERATING EXPENSES

## Research and Development



|(In millions, except percentages)|2023|2022|Percentage Change|
|---|---|---|---|
|Research and development|$ 27,195|$ 24,512|11%|
|As a percent of revenue|13%|12%|1ppt|


Research and development expenses include payroll, employee benefits, stock-based compensation expense, and other headcount-related expenses associated with product development. Research and development expenses also include third-party development and programming costs and the amortization of purchased software code and services content.

## Fiscal Year 2023 Compared with Fiscal Year 2022

Research and development expenses increased $2.7 billion or 11% driven by investments in cloud engineering and LinkedIn.

## Sales and Marketing



|(In millions, except percentages)|2023|2022|Percentage Change|
|---|---|---|---|
|Sales and marketing|$ 22,759|$ 21,825|4%|
|As a percent of revenue|11%|11%|Oppt|


Sales and marketing expenses include payroll, employee benefits, stock-based compensation expense, and other headcount-related expenses associated with sales and marketing personnel, and the costs of advertising, promotions, trade shows, seminars, and other programs.

## Fiscal Year 2023 Compared with Fiscal Year 2022

Sales and marketing expenses increased $934 million or 4% driven by 3 points of growth from the Nuance and Xandr acquisitions and investments in commercial sales, offset in part by a decline in Windows advertising. Sales and marketing included a favorable foreign currency impact of 2%.

## General and Administrative



|(In millions, except percentages)|2023|2022|Percentage Change|
|---|---|---|---|
|General and administrative|$ 7,575|$ 5,900|28%|
|As a percent of revenue|4%|3%|1ppt|


General and administrative expenses include payroll, employee benefits, stock-based compensation expense, employee severance expense incurred as part of a corporate program, and other headcount-related expenses associated with finance, legal, facilities, certain human resources and other administrative personnel, certain taxes, and legal and other administrative fees.

## Fiscal Year 2023 Compared with Fiscal Year 2022

General and administrative expenses increased $1.7 billion or 28% driven by employee severance expenses and a charge related to a non-public preliminary draft decision provided by the Irish Data Protection Commission. General and administrative included a favorable foreign currency impact of 2%.

47

PART II Item 7

OTHER INCOME (EXPENSE), NET

The components of other income (expense), net were as follows:

## (In millions)



|Year Ended June 30,|2023|2022|
|---|---|---|
|Interest and dividends income|$ 2,994|$ 2,094|
|Interest expense|(1,968)|(2,063 )|
|Net recognized gains on investments|260|461|
|Net losses on derivatives|(456)|(52)|
|Net gains (losses) on foreign currency remeasurements|181|(75)|
|Other, net|(223)|(32)|
|Total|$ 788|$ 333|


We use derivative instruments to manage risks related to foreign currencies, equity prices, interest rates, and credit; enhance investment returns; and facilitate portfolio diversification. Gains and losses from changes in fair values of derivatives that are not designated as hedging instruments are primarily recognized in other income (expense), net.

## Fiscal Year 2023 Compared with Fiscal Year 2022

Interest and dividends income increased due to higher yields, offset in part by lower portfolio balances. Interest expense decreased due to a decrease in outstanding long-term debt due to debt maturities. Net recognized gains on investments decreased due to lower gains on equity securities and higher losses on fixed income securities. Net losses on derivatives increased due to losses related to managing strategic investments.

## Effective Tax Rate

Our effective tax rate for fiscal years 2023 and 2022 was 19% and 13%, respectively. The increase in our effective tax rate was primarily due to a $3.3 billion net income tax benefit in the first quarter of fiscal year 2022 related to the transfer of intangible properties and a decrease in tax benefits relating to stock-based compensation.

In the first quarter of fiscal year 2022, we transferred certain intangible properties from our Puerto Rico subsidiary to the U.S. The transfer of intangible properties resulted in a $3.3 billion net income tax benefit in the first quarter of fiscal year 2022, as the value of future U.S. tax deductions exceeded the current tax liability from the U.S. global intangible low-taxed income tax.

Our effective tax rate was lower than the U.S. federal statutory rate, primarily due to earnings taxed at lower rates in foreign jurisdictions resulting from producing and distributing our products and services through our foreign regional operations center in Ireland.

The mix of income before income taxes between the U.S. and foreign countries impacted our effective tax rate as a result of the geographic distribution of, and customer demand for, our products and services. In fiscal year 2023, our U.S. income before income taxes was $52.9 billion and our foreign income before income taxes was $36.4 billion. In fiscal year 2022, our U.S. income before income taxes was $47.8 billion and our foreign income before income taxes was $35.9 billion.

## Uncertain Tax Positions

We settled a portion of the Internal Revenue Service ("IRS") audit for tax years 2004 to 2006 in fiscal year 2011. In February 2012, the IRS withdrew its 2011 Revenue Agents Report related to unresolved issues for tax years 2004 to 2006 and reopened the audit phase of the examination. We also settled a portion of the IRS audit for tax years 2007 to 2009 in fiscal year 2016, and a portion of the IRS audit for tax years 2010 to 2013 in fiscal year 2018. In the second quarter of fiscal year 2021, we settled an additional portion of the IRS audits for tax years 2004 to 2013 and made a payment of $1.7 billion, including tax and interest. We remain under audit for tax years 2004 to 2017.

48

PART II Item 7

As of June 30, 2023, the primary unresolved issues for the IRS audits relate to transfer pricing, which could have a material impact in our consolidated financial statements when the matters are resolved. We believe our allowances for income tax contingencies are adequate. We have not received a proposed assessment for the unresolved key transfer pricing issues. We do not expect a final resolution of these issues in the next 12 months. Based on the information currently available, we do not anticipate a significant increase or decrease to our tax contingencies for these issues within the next 12 months.

We are subject to income tax in many jurisdictions outside the U.S. Our operations in certain jurisdictions remain subject to examination for tax years 1996 to 2022, some of which are currently under audit by local tax authorities. The resolution of each of these audits is not expected to be material to our consolidated financial statements.

## NON-GAAP FINANCIAL MEASURES

Adjusted gross margin, operating income, net income, and diluted EPS are non-GAAP financial measures. Current year non-GAAP financial measures exclude the impact of the Q2 charge, which includes employee severance expenses, impairment charges resulting from changes to our hardware portfolio, and costs related to lease consolidation activities. Prior year non-GAAP financial measures exclude the net income tax benefit related to transfer of intangible properties in the first quarter of fiscal year 2022. We believe these non-GAAP measures aid investors by providing additional insight into our operational performance and help clarify trends affecting our business. For comparability of reporting, management considers non-GAAP measures in conjunction with GAAP financial results in evaluating business performance. These non-GAAP financial measures presented should not be considered a substitute for, or superior to, the measures of financial performance prepared in accordance with GAAP.

The following table reconciles our financial results reported in accordance with GAAP to non-GAAP financial results:



|(In millions, except percentages and per share amounts)|2023|2022|Percentage Change|
|---|---|---|---|
|Gross margin|$ 146,052|$ 135,620|8%|
|Severance, hardware-related impairment, and lease consolidation costs|152|0|*|
|Adjusted gross margin (non-GAAP)|$ 146,204|$ 135,620|8%|
|Operating income|$ 88,523|$ 83,383|6%|
|Severance, hardware-related impairment, and lease consolidation costs|1,171|0|*|
|Adjusted operating income (non-GAAP)|$ 89,694|$ 83,383|8%|
|Net income|$ 72,361|$ 72,738|(1)%|
|Severance, hardware-related impairment, and lease consolidation costs|946|0|*|
|Net income tax benefit related to transfer of intangible properties|0|(3,291 )|*|
|Adjusted net income (non-GAAP)|$ 73,307|$ 69,447|6%|
|Diluted earnings per share|$ 9.68|$ 9.65|0%|
|Severance, hardware-related impairment, and lease consolidation costs|0.13|0|*|
|Net income tax benefit related to transfer of intangible properties|0|(0.44)|*|
|Adjusted diluted earnings per share (non-GAAP)|$ 9.81|$ 9.21|7%|


* Not meaningful.

49

PART II Item 7

LIQUIDITY AND CAPITAL RESOURCES

We expect existing cash, cash equivalents, short-term investments, cash flows from operations, and access to capital markets to continue to be sufficient to fund our operating activities and cash commitments for investing and financing activities, such as dividends, share repurchases, debt maturities, material capital expenditures, and the transition tax related to the Tax Cuts and Jobs Act ("TCJA"), for at least the next 12 months and thereafter for the foreseeable future.

## Cash, Cash Equivalents, and Investments

Cash, cash equivalents, and short-term investments totaled $111.3 billion and $104.8 billion as of June 30, 2023 and 2022, respectively. Equity investments were $9.9 billion and $6.9 billion as of June 30, 2023 and 2022, respectively. Our short-term investments are primarily intended to facilitate liquidity and capital preservation. They consist predominantly of highly liquid investment-grade fixed-income securities, diversified among industries and individual issuers. The investments are predominantly U.S. dollar-denominated securities, but also include foreign currency-denominated securities to diversify risk. Our fixed-income investments are exposed to interest rate risk and credit risk. The credit risk and average maturity of our fixed-income portfolio are managed to achieve economic returns that correlate to certain fixed-income indices. The settlement risk related to these investments is insignificant given that the short-term investments held are primarily highly liquid investment-grade fixed-income securities.

## Valuation

In general, and where applicable, we use quoted prices in active markets for identical assets or liabilities to determine the fair value of our financial instruments. This pricing methodology applies to our Level 1 investments, such as U.S. government securities, common and preferred stock, and mutual funds. If quoted prices in active markets for identical assets or liabilities are not available to determine fair value, then we use quoted prices for similar assets and liabilities or inputs other than the quoted prices that are observable either directly or indirectly. This pricing methodology applies to our Level 2 investments, such as commercial paper, certificates of deposit, U.S. agency securities, foreign government bonds, mortgage- and asset-backed securities, corporate notes and bonds, and municipal securities. Level 3 investments are valued using internally-developed models with unobservable inputs. Assets and liabilities measured at fair value on a recurring basis using unobservable inputs are an immaterial portion of our portfolio.

A majority of our investments are priced by pricing vendors and are generally Level 1 or Level 2 investments as these vendors either provide a quoted market price in an active market or use observable inputs for their pricing without applying significant adjustments. Broker pricing is used mainly when a quoted price is not available, the investment is not priced by our pricing vendors, or when a broker price is more reflective of fair values in the market in which the investment trades. Our broker-priced investments are generally classified as Level 2 investments because the broker prices these investments based on similar assets without applying significant adjustments. In addition, all our broker-priced investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments. Our fair value processes include controls that are designed to ensure appropriate fair values are recorded. These controls include model validation, review of key model inputs, analysis of period-over-period fluctuations, and independent recalculation of prices where appropriate.

## Cash Flows

Cash from operations decreased $1.5 billion to $87.6 billion for fiscal year 2023, mainly due to an increase in cash paid to employees and suppliers and cash used to pay income taxes, offset in part by an increase in cash received from customers. Cash used in financing decreased $14.9 billion to $43.9 billion for fiscal year 2023, mainly due to a $10.5 billion decrease in common stock repurchases and a $6.3 billion decrease in repayments of debt, offset in part by a $1.7 billion increase in dividends paid. Cash used in investing decreased $7.6 billion to $22.7 billion for fiscal year 2023, due to a $20.4 billion decrease in cash used for acquisitions of companies, net of cash acquired, and purchases of intangible and other assets, offset in part by a $8.2 billion decrease in cash from net investment purchases, sales, and maturities, and a $4.2 billion increase in additions to property and equipment.

50

PART II Item 7

## Debt Proceeds

We issue debt to take advantage of favorable pricing and liquidity in the debt markets, reflecting our credit rating and the low interest rate environment. The proceeds of these issuances were or will be used for general corporate purposes, which may include, among other things, funding for working capital, capital expenditures, repurchases of capital stock, acquisitions, and repayment of existing debt. Refer to Note 11 - Debt of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K) for further discussion.

## Unearned Revenue

Unearned revenue comprises mainly unearned revenue related to volume licensing programs, which may include Software Assurance ("SA") and cloud services. Unearned revenue is generally invoiced annually at the beginning of each contract period for multi-year agreements and recognized ratably over the coverage period. Unearned revenue also includes payments for other offerings for which we have been paid in advance and earn the revenue when we transfer control of the product or service. Refer to Note 1 - Accounting Policies of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K) for further discussion.

The following table outlines the expected future recognition of unearned revenue as of June 30, 2023:

## Three Months Ending



|September 30, 2023|$ 19,673|
|---|---|
|December 31, 2023|15,600|
|March 31, 2024|10,801|
|June 30, 2024|4,827|
|Thereafter|2,912|
|Total|$ 53,813|


If our customers choose to license cloud-based versions of our products and services rather than licensing transaction-based products and services, the associated revenue will shift from being recognized at the time of the transaction to being recognized over the subscription period or upon consumption, as applicable. Refer to Note 13 - Unearned Revenue of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K) for further discussion.

## Contractual Obligations

The following table summarizes the payments due by fiscal year for our outstanding contractual obligations as of June 30, 2023:



|(In millions)|2024|Thereafter|Total|
|---|---|---|---|
|Long-term debt: (a)||||
|Principal payments|$ 5,250|$ 47,616|$ 52,866|
|Interest payments|1,379|19,746|21,125|
|Construction commitments (b)|12,237|1,218|13,455|
|Operating and finance leases, including imputed interest (c)|5,988|73,852|79,840|
|Purchase commitments (d)|64,703|3,115|67,818|
|Total|$ 89,557|$ 145,547|$ 235,104|


(a)Refer to Note 11 - Debt of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K).

(b)Refer to Note 7 - Property and Equipment of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K).

(c)Refer to Note 14 - Leases of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K).

(d)Purchase commitments primarily relate to datacenters and include open purchase orders and take-or-pay contracts that are not presented as construction commitments above.

51

PART II Item 7

## Income Taxes

As a result of the TCJA, we are required to pay a one-time transition tax on deferred foreign income not previously subject to U.S. income tax. Under the TCJA, the transition tax is payable in interest-free installments over eight years, with 8% due in each of the first five years, 15% in year six, 20% in year seven, and 25% in year eight. We have paid transition tax of $7.7 billion, which included $1.5 billion for fiscal year 2023. The remaining transition tax of $10.5 billion is payable over the next three years, with $2.7 billion payable within 12 months.

In fiscal year 2023, we paid cash tax of $4.8 billion due to the mandatory capitalization for tax purposes of research and development expenditures enacted by the TCJA and effective on July 1, 2022.

## Share Repurchases

During fiscal years 2023 and 2022, we repurchased 69 million shares and 95 million shares of our common stock for $18.4 billion and $28.0 billion, respectively, through our share repurchase programs. All repurchases were made using cash resources. As of June 30, 2023, $22.3 billion remained of our $60 billion share repurchase program. Refer to Note 16 - Stockholders' Equity of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K) for further discussion.

## Dividends

During fiscal year 2023 and 2022, our Board of Directors declared quarterly dividends of $0.68 per share and $0.62 per share, totaling $20.2 billion and $18.6 billion, respectively. We intend to continue returning capital to shareholders in the form of dividends, subject to declaration by our Board of Directors. Refer to Note 16 - Stockholders' Equity of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K) for further discussion.

## Other Planned Uses of Capital

On January 18, 2022, we entered into a definitive agreement to acquire Activision Blizzard, Inc. ("Activision Blizzard") for $95.00 per share in an all-cash transaction valued at $68.7 billion, inclusive of Activision Blizzard's net cash. The acquisition has been approved by Activision Blizzard's shareholders. We continue to work toward closing the transaction subject to obtaining required regulatory approvals and satisfaction of other customary closing conditions. Microsoft and Activision Blizzard have jointly agreed to extend the merger agreement through October 18, 2023 to allow for additional time to resolve remaining regulatory concerns.

We will continue to invest in sales, marketing, product support infrastructure, and existing and advanced areas of technology, as well as acquisitions that align with our business strategy. Additions to property and equipment will continue, including new facilities, datacenters, and computer systems for research and development, sales and marketing, support, and administrative staff. We expect capital expenditures to increase in coming years to support growth in our cloud offerings and our investments in Al infrastructure. We have operating and finance leases for datacenters, corporate offices, research and development facilities, Microsoft Experience Centers, and certain equipment. We have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of capital resources.

## CRITICAL ACCOUNTING ESTIMATES

Our consolidated financial statements and accompanying notes are prepared in accordance with GAAP. Preparing consolidated financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, and expenses. Critical accounting estimates are those estimates that involve a significant level of estimation uncertainty and could have a material impact on our financial condition or results of operations. We have critical accounting estimates in the areas of revenue recognition, impairment of investment securities, goodwill, research and development costs, legal and other contingencies, income taxes, and inventories.

52

PART II Item 7

## Revenue Recognition

Our contracts with customers often include promises to transfer multiple products and services to a customer. Determining whether products and services are considered distinct performance obligations that should be accounted for separately versus together may require significant judgment. When a cloud- based service includes both on-premises software licenses and cloud services, judgment is required to determine whether the software license is considered distinct and accounted for separately, or not distinct and accounted for together with the cloud service and recognized over time. Certain cloud services, primarily Office 365, depend on a significant level of integration, interdependency, and interrelation between the desktop applications and cloud services, and are accounted for together as one performance obligation. Revenue from Office 365 is recognized ratably over the period in which the cloud services are provided.

Judgment is required to determine the stand-alone selling price ("SSP") for each distinct performance obligation. We use a single amount to estimate SSP for items that are not sold separately, including on-premises licenses sold with SA or software updates provided at no additional charge. We use a range of amounts to estimate SSP when we sell each of the products and services separately and need to determine whether there is a discount to be allocated based on the relative SSP of the various products and services.

In instances where SSP is not directly observable, such as when we do not sell the product or service separately, we determine the SSP using information that may include market conditions and other observable inputs. We typically have more than one SSP for individual products and services due to the stratification of those products and services by customers and circumstances. In these instances, we may use information such as the size of the customer and geographic region in determining the SSP.

Due to the various benefits from and the nature of our SA program, judgment is required to assess the pattern of delivery, including the exercise pattern of certain benefits across our portfolio of customers.

Our products are generally sold with a right of return, we may provide other credits or incentives, and in certain instances we estimate customer usage of our products and services, which are accounted for as variable consideration when determining the amount of revenue to recognize. Returns and credits are estimated at contract inception and updated at the end of each reporting period if additional information becomes available. Changes to our estimated variable consideration were not material for the periods presented.

## Impairment of Investment Securities

We review debt investments quarterly for credit losses and impairment. If the cost of an investment exceeds its fair value, we evaluate, among other factors, general market conditions, credit quality of debt instrument issuers, and the extent to which the fair value is less than cost. This determination requires significant judgment. In making this judgment, we employ a systematic methodology that considers available quantitative and qualitative evidence in evaluating potential impairment of our investments. In addition, we consider specific adverse conditions related to the financial health of, and business outlook for, the investee. If we have plans to sell the security or it is more likely than not that we will be required to sell the security before recovery, then a decline in fair value below cost is recorded as an impairment charge in other income (expense), net and a new cost basis in the investment is established. If market, industry, and/or investee conditions deteriorate, we may incur future impairments.

Equity investments without readily determinable fair values are written down to fair value if a qualitative assessment indicates that the investment is impaired and the fair value of the investment is less than carrying value. We perform a qualitative assessment on a periodic basis. We are required to estimate the fair value of the investment to determine the amount of the impairment loss. Once an investment is determined to be impaired, an impairment charge is recorded in other income (expense), net.

53

PART II Item 7

## Goodwill

We allocate goodwill to reporting units based on the reporting unit expected to benefit from the business combination. We evaluate our reporting units on an annual basis and, if necessary, reassign goodwill using a relative fair value allocation approach. Goodwill is tested for impairment at the reporting unit level (operating segment or one level below an operating segment) on an annual basis (May 1) and between annual tests if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. These events or circumstances could include a significant change in the business climate, legal factors, operating performance indicators, competition, or sale or disposition of a significant portion of a reporting unit.

Application of the goodwill impairment test requires judgment, including the identification of reporting units, assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units, and determination of the fair value of each reporting unit. The fair value of each reporting unit is estimated primarily through the use of a discounted cash flow methodology. This analysis requires significant judgments, including estimation of future cash flows, which is dependent on internal forecasts, estimation of the long-term rate of growth for our business, estimation of the useful life over which cash flows will occur, and determination of our weighted average cost of capital.

The estimates used to calculate the fair value of a reporting unit change from year to year based on operating results, market conditions, and other factors. Changes in these estimates and assumptions could materially affect the determination of fair value and goodwill impairment for each reporting unit.

## Research and Development Costs

Costs incurred internally in researching and developing a computer software product are charged to expense until technological feasibility has been established for the product. Once technological feasibility is established, software costs are capitalized until the product is available for general release to customers. Judgment is required in determining when technological feasibility of a product is established. We have determined that technological feasibility for our software products is reached after all high-risk development issues have been resolved through coding and testing. Generally, this occurs shortly before the products are released to production. The amortization of these costs is included in cost of revenue over the estimated life of the products.

## Legal and Other Contingencies

The outcomes of legal proceedings and claims brought against us are subject to significant uncertainty. An estimated loss from a loss contingency such as a legal proceeding or claim is accrued by a charge to income if it is probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. In determining whether a loss should be accrued we evaluate, among other factors, the degree of probability of an unfavorable outcome and the ability to make a reasonable estimate of the amount of loss. Changes in these factors could materially impact our consolidated financial statements.

54

PART II Item 7

## Income Taxes

The objectives of accounting for income taxes are to recognize the amount of taxes payable or refundable for the current year, and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in an entity's financial statements or tax returns. We recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. Accounting literature also provides guidance on derecognition of income tax assets and liabilities, classification of deferred income tax assets and liabilities, accounting for interest and penalties associated with tax positions, and income tax disclosures. Judgment is required in assessing the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. Variations in the actual outcome of these future tax consequences could materially impact our consolidated financial statements.

## Inventories

Inventories are stated at average cost, subject to the lower of cost or net realizable value. Cost includes materials, labor, and manufacturing overhead related to the purchase and production of inventories. Net realizable value is the estimated selling price less estimated costs of completion, disposal, and transportation. We regularly review inventory quantities on hand, future purchase commitments with our suppliers, and the estimated utility of our inventory. These reviews include analysis of demand forecasts, product life cycle status, product development plans, current sales levels, pricing strategy, and component cost trends. If our review indicates a reduction in utility below carrying value, we reduce our inventory to a new cost basis through a charge to cost of revenue.

55

PART II Item 7

STATEMENT OF MANAGEMENT'S RESPONSIBILITY FOR FINANCIAL STATEMENTS

Management is responsible for the preparation of the consolidated financial statements and related information that are presented in this report. The consolidated financial statements, which include amounts based on management's estimates and judgments, have been prepared in conformity with accounting principles generally accepted in the United States of America.

The Company designs and maintains accounting and internal control systems to provide reasonable assurance at reasonable cost that assets are safeguarded against loss from unauthorized use or disposition, and that the financial records are reliable for preparing consolidated financial statements and maintaining accountability for assets. These systems are augmented by written policies, an organizational structure providing division of responsibilities, careful selection and training of qualified personnel, and a program of internal audits.

The Company engaged Deloitte & Touche LLP, an independent registered public accounting firm, to audit and render an opinion on the consolidated financial statements and internal control over financial reporting in accordance with the standards of the Public Company Accounting Oversight Board (United States).

The Board of Directors, through its Audit Committee, consisting solely of independent directors of the Company, meets periodically with management, internal auditors, and our independent registered public accounting firm to ensure that each is meeting its responsibilities and to discuss matters concerning internal controls and financial reporting. Deloitte & Touche LLP and the internal auditors each have full and free access to the Audit Committee.

Satya Nadella Chief Executive Officer

Amy E. Hood Executive Vice President and Chief Financial Officer

Alice L. Jolla Corporate Vice President and Chief Accounting Officer

56

PART II Item 7A

ITEM 7A. QUANTITATIVE AND QUALITATIVE DISCLOSURES ABOUT MARKET RISK RISKS

We are exposed to economic risk from foreign exchange rates, interest rates, credit risk, and equity prices. We use derivatives instruments to manage these risks, however, they may still impact our consolidated financial statements.

## Foreign Currencies

Certain forecasted transactions, assets, and liabilities are exposed to foreign currency risk. We monitor our foreign currency exposures daily to maximize the economic effectiveness of our foreign currency positions, including hedges. Principal currency exposures include the Euro, Japanese yen, British pound, Canadian dollar, and Australian dollar.

## Interest Rate

Securities held in our fixed-income portfolio are subject to different interest rate risks based on their maturities. We manage the average maturity of the fixed-income portfolio to achieve economic returns that correlate to certain global fixed-income indices.

## Credit

Our fixed-income portfolio is diversified and consists primarily of investment-grade securities. We manage credit exposures relative to broad-based indices to facilitate portfolio diversification.

## Equity

Securities held in our equity investments portfolio are subject to price risk.

## SENSITIVITY ANALYSIS

The following table sets forth the potential loss in future earnings or fair values, including associated derivatives, resulting from hypothetical changes in relevant market rates or prices:

## (In millions)



|Risk Categories|Hypothetical Change|June 30, 2023|Impact|
|---|---|---|---|
|Foreign currency - Revenue|10% decrease in foreign exchange rates|$ (8,122)|Earnings|
|Foreign currency - Investments|10% decrease in foreign exchange rates|(29)|Fair Value|
|Interest rate|100 basis point increase in U.S. treasury interest rates|(1,832)|Fair Value|
|Credit|100 basis point increase in credit spreads|(354)|Fair Value|
|Equity|10% decrease in equity market prices|(705)|Earnings|


57

PART II Item 8

ITEM 8. FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA

INCOME STATEMENTS

(In millions, except per share amounts)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Revenue:||||
|Product|$ 64,699|$ 72,732|$ 71,074|
|Service and other|147,216|125,538|97,014|
|Total revenue|211,915|198,270|168,088|
|Cost of revenue:||||
|Product|17,804|19,064|18,219|
|Service and other|48,059|43,586|34,013|
|Total cost of revenue|65,863|62,650|52,232|
|Gross margin|146,052|135,620|115,856|
|Research and development|27,195|24,512|20,716|
|Sales and marketing|22,759|21,825|20,117|
|General and administrative|7,575|5,900|5,107|
|Operating income|88,523|83,383|69,916|
|Other income, net|788|333|1,186|
|Income before income taxes|89,311|83,716|71,102|
|Provision for income taxes|16,950|10,978|9,831|
|Net income|$ 72,361|$ 72,738|$ 61,271|
|Earnings per share:||||
|Basic|$ 9.72|$ 9.70|$ 8.12|
|Diluted|$ 9.68|$ 9.65|$ 8.05|
|Weighted average shares outstanding:||||
|Basic|7,446|7,496|7,547|
|Diluted|7,472|7,540|7,608|


Refer to accompanying notes.

58

PART II Item 8

COMPREHENSIVE INCOME STATEMENTS



|June 30,|2023|2022|
|---|---|---|
|Assets|||
|Current assets:|||
|Cash and cash equivalents|$ 34,704|$ 13,931|
|Short-term investments|76,558|90,826|
|Total cash, cash equivalents, and short-term investments|111,262|104,757|
|Accounts receivable, net of allowance for doubtful accounts of $650 and $633|48,688|44,261|
|Inventories|2,500|3,742|
|Other current assets|21,807|16,924|
|Total current assets|184,257|169,684|
|Property and equipment, net of accumulated depreciation of $68,251 and $59,660|95,641|74,398|
|Operating lease right-of-use assets|14,346|13,148|
|Equity investments|9,879|6,891|
|Goodwill|67,886|67,524|
|Intangible assets, net|9,366|11,298|
|Other long-term assets|30,601|21,897|
|Total assets|$ 411,976|$ 364,840|
|Liabilities and stockholders' equity|||
|Current liabilities:|||
|Accounts payable|$ 18,095|$ 19,000|
|Current portion of long-term debt|5,247|2,749|
|Accrued compensation|11,009|10,661|
|Short-term income taxes|4,152|4,067|
|Short-term unearned revenue|50,901|45,538|
|Other current liabilities|14,745|13,067|
|Total current liabilities|104,149|95,082|
|Long-term debt|41,990|47,032|
|Long-term income taxes|25,560|26,069|
|Long-term unearned revenue|2,912|2,870|
|Deferred income taxes|433|230|
|Operating lease liabilities|12,728|11,489|
|Other long-term liabilities|17,981|15,526|
|Total liabilities|205,753|198,298|
|Commitments and contingencies|||
|Stockholders' equity:|||
|Common stock and paid-in capital - shares authorized 24,000; outstanding 7,432 and 7,464|93,718|86,939|
|Retained earnings|118,848|84,281|
|Accumulated other comprehensive loss|(6,343)|(4,678)|
|Total stockholders' equity|206,223|166,542|
|Total liabilities and stockholders' equity|$ 411,976|$ 364,840|




|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Operations||||
|Net income|$ 72,361|$ 72,738|$ 61,271|
|Adjustments to reconcile net income to net cash from operations:||||
|Depreciation, amortization, and other|13,861|14,460|11,686|
|Stock-based compensation expense|9,611|7,502|6,118|
|Net recognized losses (gains) on investments and derivatives|196|(409)|(1,249)|
|Deferred income taxes|(6,059)|(5,702)|(150 )|
|Changes in operating assets and liabilities:||||
|Accounts receivable|(4,087)|(6,834)|(6,481)|
|Inventories|1,242|(1,123)|(737)|
|Other current assets|(1,991)|(709 )|(932)|
|Other long-term assets|(2,833)|(2,805)|(3,459)|
|Accounts payable|(2,721)|2,943|2,798|
|Unearned revenue|5,535|5,109|4,633|
|Income taxes|(358)|696|(2,309)|
|Other current liabilities|2,272|2,344|4,149|
|Other long-term liabilities|553|825|1,402|
|Net cash from operations|87,582|89,035|76,740|
|Financing||||
|Cash premium on debt exchange|0|0|(1,754 )|
|Repayments of debt|(2,750)|(9,023)|(3,750)|
|Common stock issued|1,866|1,841|1,693|
|Common stock repurchased|(22,245)|(32,696 )|(27,385 )|
|Common stock cash dividends paid|(19,800)|(18,135 )|(16,521 )|
|Other, net|(1,006)|(863)|(769)|
|Net cash used in financing|(43,935)|(58,876 )|(48,486 )|
|Investing||||
|Additions to property and equipment|(28,107)|(23,886 )|(20,622 )|
|Acquisition of companies, net of cash acquired, and purchases of intangible and other assets|(1,670)|(22,038 )|(8,909)|
|Purchases of investments|(37,651 )|(26,456 )|(62,924 )|
|Maturities of investments|33,510|16,451|51,792|
|Sales of investments|14,354|28,443|14,008|
|Other, net|(3,116)|(2,825)|(922)|
|Net cash used in investing|(22,680 )|(30,311 )|(27,577 )|
|Effect of foreign exchange rates on cash and cash equivalents|(194)|(141)|(29)|
|Net change in cash and cash equivalents|20,773|(293 )|648|
|Cash and cash equivalents, beginning of period|13,931|14,224|13,576|
|Cash and cash equivalents, end of period|$ 34,704|$ 13,931|$ 14,224|




|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Net income|$ 72,361|$ 72,738|$ 61,271|
|Other comprehensive income (loss), net of tax:||||
|Net change related to derivatives|(14)|6|19|
|Net change related to investments|(1,444)|(5,360)|(2,266)|
|Translation adjustments and other|(207)|(1,146)|873|
|Other comprehensive loss|(1,665)|(6,500)|(1,374)|
|Comprehensive income|$ 70,696|$ 66,238|$ 59,897|


Refer to accompanying notes.

59

PART II Item 8

BALANCE SHEETS

(In millions)

Refer to accompanying notes.

60

PART II Item 8

CASH FLOWS STATEMENTS

Refer to accompanying notes.

61

PART II Item 8

STOCKHOLDERS' EQUITY STATEMENTS

## (In millions, except per share amounts)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Common stock and paid-in capital||||
|Balance, beginning of period|$ 86,939|$ 83,111|$ 80,552|
|Common stock issued|1,866|1,841|1,963|
|Common stock repurchased|(4,696)|(5,688)|(5,539)|
|Stock-based compensation expense|9,611|7,502|6,118|
|Other, net|(2)|173|17|
|Balance, end of period|93,718|86,939|83,111|
|Retained earnings||||
|Balance, beginning of period|84,281|57,055|34,566|
|Net income|72,361|72,738|61,271|
|Common stock cash dividends|(20,226)|(18,552 )|(16,871 )|
|Common stock repurchased|(17,568)|(26,960 )|(21,879 )|
|Cumulative effect of accounting changes|0|0|(32)|
|Balance, end of period|118,848|84,281|57,055|
|Accumulated other comprehensive income (loss)||||
|Balance, beginning of period|(4,678)|1,822|3,186|
|Other comprehensive loss|(1,665)|(6,500)|(1,374)|
|Cumulative effect of accounting changes|0|0|10|
|Balance, end of period|(6,343)|(4,678)|1,822|
|Total stockholders' equity|$ 206,223|$ 166,542|$ 141,988|
|Cash dividends declared per common share|$ 2.72|$ 2.48|$ 2.24|


Refer to accompanying notes.

62

PART II Item 8

NOTES TO FINANCIAL STATEMENTS NOTE 1 - ACCOUNTING POLICIES

## Accounting Principles

Our consolidated financial statements and accompanying notes are prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").

We have recast certain prior period amounts to conform to the current period presentation. The recast of these prior period amounts had no impact on our consolidated balance sheets, consolidated income statements, or consolidated cash flows statements.

## Principles of Consolidation

The consolidated financial statements include the accounts of Microsoft Corporation and its subsidiaries. Intercompany transactions and balances have been eliminated.

## Estimates and Assumptions

Preparing financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, and expenses. Examples of estimates and assumptions include: for revenue recognition, determining the nature and timing of satisfaction of performance obligations, and determining the standalone selling price ("SSP") of performance obligations, variable consideration, and other obligations such as product returns and refunds; loss contingencies; product warranties; the fair value of and/or potential impairment of goodwill and intangible assets for our reporting units; product life cycles; useful lives of our tangible and intangible assets; allowances for doubtful accounts; the market value of, and demand for, our inventory; stock-based compensation forfeiture rates; when technological feasibility is achieved for our products; the potential outcome of uncertain tax positions that have been recognized in our consolidated financial statements or tax returns; and determining the timing and amount of impairments for investments. Actual results and outcomes may differ from management's estimates and assumptions due to risks and uncertainties.

In July 2022, we completed an assessment of the useful lives of our server and network equipment. Due to investments in software that increased efficiencies in how we operate our server and network equipment, as well as advances in technology, we determined we should increase the estimated useful lives of both server and network equipment from four years to six years. This change in accounting estimate was effective beginning fiscal year 2023. Based on the carrying amount of server and network equipment included in property and equipment, net as of June 30, 2022, the effect of this change in estimate for fiscal year 2023 was an increase in operating income of $3.7 billion and net income of $3.0 billion, or $0.40 per both basic and diluted share.

## Foreign Currencies

Assets and liabilities recorded in foreign currencies are translated at the exchange rate on the balance sheet date. Revenue and expenses are translated at average rates of exchange prevailing during the year. Translation adjustments resulting from this process are recorded to other comprehensive income.

## Product Revenue and Service and Other Revenue

Product revenue includes sales from operating systems, cross-device productivity and collaboration applications, server applications, business solution applications, desktop and server management tools, software development tools, video games, and hardware such as PCs, tablets, gaming and entertainment consoles, other intelligent devices, and related accessories.

Service and other revenue includes sales from cloud-based solutions that provide customers with software, services, platforms, and content such as Office 365, Azure, Dynamics 365, and Xbox; solution support; and consulting services. Service and other revenue also includes sales from online advertising and Linkedln.

63

PART II Item 8

## Revenue Recognition

Revenue is recognized upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to receive in exchange for those products or services. We enter into contracts that can include various combinations of products and services, which are generally capable of being distinct and accounted for as separate performance obligations. Revenue is recognized net of allowances for returns and any taxes collected from customers, which are subsequently remitted to governmental authorities.

## Nature of Products and Services

Licenses for on-premises software provide the customer with a right to use the software as it exists when made available to the customer. Customers may purchase perpetual licenses or subscribe to licenses, which provide customers with the same functionality and differ mainly in the duration over which the customer benefits from the software. Revenue from distinct on-premises licenses is recognized upfront at the point in time when the software is made available to the customer. In cases where we allocate revenue to software updates, primarily because the updates are provided at no additional charge, revenue is recognized as the updates are provided, which is generally ratably over the estimated life of the related device or license.

Certain volume licensing programs, including Enterprise Agreements, include on-premises licenses combined with Software Assurance ("SA"). SA conveys rights to new software and upgrades released over the contract period and provides support, tools, and training to help customers deploy and use products more efficiently. On-premises licenses are considered distinct performance obligations when sold with SA. Revenue allocated to SA is generally recognized ratably over the contract period as customers simultaneously consume and receive benefits, given that SA comprises distinct performance obligations that are satisfied over time.

Cloud services, which allow customers to use hosted software over the contract period without taking possession of the software, are provided on either a subscription or consumption basis. Revenue related to cloud services provided on a subscription basis is recognized ratably over the contract period. Revenue related to cloud services provided on a consumption basis, such as the amount of storage used in a period, is recognized based on the customer utilization of such resources. When cloud services require a significant level of integration and interdependency with software and the individual components are not considered distinct, all revenue is recognized over the period in which the cloud services are provided.

Revenue from search advertising is recognized when the advertisement appears in the search results or when the action necessary to earn the revenue has been completed. Revenue from consulting services is recognized as services are provided.

Our hardware is generally highly dependent on, and interrelated with, the underlying operating system and cannot function without the operating system. In these cases, the hardware and software license are accounted for as a single performance obligation and revenue is recognized at the point in time when ownership is transferred to resellers or directly to end customers through retail stores and online marketplaces.

Refer to Note 19 - Segment Information and Geographic Data for further information, including revenue by significant product and service offering.

## Significant Judgments

Our contracts with customers often include promises to transfer multiple products and services to a customer. Determining whether products and services are considered distinct performance obligations that should be accounted for separately versus together may require significant judgment. When a cloud- based service includes both on-premises software licenses and cloud services, judgment is required to determine whether the software license is considered distinct and accounted for separately, or not distinct and accounted for together with the cloud service and recognized over time. Certain cloud services, primarily Office 365, depend on a significant level of integration, interdependency, and interrelation between the desktop applications and cloud services, and are accounted for together as one performance obligation. Revenue from Office 365 is recognized ratably over the period in which the cloud services are provided.

64

PART II Item 8

Judgment is required to determine the SSP for each distinct performance obligation. We use a single amount to estimate SSP for items that are not sold separately, including on-premises licenses sold with SA or software updates provided at no additional charge. We use a range of amounts to estimate SSP when we sell each of the products and services separately and need to determine whether there is a discount to be allocated based on the relative SSP of the various products and services.

In instances where SSP is not directly observable, such as when we do not sell the product or service separately, we determine the SSP using information that may include market conditions and other observable inputs. We typically have more than one SSP for individual products and services due to the stratification of those products and services by customers and circumstances. In these instances, we may use information such as the size of the customer and geographic region in determining the SSP.

Due to the various benefits from and the nature of our SA program, judgment is required to assess the pattern of delivery, including the exercise pattern of certain benefits across our portfolio of customers.

Our products are generally sold with a right of return, we may provide other credits or incentives, and in certain instances we estimate customer usage of our products and services, which are accounted for as variable consideration when determining the amount of revenue to recognize. Returns and credits are estimated at contract inception and updated at the end of each reporting period if additional information becomes available. Changes to our estimated variable consideration were not material for the periods presented.

## Contract Balances and Other Receivables

Timing of revenue recognition may differ from the timing of invoicing to customers. We record a receivable when revenue is recognized prior to invoicing, or unearned revenue when revenue is recognized subsequent to invoicing. For multi-year agreements, we generally invoice customers annually at the beginning of each annual coverage period. We record a receivable related to revenue recognized for multi-year on-premises licenses as we have an unconditional right to invoice and receive payment in the future related to those licenses.

Unearned revenue comprises mainly unearned revenue related to volume licensing programs, which may include SA and cloud services. Unearned revenue is generally invoiced annually at the beginning of each contract period for multi-year agreements and recognized ratably over the coverage period. Unearned revenue also includes payments for consulting services to be performed in the future, Linkedln subscriptions, Office 365 subscriptions, Xbox subscriptions, Windows post-delivery support, Dynamics business solutions, and other offerings for which we have been paid in advance and earn the revenue when we transfer control of the product or service.

Refer to Note 13 - Unearned Revenue for further information, including unearned revenue by segment and changes in unearned revenue during the period.

Payment terms and conditions vary by contract type, although terms generally include a requirement of payment within 30 to 60 days. In instances where the timing of revenue recognition differs from the timing of invoicing, we have determined our contracts generally do not include a significant financing component. The primary purpose of our invoicing terms is to provide customers with simplified and predictable ways of purchasing our products and services, not to receive financing from our customers or to provide customers with financing. Examples include invoicing at the beginning of a subscription term with revenue recognized ratably over the contract period, and multi-year on-premises licenses that are invoiced annually with revenue recognized upfront.

As of June 30, 2023 and 2022, long-term accounts receivable, net of allowance for doubtful accounts, was $4.5 billion and $3.8 billion, respectively, and is included in other long-term assets in our consolidated balance sheets.

The allowance for doubtful accounts reflects our best estimate of probable losses inherent in the accounts receivable balance. We determine the allowance based on known troubled accounts, historical experience, and other currently available evidence.

65

PART II Item 8

## (In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Balance, beginning of period|$ 710|$ 798|$ 816|
|Charged to costs and other|258|157|234|
|Write-offs|(252)|(245)|(252)|
|Balance, end of period|$ 716|$ 710|$ 798|


Allowance for doubtful accounts included in our consolidated balance sheets:

(In millions)



|June 30,|2023|2022|2021|
|---|---|---|---|
|Accounts receivable, net of allowance for doubtful accounts|$ 650|$ 633|$ 751|
|Other long-term assets|66|77|47|
|Total|$ 716|$ 710|$ 798|


As of June 30, 2023 and 2022, other receivables related to activities to facilitate the purchase of server components were $9.2 billion and $6.1 billion, respectively, and are included in other current assets in our consolidated balance sheets.

We record financing receivables when we offer certain of our customers the option to acquire our software products and services offerings through a financing program in a limited number of countries. As of June 30, 2023 and 2022, our financing receivables, net were $5.3 billion and $4.1 billion, respectively, for short-term and long-term financing receivables, which are included in other current assets and other long-term assets in our consolidated balance sheets. We record an allowance to cover expected losses based on troubled accounts, historical experience, and other currently available evidence.

## Assets Recognized from Costs to Obtain a Contract with a Customer

We recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales incentive programs meet the requirements to be capitalized. Total capitalized costs to obtain a contract were immaterial during the periods presented and are included in other current and long-term assets in our consolidated balance sheets.

We apply a practical expedient to expense costs as incurred for costs to obtain a contract with a customer when the amortization period would have been one year or less. These costs include our internal sales organization compensation program and certain partner sales incentive programs as we have determined annual compensation is commensurate with annual sales activities.

## Cost of Revenue

Cost of revenue includes: manufacturing and distribution costs for products sold and programs licensed; operating costs related to product support service centers and product distribution centers; costs incurred to include software on PCs sold by original equipment manufacturers ("OEM"), to drive traffic to our websites, and to acquire online advertising space; costs incurred to support and maintain cloud-based and other online products and services, including datacenter costs and royalties; warranty costs; inventory valuation adjustments; costs associated with the delivery of consulting services; and the amortization of capitalized software development costs. Capitalized software development costs are amortized over the estimated lives of the products.

66

PART II Item 8

## Product Warranty

We provide for the estimated costs of fulfilling our obligations under hardware and software warranties at the time the related revenue is recognized. For hardware warranties, we estimate the costs based on historical and projected product failure rates, historical and projected repair costs, and knowledge of specific product failures (if any). The specific hardware warranty terms and conditions vary depending upon the product sold and the country in which we do business, but generally include parts and labor over a period generally ranging from 90 days to three years. For software warranties, we estimate the costs to provide bug fixes, such as security patches, over the estimated life of the software. We regularly reevaluate our estimates to assess the adequacy of the recorded warranty liabilities and adjust the amounts as necessary.

## Research and Development

Research and development expenses include payroll, employee benefits, stock-based compensation expense, and other headcount-related expenses associated with product development. Research and development expenses also include third-party development and programming costs and the amortization of purchased software code and services content. Such costs related to software development are included in research and development expense until the point that technological feasibility is reached, which for our software products, is generally shortly before the products are released to production. Once technological feasibility is reached, such costs are capitalized and amortized to cost of revenue over the estimated lives of the products.

## Sales and Marketing

Sales and marketing expenses include payroll, employee benefits, stock-based compensation expense, and other headcount-related expenses associated with sales and marketing personnel, and the costs of advertising, promotions, trade shows, seminars, and other programs. Advertising costs are expensed as incurred. Advertising expense was $904 million, $1.5 billion, and $1.5 billion in fiscal years 2023, 2022, and 2021, respectively.

## Stock-Based Compensation

Compensation cost for stock awards, which include restricted stock units ("RSUs") and performance stock units ("PSUs"), is measured at the fair value on the grant date and recognized as expense, net of estimated forfeitures, over the related service or performance period. The fair value of stock awards is based on the quoted price of our common stock on the grant date less the present value of expected dividends not received during the vesting period. We measure the fair value of PSUs using a Monte Carlo valuation model. Compensation cost for RSUs is recognized using the straight-line method and for PSUs is recognized using the accelerated method.

Compensation expense for the employee stock purchase plan ("ESPP") is measured as the discount the employee is entitled to upon purchase and is recognized in the period of purchase.

## Employee Severance

On January 18, 2023, we announced a decision to reduce our overall workforce by approximately 10,000 jobs through the third quarter of fiscal year 2023. During the three months ended December 31, 2022, we recorded $800 million of employee severance expenses related to these job eliminations as part of an ongoing employee benefit plan. These employee severance expenses were incurred as part of a corporate program, and were included in general and administrative expenses in our consolidated income statements and allocated to our segments based on relative gross margin. Refer to Note 19 - Segment Information and Geographic Data for further information.

## Income Taxes

Income tax expense includes U.S. and international income taxes, and interest and penalties on uncertain tax positions. Certain income and expenses are not reported in tax returns and financial statements in the same year. The tax effect of such temporary differences is reported as deferred income taxes. Deferred tax assets are reported net of a valuation allowance when it is more likely than not that a tax benefit will not be realized. All deferred income taxes are classified as long-term in our consolidated balance sheets.

67

PART II Item 8

## Investments

We consider all highly liquid interest-earning investments with a maturity of three months or less at the date of purchase to be cash equivalents. The fair values of these investments approximate their carrying values. In general, investments with original maturities of greater than three months and remaining maturities of less than one year are classified as short-term investments. Investments with maturities beyond one year may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations.

Debt investments are classified as available-for-sale and realized gains and losses are recorded using the specific identification method. Changes in fair value, excluding credit losses and impairments, are recorded in other comprehensive income. Fair value is calculated based on publicly available market information or other estimates determined by management. If the cost of an investment exceeds its fair value, we evaluate, among other factors, general market conditions, credit quality of debt instrument issuers, and the extent to which the fair value is less than cost. To determine credit losses, we employ a systematic methodology that considers available quantitative and qualitative evidence. In addition, we consider specific adverse conditions related to the financial health of, and business outlook for, the investee. If we have plans to sell the security or it is more likely than not that we will be required to sell the security before recovery, then a decline in fair value below cost is recorded as an impairment charge in other income (expense), net and a new cost basis in the investment is established. If market, industry, and/or investee conditions deteriorate, we may incur future impairments.

Equity investments with readily determinable fair values are measured at fair value. Equity investments without readily determinable fair values are measured using the equity method or measured at cost with adjustments for observable changes in price or impairments (referred to as the measurement alternative). We perform a qualitative assessment on a periodic basis and recognize an impairment if there are sufficient indicators that the fair value of the investment is less than carrying value. Changes in value are recorded in other income (expense), net.

## Derivatives

Derivative instruments are recognized as either assets or liabilities and measured at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation.

For derivative instruments designated as fair value hedges, gains and losses are recognized in other income (expense), net with offsetting gains and losses on the hedged items. Gains and losses representing hedge components excluded from the assessment of effectiveness are recognized in other income (expense), net.

For derivative instruments designated as cash flow hedges, gains and losses are initially reported as a component of other comprehensive income and subsequently recognized in other income (expense), net with the corresponding hedged item. Gains and losses representing hedge components excluded from the assessment of effectiveness are recognized in other income (expense), net.

For derivative instruments that are not designated as hedges, gains and losses from changes in fair values are primarily recognized in other income (expense), net.

68

PART II Item 8

## Fair Value Measurements

We account for certain assets and liabilities at fair value. The hierarchy below lists three levels of fair value based on the extent to which inputs used in measuring fair value are observable in the market. We categorize each of our fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

·Level 1 - inputs are based upon unadjusted quoted prices for identical instruments in active markets. Our Level 1 investments include U.S. government securities, common and preferred stock, and mutual funds. Our Level 1 derivative assets and liabilities include those actively traded on exchanges.

·Level 2 - inputs are based upon quoted prices for similar instruments in active markets, quoted prices for identical or similar instruments in markets that are not active, and model-based valuation techniques (e.g. the Black-Scholes model) for which all significant inputs are observable in the market or can be corroborated by observable market data for substantially the full term of the assets or liabilities. Where applicable, these models project future cash flows and discount the future amounts to a present value using market-based observable inputs including interest rate curves, credit spreads, foreign exchange rates, and forward and spot prices for currencies. Our Level 2 investments include commercial paper, certificates of deposit, U.S. agency securities, foreign government bonds, mortgage- and asset-backed securities, corporate notes and bonds, and municipal securities. Our Level 2 derivative assets and liabilities include certain cleared swap contracts and over-the-counter forward, option, and swap contracts.

·Level 3 - inputs are generally unobservable and typically reflect management's estimates of assumptions that market participants would use in pricing the asset or liability. The fair values are therefore determined using model-based techniques, including option pricing models and discounted cash flow models. Our Level 3 assets and liabilities include investments in corporate notes and bonds, municipal securities, and goodwill and intangible assets, when they are recorded at fair value due to an impairment charge. Unobservable inputs used in the models are significant to the fair values of the assets and liabilities.

We measure equity investments without readily determinable fair values on a nonrecurring basis. The fair values of these investments are determined based on valuation techniques using the best information available, and may include quoted market prices, market comparables, and discounted cash flow projections.

Our other current financial assets and current financial liabilities have fair values that approximate their carrying values.

## Inventories

Inventories are stated at average cost, subject to the lower of cost or net realizable value. Cost includes materials, labor, and manufacturing overhead related to the purchase and production of inventories. Net realizable value is the estimated selling price less estimated costs of completion, disposal, and transportation. We regularly review inventory quantities on hand, future purchase commitments with our suppliers, and the estimated utility of our inventory. If our review indicates a reduction in utility below carrying value, we reduce our inventory to a new cost basis through a charge to cost of revenue.

## Property and Equipment

Property and equipment is stated at cost less accumulated depreciation, and depreciated using the straight-line method over the shorter of the estimated useful life of the asset or the lease term. The estimated useful lives of our property and equipment are generally as follows: computer software developed or acquired for internal use, three years; computer equipment, two to six years; buildings and improvements, five to 15 years; leasehold improvements, three to 20 years; and furniture and equipment, one to 10 years. Land is not depreciated.

## Leases

We determine if an arrangement is a lease at inception. Operating leases are included in operating lease right-of-use ("ROU") assets, other current liabilities, and operating lease liabilities in our consolidated balance sheets. Finance leases are included in property and equipment, other current liabilities, and other long-term liabilities in our consolidated balance sheets.

69

PART II Item 8

ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments arising from the lease. Operating lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of our leases do not provide an implicit rate, we generally use our incremental borrowing rate based on the estimated rate of interest for collateralized borrowing over a similar term of the lease payments at commencement date. The operating lease ROU asset also includes any lease payments made and excludes lease incentives. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

We have lease agreements with lease and non-lease components, which are generally accounted for separately. For certain equipment leases, such as vehicles, we account for the lease and non-lease components as a single lease component. Additionally, for certain equipment leases, we apply a portfolio approach to effectively account for the operating lease ROU assets and liabilities.

## Goodwill

Goodwill is tested for impairment at the reporting unit level (operating segment or one level below an operating segment) on an annual basis (May 1) and between annual tests if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value.

## Intangible Assets

Our intangible assets are subject to amortization and are amortized using the straight-line method over their estimated period of benefit, ranging from one to 20 years. We evaluate the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired.

## NOTE 2 - EARNINGS PER SHARE

Basic earnings per share ("EPS") is computed based on the weighted average number of shares of common stock outstanding during the period. Diluted EPS is computed based on the weighted average number of shares of common stock plus the effect of dilutive potential common shares outstanding during the period using the treasury stock method. Dilutive potential common shares include outstanding stock options and stock awards.

The components of basic and diluted EPS were as follows:

(In millions, except earnings per share)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Net income available for common shareholders (A)|$ 72,361|$ 72,738|$ 61,271|
|Weighted average outstanding shares of common stock (B)|7,446|7,496|7,547|
|Dilutive effect of stock-based awards|26|44|61|
|Common stock and common stock equivalents (C)|7,472|7,540|7,608|
|Earnings Per Share||||
|Basic (A/B)|$ 9.72|$ 9.70|$ 8.12|
|Diluted (A/C)|$ 9.68|$ 9.65|$ 8.05|


Anti-dilutive stock-based awards excluded from the calculations of diluted EPS were immaterial during the periods presented.

70

PART II Item 8

NOTE 3 - OTHER INCOME (EXPENSE), NET

The components of other income (expense), net were as follows:

## (In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Interest and dividends income|$ 2,994|$ 2,094|$ 2,131|
|Interest expense|(1,968)|(2,063)|(2,346)|
|Net recognized gains on investments|260|461|1,232|
|Net gains (losses) on derivatives|(456)|(52)|17|
|Net gains (losses) on foreign currency remeasurements|181|(75)|54|
|Other, net|(223)|(32)|98|
|Total|$ 788|$ 333|$ 1,186|


## Net Recognized Gains (Losses) on Investments

Net recognized gains (losses) on debt investments were as follows:

(In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Realized gains from sales of available-for-sale securities|$ 36|$ 162|$ 105|
|Realized losses from sales of available-for-sale securities|(124)|(138)|(40)|
|Impairments and allowance for credit losses|(10)|(81)|(2)|
|Total|$ (98)|$ (57)|$ 63|


Net recognized gains (losses) on equity investments were as follows:

(In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Net realized gains on investments sold|$ 75|$ 29|$ 123|
|Net unrealized gains on investments still held|303|509|1,057|
|Impairments of investments|(20)|(20)|(11)|
|Total|$ 358|$ 518|$ 1,169|


71

PART II Item 8

NOTE 4 - INVESTMENTS



|(In millions)|Fair Value Level|Adjusted Cost Basis|Unrealized Gains|Unrealized Losses|Recorded Basis|Cash and Cash Equivalents|Short-term Investments|Equity Investments|
|---|---|---|---|---|---|---|---|---|
|June 30, 2023|||||||||
|Changes in Fair Value Recorded in Other Comprehensive Income|||||||||
|Commercial paper|Level 2|$ 16,589|$ 0|$ 0|$ 16,589|$ 12,231|$ 4,358|$ 0|
|Certificates of deposit|Level 2|2,701|0|0|2,701|2,657|44|0|
|U.S. government securities|Level 1|65,237|2|(3,870)|61,369|2,991|58,378|0|
|U.S. agency securities|Level 2|2,703|0|0|2,703|894|1,809|0|
|Foreign government bonds|Level 2|498|1|(24)|475|0|475|0|
|Mortgage- and asset- backed securities|Level 2|824|1|(39)|786|0|786|0|
|Corporate notes and bonds|Level 2|10,809|8|(583)|10,234|0|10,234|0|
|Corporate notes and bonds|Level 3|120|0|0|120|0|120|0|
|Municipal securities|Level 2|285|1|(18)|268|7|261|0|
|Municipal securities|Level 3|103|0|(16)|87|0|87|0|
|Total debt investments||$ 99,869|$ 13|$ (4,550)|$ 95,332|$ 18,780|$ 76,552|$ 0|
|Changes in Fair Value Recorded in Net Income|||||||||
|Equity investments|Level 1||||$ 10,138|$ 7,446|$ 0|$ 2,692|
|Equity investments|Other||||7,187|0|0|7,187|
|Total equity investments|||||$ 17,325|$ 7,446|$ 0|$ 9,879|
|Cash|||||$ 8,478|$ 8,478|$ 0|$ 0|
|Derivatives, net (a)|||||6|0|6|0|
|Total|||||$ 121,141|$ 34,704|$ 76,558|$ 9,879|




|(In millions)|Fair Value Level|Adjusted Cost Basis|Unrealized Gains|Unrealized Losses|Recorded Basis|Cash and Cash Equivalents|Short-term Investments|Equity Investments|
|---|---|---|---|---|---|---|---|---|
|June 30, 2022|||||||||
|Changes in Fair Value Recorded in Other Comprehensive Income|||||||||
|Commercial paper|Level 2|$ 2,500|$ 0|$ 0|$ 2,500|$ 2,498|$ 2|$ 0|
|Certificates of deposit|Level 2|2,071|0|0|2,071|2,032|39|0|
|U.S. government securities|Level 1|79,696|29|(2,178)|77,547|9|77,538|0|
|U.S. agency securities|Level 2|419|0|(9)|410|0|410|0|
|Foreign government bonds|Level 2|506|0|(24)|482|0|482|0|
|Mortgage- and asset- backed securities|Level 2|727|1|(30)|698|0|698|0|
|Corporate notes and bonds|Level 2|11,661|4|(554)|11,111|0|11,111|0|
|Corporate notes and bonds|Level 3|67|0|0|67|0|67|0|
|Municipal securities|Level 2|368|19|(13)|374|0|374|0|
|Municipal securities|Level 3|103|0|(6)|97|0|97|0|
|Total debt investments||$ 98,118|$ 53|$ (2,814)|$ 95,357|$ 4,539|$ 90,818|$ 0|
|Changes in Fair Value Recorded in Net Income|||||||||
|Equity investments|Level 1||||$ 1,590|$ 1,134|$ 0|$ 456|
|Equity investments|Other||||6,435|0|0|6,435|
|Total equity investments|||||$ 8,025|$ 1,134|$ 0|$ 6,891|
|Cash|||||$ 8,258|$ 8,258|$ 0|$ 0|
|Derivatives, net (a)|||||8|0|8|0|
|Total|||||$ 111,648|$ 13,931|$ 90,826|$ 6,891|


## The components of investments were as follows:

72

PART II Item 8

(a)Refer to Note 5 - Derivatives for further information on the fair value of our derivative instruments.

Equity investments presented as "Other" in the tables above include investments without readily determinable fair values measured using the equity method or measured at cost with adjustments for observable changes in price or impairments, and investments measured at fair value using net asset value as a practical expedient which are not categorized in the fair value hierarchy. As of June 30, 2023 and 2022, equity investments without readily determinable fair values measured at cost with adjustments for observable changes in price or impairments were $4.2 billion and $3.8 billion, respectively.

73

PART II Item 8

## Unrealized Losses on Debt Investments

Debt investments with continuous unrealized losses for less than 12 months and 12 months or greater and their related fair values were as follows:



|(In millions)|Less than 12 Months||12 Months or Greater|||Total Unrealized Losses|
|---|---|---|---|---|---|---|
||Fair Value|Unrealized Losses|Fair Value|Unrealized Losses|Total Fair Value||
|June 30, 2023|||||||
|U.S. government and agency securities|$ 7,950|$ (336)|$ 45,273|$ (3,534)|$ 53,223|$ (3,870)|
|Foreign government bonds|77|(5)|391|(19)|468|(24)|
|Mortgage- and asset-backed securities|257|(5)|412|(34)|669|(39)|
|Corporate notes and bonds|2,326|(49)|7,336|(534)|9,662|(583)|
|Municipal securities|111|(3)|186|(31)|297|(34)|
|Total|$ 10,721|$ (398)|$ 53,598|$ (4,152)|$ 64,319|$ (4,550)|




|(In millions)|Less than 12 Months||12 Months or Greater Unrealized Total Fair Value Losses Fair Value|||Total Unrealized Losses|
|---|---|---|---|---|---|---|
||Fair Value|Unrealized Losses|||||
|June 30, 2022|||||||
|U.S. government and agency securities|$ 59,092|$ (1,835)|$ 2,210|$ (352)|$ 61,302|$ (2,187)|
|Foreign government bonds|418|(18)|27|(6)|445|(24)|
|Mortgage- and asset-backed securities|510|(26)|41|(4)|551|(30)|
|Corporate notes and bonds|9,443|(477)|786|(77)|10,229|(554 )|
|Municipal securities|178|(12)|74|(7)|252|(19)|
|Total|$ 69,641|$ (2,368)|$ 3,138|$ (446 )|$ 72,779|$ (2,814)|


Unrealized losses from fixed-income securities are primarily attributable to changes in interest rates. Management does not believe any remaining unrealized losses represent impairments based on our evaluation of available evidence.

## Debt Investment Maturities



|(In millions)|Adjusted Cost Basis|Estimated Fair Value|
|---|---|---|
|June 30, 2023|||
|Due in one year or less|$ 38,182|$ 38,048|
|Due after one year through five years|47,127|44,490|
|Due after five years through 10 years|13,262|11,628|
|Due after 10 years|1,298|1,166|
|Total|$ 99,869|$ 95,332|


74

PART II Item 8

NOTE 5 - DERIVATIVES

We use derivative instruments to manage risks related to foreign currencies, interest rates, equity prices, and credit; to enhance investment returns; and to facilitate portfolio diversification. Our objectives for holding derivatives include reducing, eliminating, and efficiently managing the economic impact of these exposures as effectively as possible. Our derivative programs include strategies that both qualify and do not qualify for hedge accounting treatment.

## Foreign Currencies

Certain forecasted transactions, assets, and liabilities are exposed to foreign currency risk. We monitor our foreign currency exposures daily to maximize the economic effectiveness of our foreign currency hedge positions.

Foreign currency risks related to certain non-U.S. dollar-denominated investments are hedged using foreign exchange forward contracts that are designated as fair value hedging instruments. Foreign currency risks related to certain Euro-denominated debt are hedged using foreign exchange forward contracts that are designated as cash flow hedging instruments.

Certain options and forwards not designated as hedging instruments are also used to manage the variability in foreign exchange rates on certain balance sheet amounts and to manage other foreign currency exposures.

## Interest Rate

Interest rate risks related to certain fixed-rate debt are hedged using interest rate swaps that are designated as fair value hedging instruments to effectively convert the fixed interest rates to floating interest rates.

Securities held in our fixed-income portfolio are subject to different interest rate risks based on their maturities. We manage the average maturity of our fixed-income portfolio to achieve economic returns that correlate to certain broad-based fixed-income indices using option, futures, and swap contracts. These contracts are not designated as hedging instruments and are included in "Other contracts" in the tables below.

## Equity

Securities held in our equity investments portfolio are subject to market price risk. At times, we may hold options, futures, and swap contracts. These contracts are not designated as hedging instruments.

## Credit

Our fixed-income portfolio is diversified and consists primarily of investment-grade securities. We use credit default swap contracts to manage credit exposures relative to broad-based indices and to facilitate portfolio diversification. These contracts are not designated as hedging instruments and are included in "Other contracts" in the tables below.

## Credit-Risk-Related Contingent Features

Certain of our counterparty agreements for derivative instruments contain provisions that require our issued and outstanding long-term unsecured debt to maintain an investment grade credit rating and require us to maintain minimum liquidity of $1.0 billion. To the extent we fail to meet these requirements, we will be required to post collateral, similar to the standard convention related to over-the-counter derivatives. As of June 30, 2023, our long-term unsecured debt rating was AAA, and cash investments were in excess of $1.0 billion. As a result, no collateral was required to be posted.

75

## PART II Item 8

The following table presents the notional amounts of our outstanding derivative instruments measured in U.S. dollar equivalents:



|(In millions)|June 30,|June 30,|
|---|---|---|
||2023|2022|
|Designated as Hedging Instruments|||
|Foreign exchange contracts purchased|$ 1,492|$ 635|
|Interest rate contracts purchased|1,078|1,139|
|Not Designated as Hedging Instruments|||
|Foreign exchange contracts purchased|7,874|10,322|
|Foreign exchange contracts sold|25,159|21,606|
|Equity contracts purchased|3,867|1,131|
|Equity contracts sold|2,154|0|
|Other contracts purchased|1,224|1,642|
|Other contracts sold|581|544|


## Fair Values of Derivative Instruments

The following table presents our derivative instruments:



|(In millions)|Derivative Assets|Derivative Liabilities June 30, 2023|Derivative Assets|Derivative Liabilities June 30, 2022|
|---|---|---|---|---|
|Designated as Hedging Instruments|||||
|Foreign exchange contracts|$ 34|$ (67)|$ 0|$ (77)|
|Interest rate contracts|16|0|3|0|
|Not Designated as Hedging Instruments|||||
|Foreign exchange contracts|249|(332)|333|(362)|
|Equity contracts|165|(400)|5|(95)|
|Other contracts|5|(6)|15|(17)|
|Gross amounts of derivatives|469|(805)|356|(551)|
|Gross amounts of derivatives offset in the balance sheet|(202)|206|(130)|133|
|Cash collateral received|0|(125)|0|(75)|
|Net amounts of derivatives|$ 267|$ (724)|$ 226|$ (493 )|
|Reported as|||||
|Short-term investments|$ 6|$ 0|$ 8|$ 0|
|Other current assets|245|0|218|0|
|Other long-term assets|16|0|0|0|
|Other current liabilities|0|(341)|0|(298)|
|Other long-term liabilities|0|(383)|0|(195)|
|Total|$ 267|$ (724)|$ 226|$ (493)|


Gross derivative assets and liabilities subject to legally enforceable master netting agreements for which we have elected to offset were $442 million and $804 million, respectively, as of June 30, 2023, and $343 million and $550 million, respectively, as of June 30, 2022.

The following table presents the fair value of our derivatives instruments on a gross basis:



|(In millions)|Level 1|Level 2|Level 3|Total|
|---|---|---|---|---|
|June 30, 2023|||||
|Derivative assets|$ 0|$ 462|$ 7|$ 469|
|Derivative liabilities|0|(805)|0|(805)|
|June 30, 2022|||||
|Derivative assets|1|349|6|356|
|Derivative liabilities|0|(551)|0|(551)|


76

PART II Item 8

Gains (losses) on derivative instruments recognized in other income (expense), net were as follows:

(In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Designated as Fair Value Hedging Instruments||||
|Foreign exchange contracts||||
|Derivatives|$ 0|$ 49|$ 193|
|Hedged items|0|(50)|(188)|
|Excluded from effectiveness assessment|0|4|30|
|Interest rate contracts||||
|Derivatives|(65)|(92)|(37)|
|Hedged items|38|108|53|
|Designated as Cash Flow Hedging Instruments||||
|Foreign exchange contracts||||
|Amount reclassified from accumulated other comprehensive income|61|(79)|17|
|Not Designated as Hedging Instruments||||
|Foreign exchange contracts|(73)|383|27|
|Equity contracts|(420)|13|(6)|
|Other contracts|(41)|(85)|15|


Gains (losses), net of tax, on derivative instruments recognized in our consolidated comprehensive income statements were as follows:

(In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Designated as Cash Flow Hedging Instruments||||
|Foreign exchange contracts||||
|Included in effectiveness assessment|$ 34|$ (57)|$ 34|


## NOTE 6 - INVENTORIES

The components of inventories were as follows:

## (In millions)



|June 30,|2023|2022|
|---|---|---|
|Raw materials|$ 709|$ 1,144|
|Work in process|23|82|
|Finished goods|1,768|2,516|
|Total|$ 2,500|$ 3,742|


77

PART II Item 8

NOTE 7 - PROPERTY AND EQUIPMENT

The components of property and equipment were as follows:



|June 30,|2023|2022|
|---|---|---|
|Land|$ 5,683|$ 4,734|
|Buildings and improvements|68,465|55,014|
|Leasehold improvements|8,537|7,819|
|Computer equipment and software|74,961|60,631|
|Furniture and equipment|6,246|5,860|
|Total, at cost|163,892|134,058|
|Accumulated depreciation|(68,251 )|(59,660 )|
|Total, net|$ 95,641|$ 74,398|


During fiscal years 2023, 2022, and 2021, depreciation expense was $11.0 billion, $12.6 billion, and $9.3 billion, respectively. Depreciation expense declined in fiscal year 2023 due to the change in estimated useful lives of our server and network equipment.

As of June 30, 2023, we have committed $13.5 billion for the construction of new buildings, building improvements, and leasehold improvements, primarily related to datacenters.

## Nuance Communications, Inc.

On March 4, 2022, we completed our acquisition of Nuance Communications, Inc. ("Nuance") for a total purchase price of $18.8 billion, consisting primarily of cash. Nuance is a cloud and artificial intelligence ("Al") software provider with healthcare and enterprise Al experience, and the acquisition will build on our industry-specific cloud offerings. The financial results of Nuance have been included in our consolidated financial statements since the date of the acquisition. Nuance is reported as part of our Intelligent Cloud segment.

The allocation of the purchase price to goodwill was completed as of December 31, 2022. The major classes of assets and liabilities to which we have allocated the purchase price were as follows:

## (In millions)



|Goodwill (a)|$ 16,326|
|---|---|
|Intangible assets|4,365|
|Other assets|42|
|Other liabilities (b)|(1,972)|
|Total|$ 18,761|


(a)Goodwill was assigned to our Intelligent Cloud segment and was primarily attributed to increased synergies that are expected to be achieved from the integration of Nuance. None of the goodwill is expected to be deductible for income tax purposes.

(b)Includes $986 million of convertible senior notes issued by Nuance in 2015 and 2017, substantially all of which have been redeemed.

Following are the details of the purchase price allocated to the intangible assets acquired:



|(In millions, except average life)|Amount|Weighted Average Life|
|---|---|---|
|Customer-related|$ 2,610|9 years|
|Technology-based|1,540|5 years|
|Marketing-related|215|4 years|
|Total|$ 4,365|7 years|


78

PART II Item 8

## ZeniMax Media Inc.

On March 9, 2021, we completed our acquisition of ZeniMax Media Inc. ("ZeniMax"), the parent company of Bethesda Softworks LLC ("Bethesda"), for a total purchase price of $8.1 billion, consisting primarily of cash. The purchase price included $766 million of cash and cash equivalents acquired. Bethesda is one of the largest, privately held game developers and publishers in the world, and brings a broad portfolio of games, technology, and talent to Xbox. The financial results of ZeniMax have been included in our consolidated financial statements since the date of the acquisition. ZeniMax is reported as part of our More Personal Computing segment.

The allocation of the purchase price to goodwill was completed as of December 31, 2021. The major classes of assets and liabilities to which we have allocated the purchase price were as follows:

## (In millions)



|Cash and cash equivalents|$ 766|
|---|---|
|Goodwill|5,510|
|Intangible assets|1,968|
|Other assets|121|
|Other liabilities|(244 )|
|Total|$ 8,121|


Goodwill was assigned to our More Personal Computing segment. The goodwill was primarily attributed to increased synergies that are expected to be achieved from the integration of ZeniMax. None of the goodwill is expected to be deductible for income tax purposes.

Following are details of the purchase price allocated to the intangible assets acquired:



|(In millions, except average life)|Amount|Weighted Average Life|
|---|---|---|
|Technology-based|$ 1,341|4 years|
|Marketing-related|627|11 years|
|Total|$ 1,968|6 years|


## Activision Blizzard, Inc.

On January 18, 2022, we entered into a definitive agreement to acquire Activision Blizzard, Inc. ("Activision Blizzard") for $95.00 per share in an all-cash transaction valued at $68.7 billion, inclusive of Activision Blizzard's net cash. Activision Blizzard is a leader in game development and an interactive entertainment content publisher. The acquisition will accelerate the growth in our gaming business across mobile, PC, console, and cloud gaming. The acquisition has been approved by Activision Blizzard's shareholders. We continue to work toward closing the transaction subject to obtaining required regulatory approvals and satisfaction of other customary closing conditions. Microsoft and Activision Blizzard have jointly agreed to extend the merger agreement through October 18, 2023 to allow for additional time to resolve remaining regulatory concerns.

NOTE 9 - GOODWILL

Changes in the carrying amount of goodwill were as follows:



|(In millions)|June 30, 2021|Acquisitions|Other|June 30, 2022|Acquisitions|Other|June 30, 2023|
|---|---|---|---|---|---|---|---|
|Productivity and Business Processes|$ 24,317|$ 599|$ (105)|$ 24,811|$ 11|$ (47)|$ 24,775|
|Intelligent Cloud|13,256|16,879|47|30,182|223|64|30,469|
|More Personal Computing|12,138|648|(255)|12,531|0|111|12,642|
|Total|$ 49,711|$ 18,126|$ (313)|$ 67,524|$ 234|$ 128|$ 67,886|


79

PART II Item 8

The measurement periods for the valuation of assets acquired and liabilities assumed end as soon as information on the facts and circumstances that existed as of the acquisition dates becomes available, but do not exceed 12 months. Adjustments in purchase price allocations may require a change in the amounts allocated to goodwill during the periods in which the adjustments are determined.

Any change in the goodwill amounts resulting from foreign currency translations and purchase accounting adjustments are presented as "Other" in the table above. Also included in "Other" are business dispositions and transfers between segments due to reorganizations, as applicable.

## Goodwill Impairment

We test goodwill for impairment annually on May 1 at the reporting unit level, primarily using a discounted cash flow methodology with a peer-based, risk- adjusted weighted average cost of capital. We believe use of a discounted cash flow approach is the most reliable indicator of the fair values of the businesses.

No instances of impairment were identified in our May 1, 2023, May 1, 2022, or May 1, 2021 tests. As of June 30, 2023 and 2022, accumulated goodwill impairment was $11.3 billion.

## NOTE 10 - INTANGIBLE ASSETS

The components of intangible assets, all of which are finite-lived, were as follows:



|(In millions)|Gross Carrying Amount|Accumulated Amortization|Net Carrying Amount|Gross Carrying Amount|Accumulated Amortization|Net Carrying Amount|
|---|---|---|---|---|---|---|
|June 30,|||2023|||2022|
|Technology-based|$ 11,245|$ (7,589)|$ 3,656|$ 11,277|$ (6,958)|$ 4,319|
|Customer-related|7,281|(4,047)|3,234|7,342|(3,171)|4,171|
|Marketing-related|4,935|(2,473)|2,462|4,942|(2,143)|2,799|
|Contract-based|29|(15)|14|16|(7)|9|
|Total|$ 23,490|$ (14,124)|$ 9,366|$ 23,577|$ (12,279 )|$ 11,298|


No material impairments of intangible assets were identified during fiscal years 2023, 2022, or 2021. We estimate that we have no significant residual value related to our intangible assets.

The components of intangible assets acquired during the periods presented were as follows:



|(In millions)|Amount|Weighted Average Life|Amount|Weighted Average Life|
|---|---|---|---|---|
|Year Ended June 30,|2023||2022||
|Technology-based|$ 522|7 years|$ 2,611|4 years|
|Customer-related|0|0 years|2,837|9 years|
|Marketing-related|7|5 years|233|4 years|
|Contract-based|12|3 years|0|0 years|
|Total|$ 541|6 years|$ 5,681|7 years|


Intangible assets amortization expense was $2.5 billion, $2.0 billion, and $1.6 billion for fiscal years 2023, 2022, and 2021, respectively.

80

PART II Item 8

The following table outlines the estimated future amortization expense related to intangible assets held as of June 30, 2023:

(In millions)



|(In millions, issuance by calendar year)|Maturities (calendar year)|Stated Interest Rate|Effective Interest Rate|June 30, 2023|June 30, 2022|
|---|---|---|---|---|---|
|2009 issuance of $3.8 billion|2039|5.20%|5.24%|$ 520|$ 520|
|2010 issuance of $4.8 billion|2040|4.50%|4.57%|486|486|
|2011 issuance of $2.3 billion|2041|5.30%|5.36%|718|718|
|2012 issuance of $2.3 billion|2042|3.50%|3.57%|454|1,204|
|2013 issuance of $5.2 billion|2023-2043|3.63%-4.88%|3.73%-4.92%|1,814|2,814|
|2013 issuance of €4.1 billion|2028-2033|2.63%-3.13%|2.69%-3.22%|2,509|2,404|
|2015 issuance of $23.8 billion|2025-2055|2.70%-4.75%|2.77%-4.78%|9,805|10,805|
|2016 issuance of $19.8 billion|2023-2056|2.00%-3.95%|2.10%-4.03%|9,430|9,430|
|2017 issuance of $17.0 billion|2024-2057|2.88%-4.50%|3.04%-4.53%|8,945|8,945|
|2020 issuance of $10.0 billion|2050-2060|2.53%-2.68%|2.53%-2.68%|10,000|10,000|
|2021 issuance of $8.2 billion|2052-2062|2.92%-3.04%|2.92%-3.04%|8,185|8,185|
|Total face value||||52,866|55,511|
|Unamortized discount and issuance costs||||(438 )|(471)|
|Hedge fair value adjustments (a)||||(106)|(68)|
|Premium on debt exchange||||(5,085)|(5,191)|
|Total debt||||47,237|49,781|
|Current portion of long-term debt||||(5,247)|(2,749)|
|Long-term debt||||$ 41,990|$ 47,032|




|Year Ending June 30,||
|---|---|
|2024|$ 2,363|
|2025|1,881|
|2026|1,381|
|2027|929|
|2028|652|
|Thereafter|2,160|
|Total|$ 9,366|


NOTE 11 - DEBT

The components of debt were as follows:

(a)Refer to Note 5 - Derivatives for further information on the interest rate swaps related to fixed-rate debt.

As of June 30, 2023 and 2022, the estimated fair value of long-term debt, including the current portion, was $46.2 billion and $50.9 billion, respectively. The estimated fair values are based on Level 2 inputs.

Debt in the table above is comprised of senior unsecured obligations and ranks equally with our other outstanding obligations. Interest is paid semi- annually, except for the Euro-denominated debt, which is paid annually. Cash paid for interest on our debt for fiscal years 2023, 2022, and 2021 was $1.7 billion, $1.9 billion, and $2.0 billion, respectively.

81

## PART II Item 8

The following table outlines maturities of our long-term debt, including the current portion, as of June 30, 2023:

(In millions)



|Year Ending June 30,||
|---|---|
|2024|$ 5,250|
|2025|2,250|
|2026|3,000|
|2027|8,000|
|2028|0|
|Thereafter|34,366|
|Total|$ 52,866|


## NOTE 12 - INCOME TAXES

Provision for Income Taxes

The components of the provision for income taxes were as follows:

(In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Current Taxes||||
|U.S. federal|$ 14,009|$ 8,329|$ 3,285|
|U.S. state and local|2,322|1,679|1,229|
|Foreign|6,678|6,672|5,467|
|Current taxes|$ 23,009|$ 16,680|$ 9,981|
|Deferred Taxes||||
|U.S. federal|$ (6,146)|$ (4,815)|$ 25|
|U.S. state and local|(477)|(1,062)|(204 )|
|Foreign|564|175|29|
|Deferred taxes|$ (6,059)|$ (5,702)|$ (150)|
|Provision for income taxes|$ 16,950|$ 10,978|$ 9,831|


82

PART II Item 8

## (In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|U.S.|$ 52,917|$ 47,837|$ 34,972|
|Foreign|36,394|35,879|36,130|
|Income before income taxes|$ 89,311|$ 83,716|$ 71,102|


## Effective Tax Rate

The items accounting for the difference between income taxes computed at the U.S. federal statutory rate and our effective rate were as follows:



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Federal statutory rate|21.0%|21.0%|21.0%|
|Effect of:||||
|Foreign earnings taxed at lower rates|(1.8)%|(1.3)%|(2.7)%|
|Impact of intangible property transfers|0%|(3.9)%|0%|
|Foreign-derived intangible income deduction|(1.3)%|1.1)%|(1.3)%|
|State income taxes, net of federal benefit|1.6%|1.4%|1.4%|
|Research and development credit|(1.1)%|(0.9)%|(0.9)%|
|Excess tax benefits relating to stock-based compensation|(0.7)%|(1.9)%|(2.4)%|
|Interest, net|0.8%|0.5%|0.5%|
|Other reconciling items, net|0.5%|(0.7)%|(1.8)%|
|Effective rate|19.0%|13.1%|13.8%|


In the first quarter of fiscal year 2022, we transferred certain intangible properties from our Puerto Rico subsidiary to the U.S. The transfer of intangible properties resulted in a $3.3 billion net income tax benefit in the first quarter of fiscal year 2022, as the value of future U.S. tax deductions exceeded the current tax liability from the U.S. global intangible low-taxed income ("GILTI") tax.

We have historically paid India withholding taxes on software sales through distributor withholding and tax audit assessments in India. In March 2021, the India Supreme Court ruled favorably in the case of Engineering Analysis Centre of Excellence Private Limited vs The Commissioner of Income Tax for companies in 86 separate appeals, some dating back to 2012, holding that software sales are not subject to India withholding taxes. Although we were not a party to the appeals, our software sales in India were determined to be not subject to withholding taxes. Therefore, we recorded a net income tax benefit of $620 million in the third quarter of fiscal year 2021 to reflect the results of the India Supreme Court decision impacting fiscal year 1996 through fiscal year 2016.

The decrease from the federal statutory rate in fiscal year 2023 is primarily due to earnings taxed at lower rates in foreign jurisdictions resulting from producing and distributing our products and services through our foreign regional operations center in Ireland. The decrease from the federal statutory rate in fiscal year 2022 is primarily due to the net income tax benefit related to the transfer of intangible properties, earnings taxed at lower rates in foreign jurisdictions resulting from producing and distributing our products and services through our foreign regional operations center in Ireland, and tax benefits relating to stock-based compensation. The decrease from the federal statutory rate in fiscal year 2021 is primarily due to earnings taxed at lower rates in foreign jurisdictions resulting from producing and distributing our products and services through our foreign regional operations centers in Ireland and Puerto Rico, tax benefits relating to stock-based compensation, and tax benefits from the India Supreme Court decision on withholding taxes. In fiscal year 2023, our foreign regional operating center in Ireland, which is taxed at a rate lower than the U.S. rate, generated 81% of our foreign income before tax. In fiscal years 2022 and 2021, our foreign regional operating centers in Ireland and Puerto Rico, which are taxed at rates lower than the U.S. rate, generated 71% and 82% of our foreign income before tax. Other reconciling items, net consists primarily of tax credits and GILTI tax, and in fiscal year 2021, includes tax benefits from the India Supreme Court decision on withholding taxes. In fiscal years 2023, 2022, and 2021, there were no individually significant other reconciling items.

83

PART II Item 8

The increase in our effective tax rate for fiscal year 2023 compared to fiscal year 2022 was primarily due to a $3.3 billion net income tax benefit in the first quarter of fiscal year 2022 related to the transfer of intangible properties and a decrease in tax benefits relating to stock-based compensation. The decrease in our effective tax rate for fiscal year 2022 compared to fiscal year 2021 was primarily due to a $3.3 billion net income tax benefit in the first quarter of fiscal year 2022 related to the transfer of intangible properties, offset in part by changes in the mix of our income before income taxes between the U.S. and foreign countries, as well as tax benefits in the prior year from the India Supreme Court decision on withholding taxes, an agreement between the U.S. and India tax authorities related to transfer pricing, and final Tax Cuts and Jobs Act ("TCJA") regulations.

The components of the deferred income tax assets and liabilities were as follows:

(In millions)



|June 30,|2023|2022|
|---|---|---|
|Deferred Income Tax Assets|||
|Stock-based compensation expense|$ 681|$ 601|
|Accruals, reserves, and other expenses|3,131|2,874|
|Loss and credit carryforwards|1,441|1,546|
|Amortization (a)|9,440|10,183|
|Leasing liabilities|5,041|4,557|
|Unearned revenue|3,296|2,876|
|Book/tax basis differences in investments and debt|373|0|
|Capitalized research and development (a)|6,958|473|
|Other|489|461|
|Deferred income tax assets|30,850|23,571|
|Less valuation allowance|(939)|(1,012)|
|Deferred income tax assets, net of valuation allowance|$ 29,911|$ 22,559|
|Deferred Income Tax Liabilities|||
|Book/tax basis differences in investments and debt|$ 0|$ (174)|
|Leasing assets|(4,680)|(4,291)|
|Depreciation|(2,674)|(1,602)|
|Deferred tax on foreign earnings|(2,738)|(3,104)|
|Other|(89)|(103)|
|Deferred income tax liabilities|$ (10,181 )|$ (9,274)|
|Net deferred income tax assets|$ 19,730|$ 13,285|
|Reported As|||
|Other long-term assets|$ 20,163|$ 13,515|
|Long-term deferred income tax liabilities|(433)|(230)|
|Net deferred income tax assets|$ 19,730|$ 13,285|


(a)Provisions enacted in the TCJA related to the capitalization for tax purposes of research and development expenditures became effective on July 1, 2022. These provisions require us to capitalize research and development expenditures and amortize them on our U.S. tax return over five or fifteen years, depending on where research is conducted.

Deferred income tax balances reflect the effects of temporary differences between the carrying amounts of assets and liabilities and their tax bases and are stated at enacted tax rates expected to be in effect when the taxes are paid or recovered.

As of June 30, 2023, we had federal, state, and foreign net operating loss carryforwards of $509 million, $1.2 billion, and $2.3 billion, respectively. The federal and state net operating loss carryforwards have varying expiration dates ranging from fiscal year 2024 to 2043 or indefinite carryforward periods, if not utilized. The majority of our foreign net operating loss carryforwards do not expire. Certain acquired net operating loss carryforwards are subject to an annual limitation but are expected to be realized with the exception of those which have a valuation allowance. As of June 30, 2023, we had $456 million federal capital loss carryforwards for U.S. tax purposes from our acquisition of Nuance. The federal capital loss carryforwards are subject to an annual limitation and will expire in fiscal year 2025.

84

PART II Item 8

The valuation allowance disclosed in the table above relates to the foreign net operating loss carryforwards, federal capital loss carryforwards, and other net deferred tax assets that may not be realized.

Income taxes paid, net of refunds, were $23.1 billion, $16.0 billion, and $13.4 billion in fiscal years 2023, 2022, and 2021, respectively.

## Uncertain Tax Positions

Gross unrecognized tax benefits related to uncertain tax positions as of June 30, 2023, 2022, and 2021, were $17.1 billion, $15.6 billion, and $14.6 billion, respectively, which were primarily included in long-term income taxes in our consolidated balance sheets. If recognized, the resulting tax benefit would affect our effective tax rates for fiscal years 2023, 2022, and 2021 by $14.4 billion, $13.3 billion, and $12.5 billion, respectively.

As of June 30, 2023, 2022, and 2021, we had accrued interest expense related to uncertain tax positions of $5.2 billion, $4.3 billion, and $4.3 billion, respectively, net of income tax benefits. The provision for income taxes for fiscal years 2023, 2022, and 2021 included interest expense related to uncertain tax positions of $918 million, $36 million, and $274 million, respectively, net of income tax benefits.

The aggregate changes in the gross unrecognized tax benefits related to uncertain tax positions were as follows:

## (In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Beginning unrecognized tax benefits|$ 15,593|$ 14,550|$ 13,792|
|Decreases related to settlements|(329 )|(317)|(195)|
|Increases for tax positions related to the current year|1,051|1,145|790|
|Increases for tax positions related to prior years|870|461|461|
|Decreases for tax positions related to prior years|(60)|(246)|(297)|
|Decreases due to lapsed statutes of limitations|(5)|0|(1)|
|Ending unrecognized tax benefits|$ 17,120|$ 15,593|$ 14,550|


We settled a portion of the Internal Revenue Service ("IRS") audit for tax years 2004 to 2006 in fiscal year 2011. In February 2012, the IRS withdrew its 2011 Revenue Agents Report related to unresolved issues for tax years 2004 to 2006 and reopened the audit phase of the examination. We also settled a portion of the IRS audit for tax years 2007 to 2009 in fiscal year 2016, and a portion of the IRS audit for tax years 2010 to 2013 in fiscal year 2018. In the second quarter of fiscal year 2021, we settled an additional portion of the IRS audits for tax years 2004 to 2013 and made a payment of $1.7 billion, including tax and interest. We remain under audit for tax years 2004 to 2017.

As of June 30, 2023, the primary unresolved issues for the IRS audits relate to transfer pricing, which could have a material impact in our consolidated financial statements when the matters are resolved. We believe our allowances for income tax contingencies are adequate. We have not received a proposed assessment for the unresolved key transfer pricing issues. We do not expect a final resolution of these issues in the next 12 months. Based on the information currently available, we do not anticipate a significant increase or decrease to our tax contingencies for these issues within the next 12 months.

We are subject to income tax in many jurisdictions outside the U.S. Our operations in certain jurisdictions remain subject to examination for tax years 1996 to 2022, some of which are currently under audit by local tax authorities. The resolution of each of these audits is not expected to be material to our consolidated financial statements.

85

PART II Item 8

NOTE 13 - UNEARNED REVENUE

Unearned revenue by segment was as follows:

(In millions)



|June 30,|2023|2022|
|---|---|---|
|Productivity and Business Processes|$ 27,572|$ 24,558|
|Intelligent Cloud|21,563|19,371|
|More Personal Computing|4,678|4,479|
|Total|$ 53,813|$ 48,408|


Changes in unearned revenue were as follows:

(In millions)

Year Ended June 30, 2023



|Balance, beginning of period|$ 48,408|
|---|---|
|Deferral of revenue|123,935|
|Recognition of unearned revenue|(118,530)|
|Balance, end of period|$ 53,813|


Revenue allocated to remaining performance obligations, which includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, was $229 billion as of June 30, 2023, of which $224 billion is related to the commercial portion of revenue. We expect to recognize approximately 45% of this revenue over the next 12 months and the remainder thereafter.

## NOTE 14 -LEASES

We have operating and finance leases for datacenters, corporate offices, research and development facilities, Microsoft Experience Centers, and certain equipment. Our leases have remaining lease terms of less than 1 year to 18 years, some of which include options to extend the leases for up to 5 years, and some of which include options to terminate the leases within 1 year.

The components of lease expense were as follows:

(In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Operating lease cost|$ 2,875|$ 2,461|$ 2,127|
|Finance lease cost:||||
|Amortization of right-of-use assets|$ 1,352|$ 980|$ 921|
|Interest on lease liabilities|501|429|386|
|Total finance lease cost|$ 1,853|$ 1,409|$ 1,307|


Supplemental cash flow information related to leases was as follows:

(In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Cash paid for amounts included in the measurement of lease liabilities:||||
|Operating cash flows from operating leases|$ 2,706|$ 2,368|$ 2,052|
|Operating cash flows from finance leases|501|429|386|
|Financing cash flows from finance leases|1,056|896|648|
|Right-of-use assets obtained in exchange for lease obligations:||||
|Operating leases|3,514|5,268|4,380|
|Finance leases|3,128|4,234|3,290|


86

PART II Item 8

Supplemental balance sheet information related to leases was as follows:

## (In millions, except lease term and discount rate)



|June 30,|2023|2022|
|---|---|---|
|Operating Leases|||
|Operating lease right-of-use assets|$ 14,346|$ 13,148|
|Other current liabilities|$ 2,409|$ 2,228|
|Operating lease liabilities|12,728|11,489|
|Total operating lease liabilities|$ 15,137|$ 13,717|
|Finance Leases|||
|Property and equipment, at cost|$ 20,538|$ 17,388|
|Accumulated depreciation|(4,647)|(3,285)|
|Property and equipment, net|$ 15,891|$ 14,103|
|Other current liabilities|$ 1,197|$ 1,060|
|Other long-term liabilities|15,870|13,842|
|Total finance lease liabilities|$ 17,067|$ 14,902|
|Weighted Average Remaining Lease Term|||
|Operating leases|8 years|8 years|
|Finance leases|11 years|12 years|
|Weighted Average Discount Rate|||
|Operating leases|2.9%|2.1%|
|Finance leases|3.4%|3.1%|


The following table outlines maturities of our lease liabilities as of June 30, 2023:

(In millions)



|Year Ending June 30,|Operating Leases|Finance Leases|
|---|---|---|
|2024|$ 2,784|$ 1,747|
|2025|2,508|2,087|
|2026|2,142|1,771|
|2027|1,757|1,780|
|2028|1,582|1,787|
|Thereafter|6,327|11,462|
|Total lease payments|17,100|20,634|
|Less imputed interest|(1,963)|(3,567)|
|Total|$ 15,137|$ 17,067|


As of June 30, 2023, we have additional operating and finance leases, primarily for datacenters, that have not yet commenced of $7.7 billion and $34.4 billion, respectively. These operating and finance leases will commence between fiscal year 2024 and fiscal year 2030 with lease terms of 1 year to 18 years.

87

PART II Item 8

NOTE 15 - CONTINGENCIES

## U.S. Cell Phone Litigation

Microsoft Mobile Oy, a subsidiary of Microsoft, along with other handset manufacturers and network operators, is a defendant in 46 lawsuits, including 45 lawsuits filed in the Superior Court for the District of Columbia by individual plaintiffs who allege that radio emissions from cellular handsets caused their brain tumors and other adverse health effects. We assumed responsibility for these claims in our agreement to acquire Nokia's Devices and Services business and have been substituted for the Nokia defendants. Nine of these cases were filed in 2002 and are consolidated for certain pre-trial proceedings; the remaining cases are stayed. In a separate 2009 decision, the Court of Appeals for the District of Columbia held that adverse health effect claims arising from the use of cellular handsets that operate within the U.S. Federal Communications Commission radio frequency emission guidelines ("FCC Guidelines") are pre-empted by federal law. The plaintiffs allege that their handsets either operated outside the FCC Guidelines or were manufactured before the FCC Guidelines went into effect. The lawsuits also allege an industry-wide conspiracy to manipulate the science and testing around emission guidelines.

In 2013, the defendants in the consolidated cases moved to exclude the plaintiffs' expert evidence of general causation on the basis of flawed scientific methodologies. In 2014, the trial court granted in part and denied in part the defendants' motion to exclude the plaintiffs' general causation experts. The defendants filed an interlocutory appeal to the District of Columbia Court of Appeals challenging the standard for evaluating expert scientific evidence. In October 2016, the Court of Appeals issued its decision adopting the standard advocated by the defendants and remanding the cases to the trial court for further proceedings under that standard. The plaintiffs have filed supplemental expert evidence, portions of which were stricken by the court. A hearing on general causation took place in September of 2022. In April of 2023, the court granted defendants' motion to strike the testimony of plaintiffs' experts that cell phones cause brain cancer and entered an order excluding all of plaintiffs' experts from testifying.

## Irish Data Protection Commission Matter

In 2018, the Irish Data Protection Commission ("IDPC") began investigating a complaint against LinkedIn as to whether LinkedIn's targeted advertising practices violated the recently implemented European Union General Data Protection Regulation ("GDPR"). Microsoft cooperated throughout the period of inquiry. In April 2023, the IDPC provided LinkedIn with a non-public preliminary draft decision alleging GDPR violations and proposing a fine. Microsoft intends to challenge the preliminary draft decision. There is no set timeline for the IDPC to issue a final decision.

## Other Contingencies

We also are subject to a variety of other claims and suits that arise from time to time in the ordinary course of our business. Although management currently believes that resolving claims against us, individually or in aggregate, will not have a material adverse impact in our consolidated financial statements, these matters are subject to inherent uncertainties and management's view of these matters may change in the future.

As of June 30, 2023, we accrued aggregate legal liabilities of $617 million. While we intend to defend these matters vigorously, adverse outcomes that we estimate could reach approximately $600 million in aggregate beyond recorded amounts are reasonably possible. Were unfavorable final outcomes to occur, there exists the possibility of a material adverse impact in our consolidated financial statements for the period in which the effects become reasonably estimable.

88

PART II Item 8

NOTE 16 - STOCKHOLDERS' EQUITY

## Shares Outstanding

Shares of common stock outstanding were as follows:

(In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Balance, beginning of year|7,464|7,519|7,571|
|Issued|37|40|49|
|Repurchased|(69)|(95)|(101)|
|Balance, end of year|7,432|7,464|7,519|


## Share Repurchases

On September 18, 2019, our Board of Directors approved a share repurchase program authorizing up to $40.0 billion in share repurchases. This share repurchase program commenced in February 2020 and was completed in November 2021.

On September 14, 2021, our Board of Directors approved a share repurchase program authorizing up to $60.0 billion in share repurchases. This share repurchase program commenced in November 2021, following completion of the program approved on September 18, 2019, has no expiration date, and may be terminated at any time. As of June 30, 2023, $22.3 billion remained of this $60.0 billion share repurchase program.

We repurchased the following shares of common stock under the share repurchase programs:



|(In millions)|Shares|Amount|Shares|Amount|Shares|Amount|
|---|---|---|---|---|---|---|
|Year Ended June 30,||2023||2022||2021|
|First Quarter|17|$ 4,600|21|$ 6,200|25|$ 5,270|
|Second Quarter|20|4,600|20|6,233|27|5,750|
|Third Quarter|18|4,600|26|7,800|25|5,750|
|Fourth Quarter|14|4,600|28|7,800|24|6,200|
|Total|69|$ 18,400|95|$ 28,033|101|$ 22,970|


89

PART II Item 8

All repurchases were made using cash resources. Shares repurchased during fiscal year 2023 and the fourth and third quarters of fiscal year 2022 were under the share repurchase program approved on September 14, 2021. Shares repurchased during the second quarter of fiscal year 2022 were under the share repurchase programs approved on both September 14, 2021 and September 18, 2019. All other shares repurchased were under the share repurchase program approved on September 18, 2019. The above table excludes shares repurchased to settle employee tax withholding related to the vesting of stock awards of $3.8 billion, $4.7 billion, and $4.4 billion for fiscal years 2023, 2022, and 2021, respectively.

## Dividends

Our Board of Directors declared the following dividends:



|Declaration Date Fiscal Year 2023|Record Date|Payment Date|Dividend Per Share|Amount|
|---|---|---|---|---|
|||||(In millions)|
|September 20, 2022|November 17, 2022|December 8, 2022|$ 0.68|$ 5,066|
|November 29, 2022|February 16, 2023|March 9, 2023|0.68|5,059|
|March 14, 2023|May 18, 2023|June 8, 2023|0.68|5,054|
|June 13, 2023|August 17, 2023|September 14, 2023|0.68|5,054|
|Total|||$ 2.72|$ 20,233|
|Fiscal Year 2022|||||
|September 14, 2021|November 18, 2021|December 9, 2021|$ 0.62|$ 4,652|
|December 7, 2021|February 17, 2022|March 10, 2022|0.62|4,645|
|March 14, 2022|May 19, 2022|June 9, 2022|0.62|4,632|
|June 14, 2022|August 18, 2022|September 8, 2022|0.62|4,621|
|Total|||$ 2.48|$ 18,550|


The dividend declared on June 13, 2023 was included in other current liabilities as of June 30, 2023.

90

PART II Item 8

NOTE 17 - ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

The following table summarizes the changes in accumulated other comprehensive income (loss) by component:



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Derivatives||||
|Balance, beginning of period|$ (13)|$ (19)|$ (38)|
|Unrealized gains (losses), net of tax of $9, $(15), and $9|34|(57)|34|
|Reclassification adjustments for (gains) losses included in other income (expense), net|(61)|79|(17)|
|Tax expense (benefit) included in provision for income taxes|13|(16)|2|
|Amounts reclassified from accumulated other comprehensive income (loss)|(48)|63|(15)|
|Net change related to derivatives, net of tax of $(4), $1, and $7|(14)|6|19|
|Balance, end of period|$ (27)|$ (13)|$ (19)|
|Investments||||
|Balance, beginning of period|$ (2,138)|$ 3,222|$ 5,478|
|Unrealized losses, net of tax of $(393), $(1,440), and $(589)|(1,523)|(5,405)|(2,216)|
|Reclassification adjustments for (gains) losses included in other income (expense), net|99|57|(63)|
|Tax expense (benefit) included in provision for income taxes|(20)|(12)|13|
|Amounts reclassified from accumulated other comprehensive income (loss)|79|45|(50)|
|Net change related to investments, net of tax of $(373), $(1,428), and $(602)|(1,444)|(5,360)|(2,266)|
|Cumulative effect of accounting changes|0|0|10|
|Balance, end of period|$ (3,582)|$ (2,138)|$ 3,222|
|Translation Adjustments and Other||||
|Balance, beginning of period|$ (2,527)|$ (1,381)|$ (2,254)|
|Translation adjustments and other, net of tax of $0, $0, and $(9)|(207)|(1,146)|873|
|Balance, end of period|$ (2,734)|$ (2,527)|$ (1,381)|
|Accumulated other comprehensive income (loss), end of period|$ (6,343)|$ (4,678)|$ 1,822|


## NOTE 18 - EMPLOYEE STOCK AND SAVINGS PLANS

We grant stock-based compensation to employees and directors. Awards that expire or are canceled without delivery of shares generally become available for issuance under the plans. We issue new shares of Microsoft common stock to satisfy vesting of awards granted under our stock plans. We also have an ESPP for all eligible employees.

Stock-based compensation expense and related income tax benefits were as follows:

## (In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Stock-based compensation expense|$ 9,611|$ 7,502|$ 6,118|
|Income tax benefits related to stock-based compensation|1,651|1,293|1,065|


## Stock Plans

Stock awards entitle the holder to receive shares of Microsoft common stock as the award vests. Stock awards generally vest over a service period of four years or five years.

91

PART II Item 8

## Executive Incentive Plan

Under the Executive Incentive Plan, the Compensation Committee approves stock awards to executive officers and certain senior executives. RSUs generally vest ratably over a service period of four years. PSUs generally vest over a performance period of three years. The number of shares the PSU holder receives is based on the extent to which the corresponding performance goals have been achieved.

## Activity for All Stock Plans

The fair value of stock awards was estimated on the date of grant using the following assumptions:



|Year ended June 30,|2023|2022|2021|
|---|---|---|---|
|Dividends per share (quarterly amounts)|$ 0.62 - 0.68|$ 0.56 - 0.62|$ 0.51 - 0.56|
|Interest rates|2.0% - 5.4%|0.03% - 3.6%|0.01% - 1.5%|


During fiscal year 2023, the following activity occurred under our stock plans:



||Shares (In millions)|Weighted Average Grant-Date Fair Value|
|---|---|---|
|Stock Awards|||
|Nonvested balance, beginning of year|93|$ 227.59|
|Granted (a)|56|252.59|
|Vested|(44)|206.90|
|Forfeited|(9)|239.93|
|Nonvested balance, end of year|96|$ 250.37|


(a)Includes 1 million, 1 million, and 2 million of PSUs granted at target and performance adjustments above target levels for fiscal years 2023, 2022, and 2021, respectively.

As of June 30, 2023, total unrecognized compensation costs related to stock awards were $18.6 billion. These costs are expected to be recognized over a weighted average period of three years. The weighted average grant-date fair value of stock awards granted was $252.59, $291.22, and $221.13 for fiscal years 2023, 2022, and 2021, respectively. The fair value of stock awards vested was $11.9 billion, $14.1 billion, and $13.4 billion, for fiscal years 2023, 2022, and 2021, respectively. As of June 30, 2023, an aggregate of 164 million shares were authorized for future grant under our stock plans.

## Employee Stock Purchase Plan

We have an ESPP for all eligible employees. Shares of our common stock may be purchased by employees at three-month intervals at 90% of the fair market value on the last trading day of each three-month period. Employees may purchase shares having a value not exceeding 15% of their gross compensation during an offering period.

Employees purchased the following shares during the periods presented:

(Shares in millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Shares purchased|7|7|8|
|Average price per share|$ 245.59|$ 259.55|$ 207.88|


As of June 30, 2023, 74 million shares of our common stock were reserved for future issuance through the ESPP.

92

PART II Item 8

## Savings Plans

We have savings plans in the U.S. that qualify under Section 401(k) of the Internal Revenue Code, and a number of savings plans in international locations. Eligible U.S. employees may contribute a portion of their salary into the savings plans, subject to certain limitations. We match a portion of each dollar a participant contributes into the plans. Employer-funded retirement benefits for all plans were $1.6 billion, $1.4 billion, and $1.2 billion in fiscal years 2023, 2022, and 2021, respectively, and were expensed as contributed.

## NOTE 19 - SEGMENT INFORMATION AND GEOGRAPHIC DATA

In its operation of the business, management, including our chief operating decision maker, who is also our Chief Executive Officer, reviews certain financial information, including segmented internal profit and loss statements prepared on a basis not consistent with GAAP. During the periods presented, we reported our financial performance based on the following segments: Productivity and Business Processes, Intelligent Cloud, and More Personal Computing.

We have recast certain prior period amounts to conform to the way we internally manage and monitor our business.

Our reportable segments are described below.

## Productivity and Business Processes

Our Productivity and Business Processes segment consists of products and services in our portfolio of productivity, communication, and information services, spanning a variety of devices and platforms. This segment primarily comprises:

·Office Commercial (Office 365 subscriptions, the Office 365 portion of Microsoft 365 Commercial subscriptions, and Office licensed on- premises), comprising Office, Exchange, SharePoint, Microsoft Teams, Office 365 Security and Compliance, Microsoft Viva, and Microsoft 365 Copilot.

·Office Consumer, including Microsoft 365 Consumer subscriptions, Office licensed on-premises, and other Office services.

·LinkedIn, including Talent Solutions, Marketing Solutions, Premium Subscriptions, and Sales Solutions.

·Dynamics business solutions, including Dynamics 365, comprising a set of intelligent, cloud-based applications across ERP, CRM (including Customer Insights), Power Apps, and Power Automate; and on-premises ERP and CRM applications.

## Intelligent Cloud

Our Intelligent Cloud segment consists of our public, private, and hybrid server products and cloud services that can power modern business and developers. This segment primarily comprises:

·Server products and cloud services, including Azure and other cloud services; SQL Server, Windows Server, Visual Studio, System Center, and related Client Access Licenses ("CALs"); and Nuance and GitHub.

·Enterprise Services, including Enterprise Support Services, Industry Solutions (formerly Microsoft Consulting Services), and Nuance professional services.

## More Personal Computing

Our More Personal Computing segment consists of products and services that put customers at the center of the experience with our technology. This segment primarily comprises:

·Windows, including Windows OEM licensing and other non-volume licensing of the Windows operating system; Windows Commercial, comprising volume licensing of the Windows operating system, Windows cloud services, and other Windows commercial offerings; patent licensing; and Windows Internet of Things.

·Devices, including Surface, HoloLens, and PC accessories.

93

PART II Item 8

·Gaming, including Xbox hardware and Xbox content and services, comprising first- and third-party content (including games and in-game content), Xbox Game Pass and other subscriptions, Xbox Cloud Gaming, advertising, third-party disc royalties, and other cloud services. .Search and news advertising, comprising Bing (including Bing Chat), Microsoft News, Microsoft Edge, and third-party affiliates.

Revenue and costs are generally directly attributed to our segments. However, due to the integrated structure of our business, certain revenue recognized and costs incurred by one segment may benefit other segments. Revenue from certain contracts is allocated among the segments based on the relative value of the underlying products and services, which can include allocation based on actual prices charged, prices when sold separately, or estimated costs plus a profit margin. Cost of revenue is allocated in certain cases based on a relative revenue methodology. Operating expenses that are allocated primarily include those relating to marketing of products and services from which multiple segments benefit and are generally allocated based on relative gross margin.

In addition, certain costs are incurred at a corporate level and allocated to our segments. These allocated costs generally include legal, including settlements and fines, information technology, human resources, finance, excise taxes, field selling, shared facilities services, customer service and support, and severance incurred as part of a corporate program. Each allocation is measured differently based on the specific facts and circumstances of the costs being allocated and is generally based on relative gross margin or relative headcount.

Segment revenue and operating income were as follows during the periods presented:

## (In millions)



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Revenue||||
|Productivity and Business Processes|$ 69,274|$ 63,364|$ 53,915|
|Intelligent Cloud|87,907|74,965|59,728|
|More Personal Computing|54,734|59,941|54,445|
|Total|$ 211,915|$ 198,270|$ 168,088|
|Operating Income||||
|Productivity and Business Processes|$ 34,189|$ 29,690|$ 24,351|
|Intelligent Cloud|37,884|33,203|26,471|
|More Personal Computing|16,450|20,490|19,094|
|Total|$ 88,523|$ 83,383|$ 69,916|


No sales to an individual customer or country other than the United States accounted for more than 10% of revenue for fiscal years 2023, 2022, or 2021. Revenue, classified by the major geographic areas in which our customers were located, was as follows:



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|United States (a)|$ 106,744|$ 100,218|$ 83,953|
|Other countries|105,171|98,052|84,135|
|Total|$ 211,915|$ 198,270|$ 168,088|


(a)Includes billings to OEMs and certain multinational organizations because of the nature of these businesses and the impracticability of determining the geographic source of the revenue.

94

PART II Item 8

Revenue, classified by significant product and service offerings, was as follows:



|Year Ended June 30,|2023|2022|2021|
|---|---|---|---|
|Server products and cloud services|$ 79,970|$ 67,350|$ 52,589|
|Office products and cloud services|48,728|44,862|39,872|
|Windows|21,507|24,732|22,488|
|Gaming|15,466|16,230|15,370|
|Linkedln|15,145|13,816|10,289|
|Search and news advertising|12,208|11,591|9,267|
|Enterprise Services|7,722|7,407|6,943|
|Devices|5,521|7,306|7,143|
|Dynamics|5,437|4,687|3,754|
|Other|211|289|373|
|Total|$ 211,915|$ 198,270|$ 168,088|


Our Microsoft Cloud revenue, which includes Azure and other cloud services, Office 365 Commercial, the commercial portion of LinkedIn, Dynamics 365, and other commercial cloud properties, was $111.6 billion, $91.4 billion, and $69.1 billion in fiscal years 2023, 2022, and 2021, respectively. These amounts are primarily included in Server products and cloud services, Office products and cloud services, LinkedIn, and Dynamics in the table above.

Assets are not allocated to segments for internal reporting presentations. A portion of amortization and depreciation is included with various other costs in an overhead allocation to each segment. It is impracticable for us to separately identify the amount of amortization and depreciation by segment that is included in the measure of segment profit or loss.

Long-lived assets, excluding financial instruments and tax assets, classified by the location of the controlling statutory company and with countries over 10% of the total shown separately, were as follows:

(In millions)



|June 30,|2023|2022|2021|
|---|---|---|---|
|United States|$ 114,380|$ 106,430|$ 76,153|
|Ireland|16,359|15,505|13,303|
|Other countries|56,500|44,433|38,858|
|Total|$ 187,239|$ 166,368|$ 128,314|


95

PART II Item 8

## Opinion on the Financial Statements

We have audited the accompanying consolidated balance sheets of Microsoft Corporation and subsidiaries (the "Company") as of June 30, 2023 and 2022, the related consolidated statements of income, comprehensive income, cash flows, and stockholders' equity, for each of the three years in the period ended June 30, 2023, and the related notes (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of June 30, 2023 and 2022, and the results of its operations and its cash flows for each of the three years in the period ended June 30, 2023, in conformity with accounting principles generally accepted in the United States of America.

We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of June 30, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated July 27, 2023, expressed an unqualified opinion on the Company's internal control over financial reporting.

## Basis for Opinion

These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

## Critical Audit Matters

The critical audit matters communicated below are matters arising from the current-period audit of the financial statements that were communicated or required to be communicated to the audit committee and that (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

## Critical Audit Matter Description

The Company recognizes revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products or services. The Company offers customers the ability to acquire multiple licenses of software products and services, including cloud-based services, in its customer agreements through its volume licensing programs.

96

PART II Item 8

Significant judgment is exercised by the Company in determining revenue recognition for these customer agreements, and includes the following:

·Determination of whether products and services are considered distinct performance obligations that should be accounted for separately versus together, such as software licenses and related services that are sold with cloud-based services.

·The pattern of delivery (i.e., timing of when revenue is recognized) for each distinct performance obligation.

.Identification and treatment of contract terms that may impact the timing and amount of revenue recognized (e.g., variable consideration, optional purchases, and free services).

·Determination of stand-alone selling prices for each distinct performance obligation and for products and services that are not sold separately.

Given these factors and due to the volume of transactions, the related audit effort in evaluating management's judgments in determining revenue recognition for these customer agreements was extensive and required a high degree of auditor judgment.

## How the Critical Audit Matter Was Addressed in the Audit

Our principal audit procedures related to the Company's revenue recognition for these customer agreements included the following:

We tested the effectiveness of controls related to the identification of distinct performance obligations, the determination of the timing of revenue recognition, and the estimation of variable consideration.

· We evaluated management's significant accounting policies related to these customer agreements for reasonableness.

· We selected a sample of customer agreements and performed the following procedures:

Obtained and read contract source documents for each selection, including master agreements, and other documents that were part of the agreement.

- Tested management's identification and treatment of contract terms.

Assessed the terms in the customer agreement and evaluated the appropriateness of management's application of their accounting policies, along with their use of estimates, in the determination of revenue recognition conclusions.

· We evaluated the reasonableness of management's estimate of stand-alone selling prices for products and services that are not sold separately.

We tested the mathematical accuracy of management's calculations of revenue and the associated timing of revenue recognized in the financial statements.

## Critical Audit Matter Description

The Company's long-term income taxes liability includes uncertain tax positions related to transfer pricing issues that remain unresolved with the Internal Revenue Service ("IRS"). The Company remains under IRS audit, or subject to IRS audit, for tax years subsequent to 2003. While the Company has settled a portion of the IRS audits, resolution of the remaining matters could have a material impact on the Company's financial statements.

Conclusions on recognizing and measuring uncertain tax positions involve significant estimates and management judgment and include complex considerations of the Internal Revenue Code, related regulations, tax case laws, and prior-year audit settlements. Given the complexity and the subjective nature of the transfer pricing issues that remain unresolved with the IRS, evaluating management's estimates relating to their determination of uncertain tax positions required extensive audit effort and a high degree of auditor judgment, including involvement of our tax specialists.

97

PART II Item 8

## How the Critical Audit Matter Was Addressed in the Audit

Our principal audit procedures to evaluate management's estimates of uncertain tax positions related to unresolved transfer pricing issues included the following:

·We evaluated the appropriateness and consistency of management's methods and assumptions used in the identification, recognition, measurement, and disclosure of uncertain tax positions, which included testing the effectiveness of the related internal controls.

·We read and evaluated management's documentation, including relevant accounting policies and information obtained by management from outside tax specialists, that detailed the basis of the uncertain tax positions.

.We tested the reasonableness of management's judgments regarding the future resolution of the uncertain tax positions, including an evaluation of the technical merits of the uncertain tax positions.

.For those uncertain tax positions that had not been effectively settled, we evaluated whether management had appropriately considered new information that could significantly change the recognition, measurement or disclosure of the uncertain tax positions.

·We evaluated the reasonableness of management's estimates by considering how tax law, including statutes, regulations and case law, impacted management's judgments.

/s/ DELOITTE & TOUCHE LLP

Seattle, Washington July 27, 2023

We have served as the Company's auditor since 1983.

98

PART II Item 9, 9A

ITEM 9. CHANGES IN AND DISAGREEMENTS WITH ACCOUNTANTS ON ACCOUNTING AND FINANCIAL DISCLOSURE

Not applicable.

ITEM 9A. CONTROLS AND PROCEDURES

Under the supervision and with the participation of our management, including the Chief Executive Officer and Chief Financial Officer, we have evaluated the effectiveness of our disclosure controls and procedures as required by Exchange Act Rule 13a-15(b) as of the end of the period covered by this report. Based on that evaluation, the Chief Executive Officer and Chief Financial Officer have concluded that these disclosure controls and procedures are effective.

## REPORT OF MANAGEMENT ON INTERNAL CONTROL OVER FINANCIAL REPORTING

Our management is responsible for establishing and maintaining adequate internal control over financial reporting for the Company. Internal control over financial reporting is a process to provide reasonable assurance regarding the reliability of our financial reporting for external purposes in accordance with accounting principles generally accepted in the United States of America. Internal control over financial reporting includes maintaining records that in reasonable detail accurately and fairly reflect our transactions; providing reasonable assurance that transactions are recorded as necessary for preparation of our consolidated financial statements; providing reasonable assurance that receipts and expenditures of company assets are made in accordance with management authorization; and providing reasonable assurance that unauthorized acquisition, use, or disposition of company assets that could have a material effect on our consolidated financial statements would be prevented or detected on a timely basis. Because of its inherent limitations, internal control over financial reporting is not intended to provide absolute assurance that a misstatement of our consolidated financial statements would be prevented or detected.

Management conducted an evaluation of the effectiveness of our internal control over financial reporting based on the framework in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, management concluded that the Company's internal control over financial reporting was effective as of June 30, 2023. There were no changes in our internal control over financial reporting during the quarter ended June 30, 2023 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting. Deloitte & Touche LLP has audited our internal control over financial reporting as of June 30, 2023; their report is included in Item 9A.

99

PART II Item 9A

## REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

To the Stockholders and the Board of Directors of Microsoft Corporation

## Opinion on Internal Control over Financial Reporting

We have audited the internal control over financial reporting of Microsoft Corporation and subsidiaries (the "Company") as of June 30, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of June 30, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by COSO.

We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended June 30, 2023, of the Company and our report dated July 27, 2023, expressed an unqualified opinion on those financial statements.

## Basis for Opinion

The Company's management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Report of Management on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company's internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

## Definition and Limitations of Internal Control over Financial Reporting

A company's internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company's internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company's assets that could have a material effect on the financial statements.

Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

/s/ DELOITTE & TOUCHE LLP

Seattle, Washington July 27, 2023

100

PART II, III Item 9B, 9C, 10, 11, 12, 13, 14

ITEM 9B. OTHER INFORMATION

During the three months ended June 30, 2023, none of our directors or officers (as defined in Rule 16a-1(f) of the Securities Exchange Act of 1934) informed us of the adoption or termination of a "Rule 10b5-1 trading arrangement" or "non-Rule 10b5-1 trading arrangement," as defined in Item 408 of Regulation S-K.

## ITEM 9C. DISCLOSURE REGARDING FOREIGN JURISDICTIONS THAT PREVENT INSPECTIONS

Not applicable.

## ITEM 10. DIRECTORS, EXECUTIVE OFFICERS, AND CORPORATE GOVERNANCE

A list of our executive officers and biographical information appears in Part I, Item 1 of this Form 10-K. Information about our directors may be found under the caption "Our Director Nominees" in our Proxy Statement for the Annual Meeting of Shareholders to be held December 7, 2023 (the "Proxy Statement"). Information about our Audit Committee may be found under the caption "Board Committees" in the Proxy Statement. That information is incorporated herein by reference.

We have adopted the Microsoft Finance Code of Professional Conduct (the "finance code of ethics"), a code of ethics that applies to our Chief Executive Officer, Chief Financial Officer, Chief Accounting Officer, and other finance organization employees. The finance code of ethics is publicly available on our website at https://aka.ms/FinanceCodeProfessionalConduct. If we make any substantive amendments to the finance code of ethics or grant any waiver, including any implicit waiver, from a provision of the code to our Chief Executive Officer, Chief Financial Officer, or Chief Accounting Officer, we will disclose the nature of the amendment or waiver on that website or in a report on Form 8-K.

## ITEM 11. EXECUTIVE COMPENSATION

The information in the Proxy Statement set forth under the captions "Director Compensation," "Named Executive Officer Compensation," "Compensation Committee Report," and, if required, "Compensation Committee Interlocks and Insider Participation," is incorporated herein by reference.

## ITEM 12. SECURITY OWNERSHIP OF CERTAIN BENEFICIAL OWNERS AND MANAGEMENT AND RELATED STOCKHOLDER MATTERS

The information in the Proxy Statement set forth under the captions "Stock Ownership Information," "Principal Shareholders" and "Equity Compensation Plan Information" is incorporated herein by reference.

ITEM 13. CERTAIN RELATIONSHIPS AND RELATED TRANSACTIONS, AND DIRECTOR INDEPENDENCE

The information set forth in the Proxy Statement under the captions "Director Independence Guidelines" and "Certain Relationships and Related Transactions" is incorporated herein by reference.

## ITEM 14. PRINCIPAL ACCOUNTANT FEES AND SERVICES

Information concerning fees and services provided by our principal accountant, Deloitte & Touche LLP (PCAOB ID No. 34), appears in the Proxy Statement under the headings "Fees Billed by Deloitte & Touche" and "Policy on Audit Committee Pre-Approval of Audit and Permissible Non-Audit Services of Independent Auditor" and is incorporated herein by reference.

101

PART IV Item 15

## PART IV

ITEM 15. EXHIBIT AND FINANCIAL STATEMENT SCHEDULES

## (a)Financial Statements and Schedules

The financial statements are set forth under Part II, Item 8 of this Form 10-K, as indexed below. Financial statement schedules have been omitted since they either are not required, not applicable, or the information is otherwise included.



|Index to Financial Statements|Page|
|---|---|
|Income Statements|58|
|Comprehensive Income Statements|59|
|Balance Sheets|60|
|Cash Flows Statements|61|
|Stockholders' Equity Statements|62|
|Notes to Financial Statements|63|
|Report of Independent Registered Public Accounting Firm|96|




|Exhibit Number|Exhibit Description|Filed Herewith|Incorporated by Reference||||
|---|---|---|---|---|---|---|
||||Form|Period Ending|Exhibit|Filing Date|
|4.6|Third Supplemental Indenture for 2.500% Notes due 2016, 4.000% Notes due 2021, and 5.300% Notes due 2041, dated as of February 8, 2011,||8-K||4.2|2/8/2011|
||||||||
||between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee, to the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee||||||
||||||||
|4.7|Fourth Supplemental Indenture for 0.875% Notes due 2017, 2.125% Notes due 2022, and 3.500% Notes due 2042, dated as of November 7, 2012, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee, to the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The||8-K||4.1|11/7/2012|
||||||||
||Bank of New York Mellon Trust Company, N.A., as Trustee||||||
|4.8|Fifth Supplemental Indenture for 2.625% Notes due 2033, dated as of May 2, 2013, between||8-K||4.1|5/1/2013|
||Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee, to||||||
||the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee||||||
|4.9|Sixth Supplemental Indenture for 1.000% Notes due 2018, 2.375% Notes due 2023, and 3.750%||8-K||4.2|5/1/2013|
||Notes due 2043, dated as of May 2, 2013, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee, to the Indenture, dated as of May 18. 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee||||||




|Exhibit Number|Exhibit Description|Filed Herewith|Incorporated by Reference||||
|---|---|---|---|---|---|---|
||||Form|Period Ending|Exhibit|Filing Date|
|4.10|Seventh Supplemental Indenture for 2.125% Notes due 2021 and 3.125% Notes due 2028, dated as of December 6, 2013, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee, to the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee||8-K||4.1|12/6/2013|
||||||||
||||||||
|4.11|Eighth Supplemental Indenture for 1.625% Notes due 2018, 3.625% Notes due 2023, and 4.875% Notes due 2043, dated as of December||8-K||4.2|12/6/2013|
||||||||
||6. 2013, between Microsoft Corporation and The||||||
||Bank of New York Mellon Trust Company, N.A., as Trustee, to the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee||||||
|4.12|Ninth Supplemental Indenture for 1.850% Notes due 2020, 2.375% Notes due 2022, 2.700%||8-K||4.1|2/12/2015|
||Notes due 2025, 3.500% Notes due 2035, 3.750% Notes due 2045, and 4.000% Notes due 2055, dated as of February 12, 2015, between Microsoft Corporation and U.S. Bank National Association, as Trustee, to the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as trustee||||||
||||||||
||||||||
|4.13|Tenth Supplemental Indenture for 1.300% Notes||8-K||4.1|11/3/2015|
||due 2018, 2.000% Notes due 2020, 2.650%||||||
||Notes due 2022, 3.125% Notes due 2025, 4.200% Notes due 2035, 4.450% Notes due 2045, and 4.750% Notes due 2055, dated as of November 3, 2015, between Microsoft Corporation and U.S. Bank National Association, as Trustee, to the Indenture, dated as of May 18. 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as trustee||||||




|Exhibit Number|Exhibit Description|Filed Herewith|Incorporated by Reference||||
|---|---|---|---|---|---|---|
||||Form|Period Ending|Exhibit|Filing Date|
|4.14|Eleventh Supplemental Indenture for 1.100% Notes due 2019, 1.550% Notes due 2021. 2.000% Notes due 2023, 2.400% Notes due||8-K||4.1|8/5/2016|
||||||||
||2026, 3.450% Notes due 2036, 3.700% Notes due 2046, and 3.950% Notes due 2056, dated as of August 8, 2016, between Microsoft||||||
||||||||
||Corporation and U.S. Bank, National Association, as Trustee, to the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as trustee||||||
||||||||
|4.15|Twelfth Supplemental Indenture for 1.850%||8-K||4.1|2/3/2017|
||Notes due 2020, 2.400% Notes due 2022, 2.875% Notes due 2024, 3.300% Notes due 2027, 4.100% Notes due 2037, 4.250% Notes due 2047. and 4.500% Notes due 2057, dated as of February 6, 2017, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee, to the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as trustee||||||
||||||||
||||||||
|4.16|Thirteenth Supplemental Indenture for 2.525% Notes due 2050 and 2.675% Notes due 2060, dated as of June 1, 2020, between Microsoft Corporation and U.S. Bank National Association, as Trustee, to the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as trustee||8-K||4.1|6/1/2020|
||||||||
||||||||
|4.17|Fourteenth Supplemental Indenture for 2.921% Notes due 2052 and 3.041% Notes due 2062,||8-K||4.1|3/17/2021|
||||||||
||dated as of March 17, 2021, between Microsoft Corporation and The Bank of New York Mellon||||||
||Trust Company, N.A., as Trustee, to the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as trustee||||||
|4.18|Description of Securities||10-K|6/30/2019|4.16|8/1/2019|
|10.1*|Microsoft Corporation 2001 Stock Plan||10-Q|9/30/2016|10.1|10/20/2016|
|10.4*|Microsoft Corporation Employee Stock Purchase Plan||10-K|6/30/2012|10.4|7/26/2012|
||||||||




|Exhibit Number|Exhibit Description|Filed Herewith|Incorporated by Reference||||
|---|---|---|---|---|---|---|
||||Form|Period Ending|Exhibit|Filing Date|
|10.5*|Microsoft Corporation Deferred Compensation Plan||10-K|6/30/2018|10.5|8/3/2018|
|10.6*|Microsoft Corporation 2017 Stock Plan||DEF14A||Annex C|10/16/2017|
|10.7*|Form of Stock Award Agreement Under the Microsoft Corporation 2017 Stock Plan||10-Q|3/31/2018|10.26|4/26/2018|
|10.8*|Form of Performance Stock Award Agreement Under the Microsoft Corporation 2017 Stock Plan||10-Q|3/31/2018|10.27|4/26/2018|
|10.9|Amended and Restated Officers' Indemnification Trust Agreement between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as trustee||10-Q|9/30/2016|10.12|10/20/2016|
|10.10|Assumption of Beneficiaries' Representative Obligations Under Amended and Restated Officers' Indemnification Trust Agreement||10-K|6/30/2020|10.25|7/30/2020|
|10.11|Form of Indemnification Agreement and Amended and Restated Directors' Indemnification Trust Agreement between||10-K|6/30/2019|10.13|8/1/2019|
||||||||
||Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as trustee||||||
|10.12|Assumption of Beneficiaries' Representative Obligations Under Amended and Restated Directors' Indemnification Trust Agreement||10-K|6/30/2020|10.26|7/30/2020|
|10.14*|Microsoft Corporation Deferred Compensation Plan for Non-Employee Directors||10-Q|12/31/2017|10.14|1/31/2018|
|10.15*|Microsoft Corporation Executive Incentive Plan||8-K||10.1|9/19/2018|
|10.19*|Microsoft Corporation Executive Incentive Plan||10-Q|9/30/2016|10.17|10/20/2016|
|10.20*|Form of Executive Incentive Plan (Executive Officer SAs) Stock Award Agreement under the Microsoft Corporation 2001 Stock Plan||10-Q|9/30/2016|10.18|10/20/2016|
|10.21*|Form of Executive Incentive Plan Performance Stock Award Agreement under the Microsoft Corporation 2001 Stock Plan||10-Q|9/30/2016|10.25|10/20/2016|
|10.22*|Senior Executive Severance Benefit Plan||10-Q|9/30/2016|10.22|10/20/2016|
|10.23*|Offer Letter, dated February 3, 2014, between Microsoft Corporation and Satya Nadella||8-K||10.1|2/4/2014|


## (b)Exhibit Listing



|Exhibit Number|Exhibit Description|Filed Herewith|Incorporated by Reference||||
|---|---|---|---|---|---|---|
||||Form|Period Ending|Exhibit|Filing Date|
|3.1|Amended and Restated Articles of Incorporation of Microsoft Corporation||8-K||3.1|12/1/2016|
|3.2|Bylaws of Microsoft Corporation||8-K||3.2|7/3/2023|
|4.1|Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee ("Base Indenture")||S-3ASR||4.1|10/29/2015|
|4.2|Form of First Supplemental Indenture for 2.95% Notes due 2014, 4.20% Notes due 2019, and 5.20% Notes due 2039, dated as of May 18.||8-K||4.2|5/15/2009|
||2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee, to the Base Indenture||||||
|4.5|Form of Second Supplemental Indenture for 0.875% Notes due 2013, 1.625% Notes due 2015, 3.00% Notes due 2020, and 4.50% Notes due 2040, dated as of September 27, 2010. between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee, to the Indenture, dated as of May 18, 2009, between Microsoft Corporation and The Bank of New York Mellon Trust Company, N.A., as Trustee||8-K||4.2|9/27/2010|


102

PART IV Item 15

103

PART IV Item 15

104

PART IV Item 15

105

PART IV Item 15

106

PART IV Item 15



|Exhibit Number|Exhibit Description|Filed Herewith|Incorporated by Reference||||
|---|---|---|---|---|---|---|
||||Form|Period Ending|Exhibit|Filing Date|
|10.24*|Long-Term Performance Stock Award Agreement between Microsoft Corporation and Satya Nadella||10-Q|12/31/2014|10.24|1/26/2015|
|10.25*|Offer Letter, dated October 25, 2020, between Microsoft Corporation and Christopher Young|:unselected:|10-Q|9/30/2021|10.27|10/26/2021|
|21|Subsidiaries of Registrant|X
:selected:|||||
|23.1|Consent of Independent Registered Public Accounting Firm|X
:selected:|||||
|31.1|Certification of Chief Executive Officer Pursuant to Section 302 of the Sarbanes-Oxley Act of 2002|X
:selected:|||||
|31.2|Certification of Chief Financial Officer Pursuant to Section 302 of the Sarbanes-Oxley Act of 2002|X
:selected:|||||
|32.1 **|Certification of Chief Executive Officer Pursuant to Section 906 of the Sarbanes-Oxley Act of 2002|X
:selected:
:unselected:|||||
|32.2 **|Certification of Chief Financial Officer Pursuant to Section 906 of the Sarbanes-Oxley Act of 2002|X
:selected:|||||
|101.INS|Inline XBRL Instance Document-the instance document does not appear in the Interactive Data File as its XBRL tags are embedded within the Inline XBRL document|X
:selected:
:unselected:|||||
|101.SCH|Inline XBRL Taxonomy Extension Schema|X
:selected:|||||
|101.CAL|Inline XBRL Taxonomy Extension Calculation Linkbase|X
:selected:|||||
|101.DEF|Inline XBRL Taxonomy Extension Definition Linkbase|X
:selected:|||||
|101.LAB|Inline XBRL Taxonomy Extension Label Linkbase|X
:selected:|||||
|101.PRE|Inline XBRL Taxonomy Extension Presentation Linkbase|X
:selected:|||||
|104|Cover page formatted as Inline XBRL and contained in Exhibit 101|X
:selected:|||||


PART IV Item 16

ITEM 16. FORM 10-K SUMMARY

None.

108

SIGNATURES

Pursuant to the requirements of Section 13 or 15(d) of the Securities Exchange Act of 1934, the Registrant has duly caused this report to be signed on its behalf by the undersigned; thereunto duly authorized, in the City of Redmond, State of Washington, on July 27, 2023.

PART IV Item 16

ITEM 16. FORM 10-K SUMMARY

None.

108

SIGNATURES

Pursuant to the requirements of Section 13 or 15(d) of the Securities Exchange Act of 1934, the Registrant has duly caused this report to be signed on its behalf by the undersigned; thereunto duly authorized, in the City of Redmond, State of Washington, on July 27, 2023.

/s/ ALICE L. JOLLA Alice L. Jolla Corporate Vice President and Chief Accounting Officer (Principal Accounting Officer)

Pursuant to the requirements of the Securities Exchange Act of 1934, this report has been signed below by the following persons on behalf of Registrant and in the capacities indicated on July 27, 2023.



|Signature|Title|
|---|---|
|/s/ SATYA NADELLA|Chairman and Chief Executive Officer (Principal Executive Officer)|
|Satya Nadella||
|/s/ REID HOFFMAN|Director|
|Reid Hoffman||
|/s/ HUGH F. JOHNSTON|Director|
|Hugh F. Johnston||
|/s/ TERI L. LIST|Director|
|Teri L. List||
|/s/ SANDRA E. PETERSON|Lead Independent Director|
|Sandra E. Peterson||
|/s/ PENNY S. PRITZKER|Director|
|Penny S. Pritzker||
|/s/ CARLOS A. RODRIGUEZ|Director|
|Carlos A. Rodriguez||
|/s/ CHARLES W. SCHARF|Director|
|Charles W. Scharf||
|/s/ JOHN W. STANTON|Director|
|John W. Stanton||
|/s/ JOHN W. THOMPSON|Director|
|John W. Thompson||
|/s/ EMMA N. WALMSLEY|Director|
|Emma N. Walmsley||
|/s/ PADMASREE WARRIOR|Director|
|Padmasree Warrior||
|/s/ AMY E. HOOD|Executive Vice President and Chief Financial Officer (Principal Financial Officer)|
|Amy E. Hood||
|/s/ ALICE L. JOLLA|Corporate Vice President and Chief Accounting Officer (Principal Accounting Officer)|
|Alice L. Jolla||


109

Exhibit 21

SUBSIDIARIES OF REGISTRANT

The following is a list of subsidiaries of Microsoft Corporation as of June 30, 2023, omitting subsidiaries which, considered in the aggregate, would not constitute a significant subsidiary.



|Name|Where Incorporated|
|---|---|
|Microsoft Ireland Research|Ireland|
|Microsoft Global Finance|Ireland|
|Microsoft Ireland Operations Limited|Ireland|
|Microsoft Online, Inc.|United States|
|LinkedIn Corporation|United States|
|LinkedIn Ireland Unlimited Company|Ireland|
|Nuance Communications, Inc.|United States|


Exhibit 23.1

CONSENT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

We consent to the incorporation by reference in Registration Statement Nos. 333-109185, 333-118764, 333-52852, 333-132100, 333-161516, 333-75243, 333-185757, and 333-221833 on Form S-8 and Registration Statement Nos. 333-240227 and 333-261590 on Form S-3 of our reports dated July 27, 2023, relating to the financial statements of Microsoft Corporation and the effectiveness of Microsoft Corporation's internal control over financial reporting appearing in this Annual Report on Form 10-K of Microsoft Corporation for the year ended June 30, 2023.

/s/ DELOITTE & TOUCHE LLP

Seattle, Washington July 27, 2023

Exhibit 31.1

CERTIFICATION

I, Satya Nadella, certify that:

1. I have reviewed this annual report on Form 10-K of Microsoft Corporation;

2. Based on my knowledge, this report does not contain any untrue statement of a material fact or omit to state a material fact necessary to make the statements made, in light of the circumstances under which such statements were made, not misleading with respect to the period covered by this report;

3. Based on my knowledge, the financial statements, and other financial information included in this report, fairly present in all material respects the financial condition, results of operations and cash flows of the registrant as of, and for, the periods presented in this report;

4. The registrant's other certifying officer and I are responsible for establishing and maintaining disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) and internal control over financial reporting (as defined in Exchange Act Rules 13a-15(f) and 15d-15(f)) for the registrant and have:

a) Designed such disclosure controls and procedures, or caused such disclosure controls and procedures to be designed under our supervision, to ensure that material information relating to the registrant, including its consolidated subsidiaries, is made known to us by others within those entities, particularly during the period in which this report is being prepared;

b) Designed such internal control over financial reporting, or caused such internal control over financial reporting to be designed under our supervision, to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles;

c) Evaluated the effectiveness of the registrant's disclosure controls and procedures and presented in this report our conclusions about the effectiveness of the disclosure controls and procedures, as of the end of the period covered by this report based on such evaluation; and

d) Disclosed in this report any change in the registrant's internal control over financial reporting that occurred during the registrant's most recent fiscal quarter (the registrant's fourth fiscal quarter in the case of an annual report) that has materially affected, or is reasonably likely to materially affect, the registrant's internal control over financial reporting; and

5. The registrant's other certifying officer and I have disclosed, based on our most recent evaluation of internal control over financial reporting, to the registrant's auditors and the audit committee of registrant's Board of Directors (or persons performing the equivalent functions):

a) All significant deficiencies and material weaknesses in the design or operation of internal control over financial reporting which are reasonably likely to adversely affect the registrant's ability to record, process, summarize and report financial information; and

b) Any fraud, whether or not material, that involves management or other employees who have a significant role in the registrant's internal control over financial reporting.

/s/ SATYA NADELLA

Satya Nadella

Chief Executive Officer

July 27, 2023

Exhibit 31.2

CERTIFICATION

I, Amy E. Hood, certify that:

1. I have reviewed this annual report on Form 10-K of Microsoft Corporation;

2. Based on my knowledge, this report does not contain any untrue statement of a material fact or omit to state a material fact necessary to make the statements made, in light of the circumstances under which such statements were made, not misleading with respect to the period covered by this report;

3. Based on my knowledge, the financial statements, and other financial information included in this report, fairly present in all material respects the financial condition, results of operations and cash flows of the registrant as of, and for, the periods presented in this report;

4. The registrant's other certifying officer and I are responsible for establishing and maintaining disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) and internal control over financial reporting (as defined in Exchange Act Rules 13a-15(f) and 15d-15(f)) for the registrant and have:

a) Designed such disclosure controls and procedures, or caused such disclosure controls and procedures to be designed under our supervision, to ensure that material information relating to the registrant, including its consolidated subsidiaries, is made known to us by others within those entities, particularly during the period in which this report is being prepared;

b) Designed such internal control over financial reporting, or caused such internal control over financial reporting to be designed under our supervision, to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles;

c) Evaluated the effectiveness of the registrant's disclosure controls and procedures and presented in this report our conclusions about the effectiveness of the disclosure controls and procedures, as of the end of the period covered by this report based on such evaluation; and

d) Disclosed in this report any change in the registrant's internal control over financial reporting that occurred during the registrant's most recent fiscal quarter (the registrant's fourth fiscal quarter in the case of an annual report) that has materially affected, or is reasonably likely to materially affect, the registrant's internal control over financial reporting; and

5. The registrant's other certifying officer and I have disclosed, based on our most recent evaluation of internal control over financial reporting, to the registrant's auditors and the audit committee of registrant's Board of Directors (or persons performing the equivalent functions):

a) All significant deficiencies and material weaknesses in the design or operation of internal control over financial reporting which are reasonably likely to adversely affect the registrant's ability to record, process, summarize and report financial information; and

b) Any fraud, whether or not material, that involves management or other employees who have a significant role in the registrant's internal control over financial reporting.

/s/ AMY E. HOOD

Amy E. Hood

Executive Vice President and

Chief Financial Officer

July 27, 2023

Exhibit 32.1

CERTIFICATION PURSUANT TO SECTION 906 OF THE SARBANES-OXLEY ACT OF 2002 (18 U.S.C. SECTION 1350)

In connection with the Annual Report of Microsoft Corporation, a Washington corporation (the "Company"), on Form 10-K for the year ended June 30, 2023, as filed with the Securities and Exchange Commission (the "Report"), Satya Nadella, Chief Executive Officer of the Company, does hereby certify, pursuant to § 906 of the Sarbanes-Oxley Act of 2002 (18 U.S.C. § 1350), that to his knowledge:

(1) The Report fully complies with the requirements of section 13(a) or 15(d) of the Securities Exchange Act of 1934; and

(2) The information contained in the Report fairly presents, in all material respects, the financial condition and results of operations of the Company.

/s/ SATYA NADELLA

Satya Nadella

Chief Executive Officer

July 27, 2023

[A signed original of this written statement required by Section 906 has been provided to Microsoft Corporation and will be retained by Microsoft Corporation and furnished to the Securities and Exchange Commission or its staff upon request.]

Exhibit 32.2

CERTIFICATION PURSUANT TO SECTION 906 OF THE SARBANES-OXLEY ACT OF 2002 (18 U.S.C. SECTION 1350)

In connection with the Annual Report of Microsoft Corporation, a Washington corporation (the "Company"), on Form 10-K for the year ended June 30, 2023, as filed with the Securities and Exchange Commission (the "Report"), Amy E. Hood, Chief Financial Officer of the Company, does hereby certify, pursuant to § 906 of the Sarbanes-Oxley Act of 2002 (18 U.S.C. § 1350), that to her knowledge:

(1) The Report fully complies with the requirements of section 13(a) or 15(d) of the Securities Exchange Act of 1934; and

(2) The information contained in the Report fairly presents, in all material respects, the financial condition and results of operations of the Company.

/s/ AMY E. HOOD Amy E. Hood Executive Vice President and Chief Financial Officer July 27, 2023

[A signed original of this written statement required by Section 906 has been provided to Microsoft Corporation and will be retained by Microsoft Corporation and furnished to the Securities and Exchange Commission or its staff upon request.]

